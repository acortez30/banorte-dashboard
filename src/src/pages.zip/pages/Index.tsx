// src/pages/Orders/Index.tsx

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  addMonths,
  differenceInCalendarMonths,
} from "date-fns";
import type { DateRange } from "react-day-picker";
import { useSearchParams } from "react-router-dom";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import type { Order } from "@/components/dashboard/OrdersTable";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";

import { OrdersHeader } from "@/components/Orders/OrdersHeader";
import { OrdersMetrics } from "@/components/Orders/OrdersMetrics";
import { OrdersTableSection } from "@/components/Orders/OrdersTableSection";
import type { OrdersStatusTabValue } from "@/components/Orders/OrdersStatusTabs";
import {
  OrdersTabs,
  type OrdersTabValue,
} from "@/components/Orders/OrdersTabs";
import { PendingValidationTable } from "@/components/Orders/PendingValidationTable";

import { useLanguage } from "@/contexts/LanguageContext";
import { useLocalStorageState } from "@/hooks/useLocalStorageState";
import { usePackageValidations } from "@/hooks/usePackageValidations";
import {
  ordersService,
  supportsOrdersQueryControls,
  type OrdersPriorityStatus,
  type OrdersSortBy,
  type OrdersSortDir,
} from "@/services/orders.service";
import { formatPackageCompartments } from "@/utils/packageCompartments";

/* ============================= */
/* TYPES                         */
/* ============================= */

type OrderStatus =
  | "completed"
  | "expired"
  | "in_locker"
  | "in_transit"
  | "pending_validate"
  | "pending_payment"
  | "in_progress"
  | "returned"
  | "canceled"
  | "canceled_picked"
  | "scheduled"
  | "failure";

interface OrdersFilters {
  dateRange: DateRange | undefined;
  statusFilter: string;
  offeringFilter: string;
  search: string;
  sortBy?: OrdersSortBy | "";
  sortDir?: OrdersSortDir;
  priorityStatus?: OrdersPriorityStatus | "";
}

type OrderWithOffering = Order & {
  id_offering?: number | null;
  offering?: string;
  id_offering_operation?: number | null;
  operation_name?: string;
  is_food?: boolean;
};

/* ============================= */
/* STATUS CONFIG                 */
/* ============================= */

const STATUS_MAP: Record<string, OrderStatus> = {
  // Ciclo principal del paquete
  "16-18": "completed",
  "14-17": "in_locker",
  "14-32": "expired",
  "33-32": "returned",

  // Locker a Locker: para Orders ambos se muestran dentro del grupo En locker
  "47-17": "in_locker",
  "57-17": "in_locker",

  // Estados logísticos internos que pertenecen al grupo in_transit
  "49-17": "in_transit",
  "53-17": "in_transit",
  "97-17": "in_transit",
  "117-17": "in_transit",
  "179-17": "in_transit",

  // Cancelación / fallas
  "14-20": "canceled",
  "33-20": "canceled_picked",
  "82-17": "failure",
};

const SERVICE_STATUS_MAP: Record<number, OrderStatus> = {
  35: "scheduled",
  42: "pending_validate",
  12: "pending_payment",
  37: "in_transit",
};

const ALLOWED_STATUS = new Set<OrderStatus>([
  "completed",
  "expired",
  "in_locker",
  "in_transit",
  "pending_validate",
  "pending_payment",
  "in_progress",
  "returned",
  "canceled",
  "canceled_picked",
  "scheduled",
  "failure",
]);

/* ============================= */
/* OFFERING CONFIG               */
/* ============================= */

const OFFERING_LABEL_MAP: Record<number, string> = {
  1: "Enviar un paquete",
  2: "Intercambio Seguro",
  3: "Devoluciones Fáciles",
  4: "Recibir",
  5: "Almacenamiento",
  6: "Dejar Paquete",
  7: "Droppi Shop",
};

/* ============================= */
/* HELPERS                       */
/* ============================= */

function toValidDate(
  value: unknown,
): Date | undefined {
  if (!value) {
    return undefined;
  }

  if (value instanceof Date) {
    return Number.isNaN(value.getTime())
      ? undefined
      : value;
  }

  const parsedDate = new Date(
    String(value),
  );

  return Number.isNaN(
    parsedDate.getTime(),
  )
    ? undefined
    : parsedDate;
}

function normalizeDateRange(
  range: unknown,
): DateRange | undefined {
  if (!range) {
    return undefined;
  }

  const currentRange =
    range as DateRange;

  const from = toValidDate(
    currentRange.from,
  );

  const to = toValidDate(
    currentRange.to,
  );

  if (!from && !to) {
    return undefined;
  }

  return {
    from,
    to,
  };
}

function startOfDayMs(
  date: Date,
): number {
  return new Date(date).setHours(
    0,
    0,
    0,
    0,
  );
}

function endOfDayMs(
  date: Date,
): number {
  return new Date(date).setHours(
    23,
    59,
    59,
    999,
  );
}

function normalizeArray(
  data: unknown,
): any[] {
  if (!data) {
    return [];
  }

  return Array.isArray(data)
    ? data
    : [data];
}

function isCanceledPackage(
  item: any,
): boolean {
  return (
    item?.nombre_status ===
      "CANCELED_UNUSED" ||
    item?.nombre_status ===
      "ELIMINADO"
  );
}

function getOfferingFields(
  item: any,
) {
  const idOffering = Number(
    item?.id_offering,
  );

  const idOperation = Number(
    item?.id_offering_operation,
  );

  const validOffering =
    Number.isFinite(idOffering) &&
    idOffering > 0
      ? idOffering
      : null;

  const validOperation =
    Number.isFinite(idOperation) &&
    idOperation > 0
      ? idOperation
      : null;

  return {
    id_offering: validOffering,
    offering: validOffering
      ? OFFERING_LABEL_MAP[
          validOffering
        ] ?? "---"
      : "---",
    id_offering_operation:
      validOperation,
    operation_name:
      item?.operation_name ?? "---",
    is_food:
      validOperation === 9,
  };
}

function getOrderDateMs(
  order: OrderWithOffering,
): number {
  const date =
    order.received_date ||
    order.withdrawn_date;

  const parsedDate = new Date(
    date || "",
  ).getTime();

  return Number.isNaN(parsedDate)
    ? 0
    : parsedDate;
}

function isOrderInsideRange(
  order: OrderWithOffering,
  dateStart: number,
  dateEnd: number,
): boolean {
  const orderDate =
    getOrderDateMs(order);

  return (
    orderDate >= dateStart &&
    orderDate <= dateEnd
  );
}

function mapOrder(
  item: any,
): OrderWithOffering | null {
  if (!item) {
    return null;
  }

  const offeringFields =
    getOfferingFields(item);

  if (isCanceledPackage(item)) {
    return {
      id_service:
        item.id_service ??
        item.id_package ??
        0,

      tracking_number:
        item.code_service ??
        item.tracking_number ??
        "---",

      email:
        item.email ?? "---",

      door: formatPackageCompartments(item),

      status: "canceled",

      received_date:
        item.cancel_date ??
        item.update_date ??
        item.package_delivery_date ??
        null,

      withdrawn_date:
        item.package_pickup_date ??
        null,

      expiration_date:
        item.expiration_date ??
        item.package_expiration_date ??
        null,

      ...offeringFields,
    };
  }

  const packageStatus = Number(
    item.status_package ??
      item.package_status ??
      item.id_status_package,
  );

  const codePackageStatus = Number(
    item.id_status_code_package ??
      item.code_package_status ??
      item.status_code_package,
  );

  const statusKey =
    packageStatus && codePackageStatus
      ? `${packageStatus}-${codePackageStatus}`
      : "";

  const serviceStatus = Number(
    item.id_status ??
      item.service_status ??
      item.id_service_status,
  );

  const statusName = String(
    item.nombre_status ??
      item.status_name ??
      item.name_status_package ??
      "",
  )
    .trim()
    .toUpperCase();

  const codeStatusName = String(
    item.nombre_status_code_package ?? "",
  )
    .trim()
    .toUpperCase();

  let status: OrderStatus | undefined = STATUS_MAP[statusKey];

  // Si el paquete no tiene una combinación conocida, primero intentamos
  // resolver por nombres logísticos. Nunca debemos asumir "scheduled"
  // para un estado desconocido porque eso hace parecer que priority_status
  // no funciona aunque el backend esté priorizando otro grupo.
  if (!status) {
    if (
      statusName.includes("IN_TRANSIT") ||
      statusName.includes("ROUTE") ||
      statusName.includes("WAREHOUSE") ||
      statusName.includes("CEDIS") ||
      statusName.includes("ALMACEN") ||
      statusName.includes("ALMACÉN") ||
      statusName.includes("ASSIGNED_CARRIER") ||
      codeStatusName === "ASIGNADO"
    ) {
      status = "in_transit";
    } else if (statusName.includes("IN_LOCKER")) {
      status = "in_locker";
    }
  }

  if (!status && SERVICE_STATUS_MAP[serviceStatus]) {
    status = SERVICE_STATUS_MAP[serviceStatus];
  }

  if (!status) {
    if (statusName === "SCHEDULED") {
      status = "scheduled";
    } else if (
      statusName === "TO_BE_APPROVED" ||
      statusName === "PENDING_VALIDATE"
    ) {
      status = "pending_validate";
    } else if (
      statusName === "PENDIENTE_POR_PAGO" ||
      statusName === "PENDING_PAYMENT"
    ) {
      status = "pending_payment";
    } else {
      status = "in_progress";
    }
  }

  if (!ALLOWED_STATUS.has(status)) {
    return null;
  }

  return {
    id_service:
      item.id_service ??
      item.id_package ??
      0,

    tracking_number:
      item.tracking_number ??
      item.code_service ??
      "---",

    email:
      item.email ?? "---",

    door: formatPackageCompartments(item),

    status,

    received_date:
      item.package_delivery_date ??
      item.registration_date ??
      item.update_date ??
      item.service_date ??
      null,

    withdrawn_date:
      item.package_pickup_date ??
      null,

    expiration_date:
      item.expiration_date ??
      item.package_expiration_date ??
      null,

    ...offeringFields,
  };
}

function mapFailureOrder(
  item: any,
): OrderWithOffering | null {
  if (!item) {
    return null;
  }

  return {
    id_service:
      item.id_service ?? 0,

    tracking_number:
      item.code_service ??
      "---",

    email:
      item.email ?? "---",

    door:
      item.door_number &&
      item.position
        ? `#${item.door_number} · ${item.position}`
        : item.position ??
          (item.door_number
            ? `#${item.door_number}`
            : "---"),

    status: "failure",

    received_date:
      item.registration_date ??
      item.update_date ??
      null,

    withdrawn_date: null,

    expiration_date: null,

    id_offering: null,
    offering: "---",

    id_offering_operation: null,
    operation_name: "---",

    is_food: false,
  };
}

function sortOrders(
  orders: OrderWithOffering[],
): OrderWithOffering[] {
  return [...orders].sort(
    (firstOrder, secondOrder) =>
      getOrderDateMs(secondOrder) -
      getOrderDateMs(firstOrder),
  );
}

function getOrderUniqueKey(order: OrderWithOffering): string {
  const idService = Number(order.id_service);

  if (Number.isFinite(idService) && idService > 0) {
    return `service-${idService}`;
  }

  return [
    "fallback",
    order.tracking_number || "no-tracking",
    order.door || "no-door",
    order.received_date || order.withdrawn_date || "no-date",
  ].join("|");
}

function getOrderPriority(order: OrderWithOffering): number {
  const priorityByStatus: Record<OrderStatus, number> = {
    canceled: 11,
    canceled_picked: 10,
    completed: 9,
    returned: 8,
    expired: 7,
    failure: 6,
    in_locker: 5,
    in_transit: 4,
    pending_payment: 3,
    pending_validate: 2,
    scheduled: 1,
    in_progress: 0,
  };

  return priorityByStatus[order.status] ?? 0;
}

function shouldReplaceOrder(
  currentOrder: OrderWithOffering,
  nextOrder: OrderWithOffering
): boolean {
  const currentPriority = getOrderPriority(currentOrder);
  const nextPriority = getOrderPriority(nextOrder);

  if (nextPriority !== currentPriority) {
    return nextPriority > currentPriority;
  }

  return getOrderDateMs(nextOrder) >= getOrderDateMs(currentOrder);
}

function dedupeOrders(
  orders: OrderWithOffering[]
): OrderWithOffering[] {
  const ordersMap = new Map<string, OrderWithOffering>();

  orders.forEach((order) => {
    const key = getOrderUniqueKey(order);
    const currentOrder = ordersMap.get(key);

    if (!currentOrder || shouldReplaceOrder(currentOrder, order)) {
      ordersMap.set(key, order);
    }
  });

  return Array.from(ordersMap.values());
}


interface PaginationMeta {
  total: number;
  totalPages: number;
}

function readPaginationMeta(
  response: any,
  fallbackLength: number,
  pageSize: number,
): PaginationMeta {
  const rawTotal =
    response?.total ??
    response?.pagination?.total ??
    response?.result?.total ??
    response?.meta?.total;

  const parsedTotal = Number(rawTotal);
  const total = Number.isFinite(parsedTotal)
    ? Math.max(0, parsedTotal)
    : fallbackLength;

  const rawTotalPages =
    response?.total_pages ??
    response?.pagination?.total_pages ??
    response?.pagination?.totalPages ??
    response?.result?.total_pages ??
    response?.meta?.total_pages;

  const parsedTotalPages = Number(rawTotalPages);
  const totalPages =
    Number.isFinite(parsedTotalPages) && parsedTotalPages > 0
      ? parsedTotalPages
      : Math.max(1, Math.ceil(total / Math.max(1, pageSize)));

  return { total, totalPages };
}

async function safeScheduledRequest(
  request: () => Promise<any>,
): Promise<any> {
  try {
    return await request();
  } catch (error) {
    console.error("Scheduled orders request failed", error);
    return { return_result: [] };
  }
}

/* ============================= */
/* COMPONENT                     */
/* ============================= */

export default function Index() {
  const { t, language } =
    useLanguage();

  const [
    searchParams,
    setSearchParams,
  ] = useSearchParams();

  const activeTab: OrdersTabValue =
    searchParams.get("tab") ===
    "validation"
      ? "validation"
      : "packages";

  const handleTabChange =
    useCallback(
      (
        nextTab: OrdersTabValue,
      ) => {
        const nextParams =
          new URLSearchParams(
            searchParams,
          );

        if (
          nextTab === "packages"
        ) {
          nextParams.delete("tab");
        } else {
          nextParams.set(
            "tab",
            "validation",
          );
        }

        setSearchParams(
          nextParams,
          {
            replace: true,
          },
        );
      },
      [
        searchParams,
        setSearchParams,
      ],
    );

  const canViewFailures = useMemo(() => {
    try {
      const storedUser = JSON.parse(
        localStorage.getItem("user") || "{}",
      );

      const idUserType = Number(
        storedUser?.id_user_type ??
          storedUser?.data_company?.id_user_type ??
          0,
      );

      const userTypeName = String(
        storedUser?.user_type ?? "",
      )
        .trim()
        .toUpperCase();

      return (
        idUserType === 1 ||
        idUserType === 7 ||
        userTypeName.includes("SUPER") ||
        userTypeName.includes("SOPORTE") ||
        userTypeName.includes("SUPPORT")
      );
    } catch {
      return false;
    }
  }, []);

  const statusParam =
    searchParams.get("status");

  const activeStatus: OrdersStatusTabValue =
    statusParam === "in_progress" ||
    statusParam === "expired" ||
    statusParam === "scheduled" ||
    statusParam === "completed" ||
    statusParam === "canceled" ||
    (statusParam === "failure" && canViewFailures)
      ? statusParam
      : "all";

  const handleStatusTabChange =
    useCallback(
      (nextStatus: OrdersStatusTabValue) => {
        const nextParams =
          new URLSearchParams(searchParams);

        if (nextStatus === "all") {
          nextParams.delete("status");
        } else {
          nextParams.set("status", nextStatus);
        }

        setPage(1);
        setSearchParams(nextParams, {
          replace: true,
        });
      },
      [searchParams, setSearchParams],
    );

  /* ============================= */
  /* COMPANY DATA                  */
  /* ============================= */

  const companyData =
    useMemo(() => {
      try {
        return JSON.parse(
          localStorage.getItem(
            "company",
          ) || "{}",
        );
      } catch {
        return {};
      }
    }, []);

  const idProperty =
    useMemo(() => {
      const value = Number(
        companyData
          ?.id_propierty ??
          companyData
            ?.id_property,
      );

      return Number.isFinite(
        value,
      ) && value > 0
        ? value
        : undefined;
    }, [companyData]);

  const idLocker =
    useMemo(() => {
      const value = Number(
        companyData?.id_locker,
      );

      return Number.isFinite(
        value,
      ) && value > 0
        ? value
        : undefined;
    }, [companyData]);

  /* ============================= */
  /* PACKAGE VALIDATIONS           */
  /* ============================= */

  const {
    validations,
    loading:
      validationsLoading,
    refreshing:
      validationsRefreshing,
    error: validationsError,
    refetch:
      refetchValidations,
  } = usePackageValidations({
    idProperty,
    idLocker,
    language,
    refetchIntervalMs: 30_000,
  });

  /**
   * El endpoint /server/package/unassigned
   * también puede regresar paquetes con
   * assignment_status === "ASSIGNED".
   *
   * La pestaña "Paquetes por verificar"
   * solamente debe mostrar registros
   * realmente pendientes de asignación.
   */
const pendingValidations = useMemo(() => {
  return validations.filter((validation: any) => {
    const assignmentStatus = String(
      validation?.status ??
        validation?.assignment_status ??
        validation?.assignmentStatus ??
        "",
    )
      .trim()
      .toUpperCase();


  });
}, [validations]);

  /* ============================= */
  /* REFERENCES                    */
  /* ============================= */

  const isMountedRef =
    useRef(true);

  const requestIdRef =
    useRef(0);

  /* ============================= */
  /* ORDERS STATE                  */
  /* ============================= */

  const [orders, setOrders] =
    useState<
      OrderWithOffering[]
    >([]);

  const [loading, setLoading] =
    useState(false);

  const [page, setPage] =
    useState(1);

  const [pageSize, setPageSize] =
    useState(10);

  const [ordersTotal, setOrdersTotal] =
    useState(0);

  const [ordersTotalPages, setOrdersTotalPages] =
    useState(1);

  /* ============================= */
  /* PERSISTENT FILTERS            */
  /* ============================= */

  const [
    filters,
    setFilters,
  ] =
    useLocalStorageState<OrdersFilters>(
      "orders_filters",
      {
        dateRange: {
          from: new Date(
            new Date().getFullYear(),
            new Date().getMonth(),
            1,
          ),
          to: new Date(),
        },
        statusFilter: "",
        offeringFilter: "",
        search: "",
        sortBy: "",
        sortDir: "desc",
        priorityStatus: "",
      },
    );

  const dateRange =
    useMemo(
      () =>
        normalizeDateRange(
          filters.dateRange,
        ),
      [filters.dateRange],
    );

  const dateStartMs =
    useMemo(() => {
      if (!dateRange?.from) {
        return null;
      }

      return startOfDayMs(
        dateRange.from,
      );
    }, [dateRange?.from]);

  const dateEndMs =
    useMemo(() => {
      if (!dateRange?.to) {
        return null;
      }

      return endOfDayMs(
        dateRange.to,
      );
    }, [dateRange?.to]);

  const {
    offeringFilter,
    search,
  } = filters;

  // Compatibilidad con filtros guardados antes de incorporar orden/prioridad.
  const sortBy: OrdersSortBy | "" =
    filters.sortBy ?? "";

  const sortDir: OrdersSortDir =
    filters.sortDir === "asc" ? "asc" : "desc";

  const priorityStatus: OrdersPriorityStatus | "" =
    filters.priorityStatus ?? "";

  const setDateRange =
    useCallback(
      (
        range:
          | DateRange
          | undefined,
      ) => {
        setFilters(
          (previousFilters) => ({
            ...previousFilters,
            dateRange:
              normalizeDateRange(
                range,
              ),
          }),
        );
      },
      [setFilters],
    );

  const setOfferingFilter =
    useCallback(
      (value: string) => {
        setFilters(
          (previousFilters) => ({
            ...previousFilters,
            offeringFilter:
              value,
          }),
        );
      },
      [setFilters],
    );

  const setSearch =
    useCallback(
      (value: string) => {
        setFilters(
          (previousFilters) => ({
            ...previousFilters,
            search: value,
          }),
        );
      },
      [setFilters],
    );

  const setSortBy =
    useCallback(
      (value: OrdersSortBy | "") => {
        setFilters(
          (previousFilters) => ({
            ...previousFilters,
            sortBy: value,
            // sort_dir solo tiene efecto cuando existe sort_by.
            sortDir: previousFilters.sortDir ?? "desc",
          }),
        );
      },
      [setFilters],
    );

  const setSortDir =
    useCallback(
      (value: OrdersSortDir) => {
        setFilters(
          (previousFilters) => ({
            ...previousFilters,
            sortDir: value,
          }),
        );
      },
      [setFilters],
    );

  const setPriorityStatus =
    useCallback(
      (value: OrdersPriorityStatus | "") => {
        setFilters(
          (previousFilters) => ({
            ...previousFilters,
            priorityStatus: value,
          }),
        );
      },
      [setFilters],
    );

  const resetOrderQuery =
    useCallback(() => {
      setFilters(
        (previousFilters) => ({
          ...previousFilters,
          sortBy: "",
          sortDir: "desc",
          priorityStatus: "",
        }),
      );
    }, [setFilters]);

  const resetTableFilters =
    useCallback(() => {
      const now = new Date();

      setFilters(
        (previousFilters) => ({
          ...previousFilters,
          dateRange: {
            from: new Date(
              now.getFullYear(),
              now.getMonth(),
              1,
            ),
            to: now,
          },
          statusFilter: "",
          offeringFilter: "",
          search: "",
        }),
      );

      handleStatusTabChange("all");
      setPage(1);
    }, [
      handleStatusTabChange,
      setFilters,
    ]);

  /* ============================= */
  /* METRICS STATE                 */
  /* ============================= */

  const [
    totalDelivery,
    setTotalDelivery,
  ] = useState(0);

  const [
    avgPerHour,
    setAvgPerHour,
  ] = useState(0);

  const [
    peakHour,
    setPeakHour,
  ] = useState<
    string | number
  >(0);

  const [
    delivers,
    setDelivers,
  ] = useState<number[]>([]);

  const [
    collected,
    setCollected,
  ] = useState<number[]>([]);

  const [
    expired,
    setExpired,
  ] = useState<number[]>([]);

  /* ============================= */
  /* DATE LIMIT                    */
  /* ============================= */

  const onDateChange =
    useCallback(
      (
        range:
          | DateRange
          | undefined,
      ) => {
        const normalizedRange =
          normalizeDateRange(
            range,
          );

        if (
          !normalizedRange?.from
        ) {
          setDateRange(
            normalizedRange,
          );
          return;
        }

        if (!normalizedRange.to) {
          setDateRange(
            normalizedRange,
          );
          return;
        }

        const monthsDifference =
          differenceInCalendarMonths(
            normalizedRange.to,
            normalizedRange.from,
          );

        const safeRange =
          monthsDifference > 3
            ? {
                from:
                  normalizedRange.from,
                to: addMonths(
                  normalizedRange.from,
                  3,
                ),
              }
            : normalizedRange;

        const currentFrom =
          dateRange?.from?.getTime();

        const currentTo =
          dateRange?.to?.getTime();

        const nextFrom =
          safeRange.from?.getTime();

        const nextTo =
          safeRange.to?.getTime();

        if (
          currentFrom ===
            nextFrom &&
          currentTo === nextTo
        ) {
          return;
        }

        setDateRange(safeRange);
      },
      [
        dateRange,
        setDateRange,
      ],
    );

  /* ============================= */
  /* FETCH ORDERS                  */
  /* ============================= */

  const fetchData =
    useCallback(
      async (showLoader = true) => {
        if (!dateStartMs || !dateEndMs) {
          return;
        }

        const requestId =
          ++requestIdRef.current;

        if (showLoader) {
          setLoading(true);
        }

        try {
          const companyRaw =
            localStorage.getItem("company");

          if (!companyRaw) {
            throw new Error(
              "No existe company en localStorage",
            );
          }

          const userData =
            JSON.parse(companyRaw);

          if (!userData?.id_company) {
            throw new Error(
              "No existe id_company en company",
            );
          }

          const lang =
            localStorage.getItem("lang") || "es";

          const baseParams = {
            language: lang,
            id_company: userData.id_company,
            date_start: dateStartMs,
            date_end: dateEndMs,
          };

          const usesQueryPackageCompany =
            supportsOrdersQueryControls(activeStatus);

          const queryPackageCompanyControls =
            usesQueryPackageCompany
              ? {
                  ...(sortBy
                    ? {
                        sort_by: sortBy,
                        sort_dir: sortDir,
                      }
                    : {}),
                  ...(priorityStatus
                    ? {
                        priority_status: priorityStatus,
                      }
                    : {}),
                }
              : {};

          const ordersRequest = () =>
            ordersService.getOrdersByStatus(
              activeStatus,
              usesQueryPackageCompany
                ? {
                    ...baseParams,
                    ...queryPackageCompanyControls,
                    page,
                    limit: pageSize,
                  }
                : baseParams,
            );

          const [
            metricsResponse,
            ordersResponse,
          ] = await Promise.all([
            ordersService.getMetricsOrders({
              language: lang,
            }),
            activeStatus === "scheduled"
              ? safeScheduledRequest(ordersRequest)
              : ordersRequest(),
          ]);

          if (
            !isMountedRef.current ||
            requestId !== requestIdRef.current
          ) {
            return;
          }

          if (metricsResponse?.return_metric) {
            const metrics =
              metricsResponse.return_metric;

            setTotalDelivery(
              Number(
                metrics.delivery?.total_delivery ?? 0,
              ),
            );

            setAvgPerHour(
              Number(
                metrics.hours_usage
                  ?.average_usage_per_hour ?? 0,
              ),
            );

            const greatestHour =
              metrics.hours_usage
                ?.greatest_hour_use?.hora;

            setPeakHour(
              greatestHour
                ? String(greatestHour).substring(0, 5)
                : 0,
            );

            setDelivers(
              metrics.data_month?.map((item: any) =>
                Number(item.package_delivery ?? 0),
              ) || [],
            );

            setCollected(
              metrics.data_month?.map((item: any) =>
                Number(item.pickup_package ?? 0),
              ) || [],
            );

            setExpired(
              metrics.data_month?.map((item: any) =>
                Number(item.expired_packages ?? 0),
              ) || [],
            );
          } else if (showLoader) {
            setTotalDelivery(0);
            setAvgPerHour(0);
            setPeakHour(0);
            setDelivers([]);
            setCollected([]);
            setExpired([]);
          }

const mappedOrders =
  normalizeArray(
    ordersResponse?.return_result,
  )
    .map((item) =>
      activeStatus === "failure"
        ? mapFailureOrder(item)
        : mapOrder(item),
    )
    .filter(
      Boolean,
    ) as OrderWithOffering[];

          const shouldFilterRangeLocally =
            activeStatus === "scheduled" ||
            activeStatus === "canceled" ||
            activeStatus === "failure";

          const visibleOrders = shouldFilterRangeLocally
            ? mappedOrders.filter((order) =>
                isOrderInsideRange(
                  order,
                  dateStartMs,
                  dateEndMs,
                ),
              )
            : mappedOrders;

          const dedupedOrders =
            dedupeOrders(visibleOrders);

          // query-package-company ya entrega el orden definitivo del backend.
          // No debemos volver a ordenarlo localmente o sort_by / priority_status
          // perderían efecto visual. Los endpoints legacy conservan el sort local.
          const normalizedOrders = usesQueryPackageCompany
            ? dedupedOrders
            : sortOrders(dedupedOrders);

          setOrders(normalizedOrders);

          if (
            activeStatus === "scheduled" ||
            activeStatus === "canceled" ||
            activeStatus === "failure"
          ) {
            setOrdersTotal(normalizedOrders.length);
            setOrdersTotalPages(
              Math.max(
                1,
                Math.ceil(
                  normalizedOrders.length /
                    Math.max(1, pageSize),
                ),
              ),
            );
          } else {
            const pagination = readPaginationMeta(
              ordersResponse,
              normalizedOrders.length,
              pageSize,
            );

            setOrdersTotal(pagination.total);
            setOrdersTotalPages(pagination.totalPages);

            if (page > pagination.totalPages) {
              setPage(pagination.totalPages);
            }
          }
        } catch (error) {
          console.error(
            "Error loading orders data:",
            error,
          );

          if (
            isMountedRef.current &&
            requestId === requestIdRef.current &&
            showLoader
          ) {
            setOrders([]);
            setOrdersTotal(0);
            setOrdersTotalPages(1);
            setTotalDelivery(0);
            setAvgPerHour(0);
            setPeakHour(0);
            setDelivers([]);
            setCollected([]);
            setExpired([]);
          }
        } finally {
          if (
            isMountedRef.current &&
            requestId === requestIdRef.current &&
            showLoader
          ) {
            setLoading(false);
          }
        }
      },
      [
        activeStatus,
        dateStartMs,
        dateEndMs,
        page,
        pageSize,
        sortBy,
        sortDir,
        priorityStatus,
      ],
    );

  useEffect(() => {
    setPage(1);
  }, [
    activeStatus,
    dateStartMs,
    dateEndMs,
    sortBy,
    sortDir,
    priorityStatus,
  ]);

  /* ============================= */
  /* AUTO REFRESH                  */
  /* ============================= */

  useEffect(() => {
    isMountedRef.current =
      true;

    void fetchData(true);

    const intervalId =
      window.setInterval(() => {
        void fetchData(false);
      }, 30_000);

    return () => {
      isMountedRef.current =
        false;

      window.clearInterval(
        intervalId,
      );
    };
  }, [fetchData]);

  /* ============================= */
  /* RENDER                        */
  /* ============================= */

  return (
    <DashboardLayout>
      <div className="animate-fade-in space-y-6">
        <OrdersHeader
          dateRange={dateRange}
          onDateChange={
            onDateChange
          }
          exportData={
            orders as unknown as Record<
              string,
              unknown
            >[]
          }
          showExport={
            activeTab ===
            "packages"
          }
        />

        <OrdersTabs
          value={activeTab}
          onValueChange={
            handleTabChange
          }
          packagesCount={
            ordersTotal
          }
validationsCount={
  validations.length
}
          packagesContent={
            <div className="relative min-h-[320px] space-y-6">
              {loading && (
                <div className="absolute inset-0 z-50 flex justify-center rounded-xl bg-background/90 backdrop-blur-sm">
                  <LoadingSpinner
                    text={t(
                      "common.loading",
                    )}
                  />
                </div>
              )}

              <OrdersMetrics
                totalDelivery={
                  totalDelivery
                }
                avgPerHour={
                  avgPerHour
                }
                peakHour={
                  peakHour
                }
                delivers={
                  delivers
                }
                collected={
                  collected
                }
                expired={expired}
              />

              <OrdersTableSection
                orders={orders}
                activeStatus={activeStatus}
                onStatusChange={handleStatusTabChange}
                showFailures={canViewFailures}
                dateRange={dateRange}
                setDateRange={setDateRange}
                offeringFilter={offeringFilter}
                setOfferingFilter={setOfferingFilter}
                search={search}
                setSearch={setSearch}
                onResetFilters={resetTableFilters}
                showQueryControls={
                  supportsOrdersQueryControls(activeStatus)
                }
                sortBy={sortBy || "default"}
                setSortBy={(value) =>
                  setSortBy(value === "default" ? "" : value)
                }
                sortDir={sortDir}
                setSortDir={setSortDir}
                priorityStatus={priorityStatus || "none"}
                setPriorityStatus={(value) =>
                  setPriorityStatus(value === "none" ? "" : value)
                }
                resetOrderQuery={resetOrderQuery}
                serverPagination={
                  activeStatus === "scheduled" ||
                  activeStatus === "canceled" ||
                  activeStatus === "failure"
                    ? undefined
                    : {
                        page,
                        pageSize,
                        total: ordersTotal,
                        totalPages: ordersTotalPages,
                        onPageChange: setPage,
                        onPageSizeChange: (nextPageSize) => {
                          setPageSize(nextPageSize);
                          setPage(1);
                        },
                      }
                }
              />
            </div>
          }
          validationsContent={
            <PendingValidationTable
  validations={validations}
  loading={validationsLoading}
  refreshing={validationsRefreshing}
  error={validationsError}
  onRetry={refetchValidations}
/>
          }
        />
      </div>
    </DashboardLayout>
  );
}
