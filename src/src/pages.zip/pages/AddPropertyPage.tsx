// src/pages/AddPropertyPage.tsx
import { useEffect, useState, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { ChevronLeft, Plus, Save, MapPin, Building2, Trash2, Edit2 } from "lucide-react";
import { companyService } from "@/services/company.service";
import { systemService } from "@/services/system.service";
import { propertiesService } from "@/services/properties.service";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Column } from "@/components/ui/types";
import { GenericTable } from "@/components/ui/GenericTable";
import SelectableMap from "@/components/ui/Selectablemap";

// Tipos
interface PropertyOfferingOperation {
  id_offering_operation: number;
  operation_name: string;
  cost_type: "COMPARTMENT" | "BUSINESS";
}

interface PropertyForm {
  name_propierty: string;
  email: string;
  password: string;
  address: string;
  description: string;
  latitude: string;
  longitude: string;
  id_state: string;
  state: string;
  id_city: string;
  city: string;
  id_status: number;
  by_contract: boolean;
  id_type_urbanization: string;
  id_currency: string;
  request_carrier_code: boolean;
  signature_carrier_require: boolean;
  locker_extension_payment: boolean;
  guest_limit: string;
  id_subscription: string;
  unit_charge: boolean;
  cutoff_day: string;
  payment_deadline: string;
  allow_whats_app_notifs: boolean;
  allow_package_entry_by_photo: boolean;
  schedule_weekdays_from: string;
  schedule_weekdays_to: string;
  schedule_weekend_from: string;
  schedule_weekend_to: string;
  offering_operations: PropertyOfferingOperation[];
}

interface StateOption {
  id: number;
  name: string;
}

interface CityOption {
  id: number;
  name: string;
}

interface UrbanizationType {
  id: number;
  name: string;
}

interface PlanOption {
  id: number;
  name: string;
}

interface CurrencyOption {
  id: number;
  name: string;
}

const CURRENCY_OPTIONS: CurrencyOption[] = [
  { id: 1, name: "USD" },
  { id: 2, name: "MXN" },
]; 
const INITIAL_FORM: PropertyForm = {
  name_propierty: "",
  email: "",
  password: "",
  address: "",
  description: "",
  latitude: "",
  longitude: "",
  id_state: "",
  state: "",
  id_city: "",
  city: "",
  id_status: 1,
  by_contract: true,
  id_type_urbanization: "",
  id_currency: "2", // MXN por default
  request_carrier_code: false,
  signature_carrier_require: false,
  locker_extension_payment: false,
  guest_limit: "",
  id_subscription: "",
  unit_charge: true,
  cutoff_day: "",
  payment_deadline: "",
  allow_whats_app_notifs: false,
  allow_package_entry_by_photo: false,
  schedule_weekdays_from: "09:00",
  schedule_weekdays_to: "23:00",
  schedule_weekend_from: "09:00",
  schedule_weekend_to: "23:00",
  offering_operations: [],
};
// Componente Field reutilizable
function Field({ label, value, onChange, placeholder, required, type = "text", maxLength, error, disabled, icon }: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  required?: boolean;
  type?: string;
  maxLength?: number;
  error?: string;
  disabled?: boolean;
  icon?: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5 w-full">
      <Label className="text-xs font-medium text-foreground">
        {label}{required && <span className="text-destructive ml-0.5">*</span>}
      </Label>
      <div className="relative">
        {icon && (
          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none text-muted-foreground">
            {icon}
          </span>
        )}
        <Input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          maxLength={maxLength}
          disabled={disabled}
          className={`${icon ? "pl-8" : ""} ${error ? "border-destructive" : ""}`}
        />
      </div>
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}

// Componente principal
export default function AddPropertyPage() {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const { id_company } = useParams<{ id_company: string }>();

  const [form, setForm] = useState<PropertyForm>(INITIAL_FORM);
  const [errors, setErrors] = useState<Partial<Record<keyof PropertyForm, string>>>({});
  const [staging, setStaging] = useState<PropertyForm[]>([]);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // Opciones para selects
  const [states, setStates] = useState<StateOption[]>([]);
  const [cities, setCities] = useState<CityOption[]>([]);
  const [urbanizationTypes, setUrbanizationTypes] = useState<UrbanizationType[]>([]);
  const [plans, setPlans] = useState<PlanOption[]>([]);
  const [offeringCatalog, setOfferingCatalog] = useState<PropertyOfferingOperation[]>([]);
  
  // Estados de carga
  const [loadingCities, setLoadingCities] = useState(false);
  const [companyName, setCompanyName] = useState("");
  const [companyLat, setCompanyLat] = useState<number | undefined>(undefined);
  const [companyLng, setCompanyLng] = useState<number | undefined>(undefined);

  // Cargar datos iniciales
  useEffect(() => {
    if (!id_company) {
      toast.error("ID de compañía no encontrado");
      navigate("/company");
      return;
    }
    
    loadInitialData();
    loadCompanyData();
  }, [id_company]);

  const loadInitialData = async () => {
    try {
      setLoading(true);
      
      // Cargar estados
      const statesRes: any = await companyService.getStates();
      if (statesRes?.cities) {
        setStates(statesRes.cities.map((s: any) => ({ id: s.id_state, name: s.state_name })));
      }
      
      // Cargar tipos de urbanización
      const urbanRes: any = await systemService.getTypesUrbanization('es');
      if (urbanRes?.types_urbanization) {
        setUrbanizationTypes(urbanRes.types_urbanization.map((u: any) => ({ 
          id: u.id_type_urbanization, 
          name: u.name_urbanization 
        })));
      }
      
      // Cargar planes (si es necesario)
      const plansRes: any = await systemService.getPlans('es');
      if (plansRes?.all_plans) {
        setPlans(plansRes.all_plans.map((p: any) => ({ 
          id: p.id_subscription, 
          name: p.name_subscription 
        })));
      }
      
      // Catálogo global para asignar offering_operations desde el alta.
      // Droppi Shop (13) permanece fuera del alcance de esta versión.
      try {
        const catalogRes: any = await propertiesService.getChargesCatalog(language);
        const offerings = catalogRes?.result?.offerings;
        if (Array.isArray(offerings)) {
          setOfferingCatalog(
            offerings
              .filter((item: any) => Number(item.id_offering_operation) !== 13)
              .map((item: any) => ({
                id_offering_operation: Number(item.id_offering_operation),
                operation_name: item.operation_name || `Offering #${item.id_offering_operation}`,
                cost_type: "COMPARTMENT" as const,
              }))
          );
        }
      } catch (catalogError) {
        console.warn("Offering catalog unavailable:", catalogError);
      }
    } catch (error) {
      console.error("Error loading initial data:", error);
      toast.error("Error al cargar datos iniciales");
    } finally {
      setLoading(false);
    }
  };

  const loadCompanyData = async () => {
    try {
      const res: any = await companyService.getCompanyId(Number(id_company));
      if (res?.companies?.[0]) {
        const company = res.companies[0];
        setCompanyName(company.company_name);
        setCompanyLat(parseFloat(company.map_lat_center_point));
        setCompanyLng(parseFloat(company.map_length_center_point));
      }
    } catch (error) {
      console.error("Error loading company:", error);
    }
  };

  const loadCities = async (id_state: number) => {
    try {
      setLoadingCities(true);
      const res: any = await companyService.getCity(id_state);
      if (res?.cities) {
        setCities(res.cities.map((c: any) => ({ id: c.id_city, name: c.city })));
      }
    } catch (error) {
      console.error("Error loading cities:", error);
    } finally {
      setLoadingCities(false);
    }
  };

  const setField = (field: keyof PropertyForm, value: any) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const toggleOffering = (offering: PropertyOfferingOperation, enabled: boolean) => {
    setForm((prev) => ({
      ...prev,
      offering_operations: enabled
        ? [...prev.offering_operations, offering]
        : prev.offering_operations.filter(
            (item) => item.id_offering_operation !== offering.id_offering_operation
          ),
    }));
  };

  const updateOfferingCostType = (
    idOfferingOperation: number,
    costType: "COMPARTMENT" | "BUSINESS"
  ) => {
    setForm((prev) => ({
      ...prev,
      offering_operations: prev.offering_operations.map((item) =>
        item.id_offering_operation === idOfferingOperation
          ? { ...item, cost_type: costType }
          : item
      ),
    }));
  };

  const handleLocationSelect = ({ lat, lng, address }: { lat: number; lng: number; address?: string }) => {
    setField("latitude", lat.toFixed(8));
    setField("longitude", lng.toFixed(8));
    if (address) {
      setField("address", address);
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof PropertyForm, string>> = {};
    const requiredMsg = t("validation.required") || "Campo obligatorio";
    
    if (!form.name_propierty.trim()) newErrors.name_propierty = requiredMsg;
    if (!form.email.trim()) newErrors.email = requiredMsg;
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = t("validation.invalidEmail") || "Email inválido";
    }
    if (!form.password.trim()) newErrors.password = requiredMsg;
    if (!form.address.trim()) newErrors.address = requiredMsg;
    if (!form.id_currency) newErrors.id_currency = requiredMsg;
    if (!form.description.trim()) newErrors.description = requiredMsg;
    if (!form.latitude.trim()) newErrors.latitude = requiredMsg;
    if (!form.longitude.trim()) newErrors.longitude = requiredMsg;
    if (!form.id_state) newErrors.id_state = requiredMsg;
    if (!form.id_city) newErrors.id_city = requiredMsg;
    if (!form.id_type_urbanization) newErrors.id_type_urbanization = requiredMsg;
    if (!form.guest_limit.trim()) newErrors.guest_limit = requiredMsg;
    else if (isNaN(Number(form.guest_limit)) || Number(form.guest_limit) < 0) {
      newErrors.guest_limit = "Debe ser un número válido";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAddToList = () => {
    if (!validateForm()) {
      toast.error(t("companyPage.forms.validation.fillAll") || "Completa todos los campos requeridos");
      return;
    }
    
    setStaging((prev) => [...prev, { ...form }]);
    setForm(INITIAL_FORM);
    setCities([]);
    toast.success(t("companyPage.forms.addedToList") || "Propiedad agregada a la lista");
  };

  const handleRemove = (index: number) => {
    setStaging((prev) => prev.filter((_, i) => i !== index));
  };

const handleEdit = (
  property: PropertyForm & { _index?: number },
  index: number
) => {
  const { _index, ...cleanProperty } = property;

  setForm(cleanProperty);
  setStaging((prev) => prev.filter((_, i) => i !== index));

  if (cleanProperty.id_state) {
    loadCities(Number(cleanProperty.id_state));
  }
};

  const handleSaveAll = async () => {
    if (staging.length === 0) {
      toast.error(t("companyPage.forms.emptyList") || "Agrega al menos una propiedad");
      return;
    }
    
    try {
      setSaving(true);
      
      const propertiesToSave = staging.map((property) => {
  const {
    _index,
    id_state,
    state,
    city,
    schedule_weekdays_from,
    schedule_weekdays_to,
    schedule_weekend_from,
    schedule_weekend_to,
    offering_operations,
    ...prop
  } = property as PropertyForm & { _index?: number };

  return {
    ...prop,
    password: prop.password,
    latitude: prop.latitude.toString(),
    longitude: prop.longitude.toString(),
    id_city: Number(prop.id_city),
    id_type_urbanization: Number(prop.id_type_urbanization),
    id_currency: Number(prop.id_currency),
    guest_limit: Number(prop.guest_limit),
    id_subscription: prop.id_subscription
      ? Number(prop.id_subscription)
      : null,
    cutoff_day: prop.cutoff_day
      ? Number(prop.cutoff_day)
      : null,
    payment_deadline: prop.payment_deadline
      ? Number(prop.payment_deadline)
      : null,
    schedule: {
      weekdays: {
        from: schedule_weekdays_from || "09:00",
        to: schedule_weekdays_to || "23:00",
      },
      weekend: {
        from: schedule_weekend_from || "09:00",
        to: schedule_weekend_to || "23:00",
      },
    },
    offering_operations: offering_operations.map(
      ({ id_offering_operation, cost_type }) => ({
        id_offering_operation,
        cost_type,
      })
    ),
  };
});
      
      const response: any = await companyService.postProperties(
        { property: propertiesToSave },
        Number(id_company)
      );

      if (response?.error_data?.length > 0) {
        response.error_data.forEach((err: any) => {
          toast.error(
            `${err.data?.name_propierty || "Propiedad"}: ${
              err.reason || err.err || "Error al guardar"
            }`
          );
        });

        return;
      }
            
      if (response?.result?.mensaje_return?.CODE === 200) {
        toast.success(t("companyPage.forms.savedSuccess") || "Propiedades guardadas correctamente");
        navigate(`/company/${id_company}`);
      } else {
        toast.error(t("common.unexpectedError") || "Error inesperado al guardar");
      }
    } catch (error) {
      console.error("Error saving properties:", error);
      toast.error(t("common.errorSaving") || "Error al guardar las propiedades");
    } finally {
      setSaving(false);
    }
  };

  // Columnas para la tabla de staging
  const stagingColumns: Column<PropertyForm & { _index: number }>[] = [
    {
      key: "name_propierty",
      header: t("companyPage.branchTable.name_propierty") || "Nombre",
      sortable: true,
      render: (row) => <span className="font-medium text-sm">{row.name_propierty}</span>
    },
    {
      key: "address",
      header: t("companyPage.branchTable.address") || "Dirección",
      sortable: false,
      render: (row) => <span className="text-sm text-muted-foreground truncate max-w-[200px] block">{row.address}</span>
    },
    {
      key: "description",
      header: t("companyPage.branchTable.description") || "Descripción",
      sortable: false,
      render: (row) => <span className="text-sm text-muted-foreground truncate max-w-[150px] block">{row.description}</span>
    },
    {
      key: "email",
      header: t("companyPage.forms.company.email") || "Email",
      sortable: false,
      render: (row) => <span className="text-sm">{row.email}</span>
    },
    {
      key: "guest_limit",
      header: t("companyPage.branchTable.guest_limit") || "Límite de invitados",
      sortable: false,
      render: (row) => <span className="text-sm">{row.guest_limit}</span>
    },
    {
      key: "actions",
      header: t("companyPage.table.accion") || "Acciones",
      sortable: false,
      render: (row) => (
        <div className="flex items-center gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8 text-blue-500 hover:bg-blue-50"
            onClick={(e) => { e.stopPropagation(); handleEdit(row, row._index); }}
          >
            <Edit2 className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8 text-destructive hover:bg-destructive/10"
            onClick={(e) => { e.stopPropagation(); handleRemove(row._index); }}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ];

  const mapLat = form.latitude ? parseFloat(form.latitude) : companyLat;
  const mapLng = form.longitude ? parseFloat(form.longitude) : companyLng;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => navigate(`/company/${id_company}`)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          
          <div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground mb-0.5">
              <span 
                className="cursor-pointer hover:text-foreground transition-colors"
                onClick={() => navigate("/company")}
              >
                {t("companyPage.title") || "Compañía"}
              </span>
              <span>/</span>
              <span 
                className="cursor-pointer hover:text-foreground transition-colors"
                onClick={() => navigate(`/company/${id_company}`)}
              >
                {companyName || "..."}
              </span>
              <span>/</span>
              <span className="text-foreground">
                {t("companyPage.add_property") || "Agregar propiedad"}
              </span>
            </div>
            <h1 className="text-xl font-bold font-poppins">
              {t("companyPage.add_property") || "Agregar propiedad"}
            </h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {companyName && `${t("companyPage.forCompany") || "Para"}: ${companyName}`}
            </p>
          </div>
        </div>

        {/* Formulario + Mapa */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          {/* Formulario */}
          <div className="metric-card space-y-4">
            <p className="text-[13px] font-semibold font-poppins text-foreground">
              {t("companyPage.forms.property.sectionTitle") || "Datos de la propiedad"}
            </p>

            {/* Fila 1: Nombre y Email */}
            <div className="grid grid-cols-2 gap-4">
              <Field
                label={t("companyPage.branchTable.name_propierty") || "Nombre de la propiedad"}
                value={form.name_propierty}
                onChange={(v) => setField("name_propierty", v)}
                placeholder={t("companyPage.forms.property.placeholder_name") || "Ej: Torre Principal"}
                required
                maxLength={100}
                error={errors.name_propierty}
                icon={<Building2 className="h-3.5 w-3.5" />}
              />
              <Field
                label={t("companyPage.forms.company.email") || "Email"}
                value={form.email}
                onChange={(v) => setField("email", v)}
                placeholder="propiedad@correo.com"
                required
                type="email"
                error={errors.email}
              />
            </div>

            {/* Fila 2: Contraseña */}
            <div className="grid grid-cols-2 gap-4">
              <Field
                label={t("companyPage.forms.company.password") || "Contraseña"}
                value={form.password}
                onChange={(v) => setField("password", v)}
                placeholder="••••••••"
                required
                type="password"
                error={errors.password}
              />
              <Field
                label={t("companyPage.branchTable.guest_limit") || "Límite de invitados"}
                value={form.guest_limit}
                onChange={(v) => setField("guest_limit", v)}
                placeholder="10"
                required
                type="number"
                error={errors.guest_limit}
              />
            </div>

            {/* Dirección */}
            <Field
              label={t("companyPage.branchTable.address") || "Dirección"}
              value={form.address}
              onChange={(v) => setField("address", v)}
              placeholder="Calle, número, colonia, ciudad"
              required
              maxLength={300}
              error={errors.address}
            />

            {/* Descripción */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-foreground">
                {t("companyPage.branchTable.description") || "Descripción"}
                <span className="text-destructive ml-0.5">*</span>
              </Label>
              <Textarea
                value={form.description}
                onChange={(e) => setField("description", e.target.value)}
                placeholder={t("companyPage.forms.property.placeholder_description") || "Descripción de la propiedad"}
                rows={3}
                className={errors.description ? "border-destructive" : ""}
              />
              {errors.description && <p className="text-xs text-destructive">{errors.description}</p>}
            </div>

            {/* Estado y Ciudad */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-foreground">
                  {t("companyPage.forms.company.state") || "Estado"}
                  <span className="text-destructive ml-0.5">*</span>
                </Label>
                <Select
                  value={form.id_state}
                  onValueChange={(v) => {
                    const state = states.find(s => String(s.id) === v);
                    setField("id_state", v);
                    setField("state", state?.name || "");
                    loadCities(Number(v));
                    setField("id_city", "");
                    setField("city", "");
                  }}
                >
                  <SelectTrigger className={errors.id_state ? "border-destructive" : ""}>
                    <SelectValue placeholder={t("companyPage.forms.company.placeholder_state") || "Seleccionar estado"} />
                  </SelectTrigger>
                  <SelectContent>
                    {states.map(s => (
                      <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.id_state && <p className="text-xs text-destructive">{errors.id_state}</p>}
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-foreground">
                  {t("companyPage.forms.company.city") || "Ciudad"}
                  <span className="text-destructive ml-0.5">*</span>
                </Label>
                <Select
                  value={form.id_city}
                  disabled={!form.id_state || loadingCities}
                  onValueChange={(v) => {
                    const city = cities.find(c => String(c.id) === v);
                    setField("id_city", v);
                    setField("city", city?.name || "");
                  }}
                >
                  <SelectTrigger className={errors.id_city ? "border-destructive" : ""}>
                    <SelectValue placeholder={
                      loadingCities 
                        ? (t("common.loading") || "Cargando...")
                        : (t("companyPage.forms.company.placeholder_city") || "Seleccionar ciudad")
                    } />
                  </SelectTrigger>
                  <SelectContent>
                    {cities.map(c => (
                      <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.id_city && <p className="text-xs text-destructive">{errors.id_city}</p>}
              </div>
            </div>

{/* Tipo de urbanización y moneda */}
<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
  <div className="space-y-1.5">
    <Label className="text-xs font-medium text-foreground">
      {t("companyPage.branchTable.urbanization_type") || "Tipo de urbanización"}
      <span className="text-destructive ml-0.5">*</span>
    </Label>

    <Select
      value={form.id_type_urbanization}
      onValueChange={(v) => setField("id_type_urbanization", v)}
    >
      <SelectTrigger className={errors.id_type_urbanization ? "border-destructive" : ""}>
        <SelectValue
          placeholder={
            t("companyPage.forms.property.placeholder_urbanization") ||
            "Seleccionar tipo"
          }
        />
      </SelectTrigger>

      <SelectContent>
        {urbanizationTypes.map((u) => (
          <SelectItem key={u.id} value={String(u.id)}>
            {u.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>

    {errors.id_type_urbanization && (
      <p className="text-xs text-destructive">
        {errors.id_type_urbanization}
      </p>
    )}
  </div>

  <div className="space-y-1.5">
    <Label className="text-xs font-medium text-foreground">
      {t("companyPage.forms.property.currency") || "Moneda"}
      <span className="text-destructive ml-0.5">*</span>
    </Label>

    <Select
      value={form.id_currency}
      onValueChange={(v) => setField("id_currency", v)}
    >
      <SelectTrigger className={errors.id_currency ? "border-destructive" : ""}>
        <SelectValue placeholder="Seleccionar moneda" />
      </SelectTrigger>

      <SelectContent>
        {CURRENCY_OPTIONS.map((currency) => (
          <SelectItem key={currency.id} value={String(currency.id)}>
            {currency.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>

    {errors.id_currency && (
      <p className="text-xs text-destructive">{errors.id_currency}</p>
    )}
  </div>
</div>

            {/* Configuración inicial de la propiedad */}
            <div className="space-y-4 rounded-xl border border-border bg-muted/20 p-4">
              <div>
                <p className="text-[13px] font-semibold font-poppins text-foreground">
                  Configuración inicial
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Estos campos son opcionales; el backend conserva sus valores por defecto cuando no aplican.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-foreground">
                    Suscripción
                  </Label>
                  <Select
                    value={form.id_subscription || "none"}
                    onValueChange={(value) =>
                      setField("id_subscription", value === "none" ? "" : value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Sin suscripción" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Sin suscripción</SelectItem>
                      {plans.map((plan) => (
                        <SelectItem key={plan.id} value={String(plan.id)}>
                          {plan.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Field
                  label="Día de corte"
                  value={form.cutoff_day}
                  onChange={(value) => setField("cutoff_day", value)}
                  type="number"
                  placeholder="Ej. 15"
                />

                <Field
                  label="Límite de pago"
                  value={form.payment_deadline}
                  onChange={(value) => setField("payment_deadline", value)}
                  type="number"
                  placeholder="Ej. 5"
                />
              </div>

              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <div className="flex items-center justify-between rounded-lg border border-border bg-background px-3 py-2.5">
                  <div>
                    <Label className="cursor-pointer text-xs font-medium text-foreground">
                      Cobro por unidad
                    </Label>
                    <p className="text-[10px] text-muted-foreground">unit_charge</p>
                  </div>
                  <Switch
                    checked={form.unit_charge}
                    onCheckedChange={(checked) => setField("unit_charge", checked)}
                  />
                </div>

                <div className="flex items-center justify-between rounded-lg border border-border bg-background px-3 py-2.5">
                  <div>
                    <Label className="cursor-pointer text-xs font-medium text-foreground">
                      Notificaciones por WhatsApp
                    </Label>
                    <p className="text-[10px] text-muted-foreground">allow_whats_app_notifs</p>
                  </div>
                  <Switch
                    checked={form.allow_whats_app_notifs}
                    onCheckedChange={(checked) =>
                      setField("allow_whats_app_notifs", checked)
                    }
                  />
                </div>

                <div className="flex items-center justify-between rounded-lg border border-border bg-background px-3 py-2.5 md:col-span-2">
                  <div>
                    <Label className="cursor-pointer text-xs font-medium text-foreground">
                      Permitir ingreso de paquetes mediante fotografía
                    </Label>
                    <p className="text-[10px] text-muted-foreground">
                      Habilita photo_delivery para el House Account.
                    </p>
                  </div>
                  <Switch
                    checked={form.allow_package_entry_by_photo}
                    onCheckedChange={(checked) =>
                      setField("allow_package_entry_by_photo", checked)
                    }
                  />
                </div>
              </div>

              <div className="space-y-3">
                <p className="text-xs font-semibold text-foreground">Horario</p>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="rounded-lg border border-border bg-background p-3">
                    <p className="mb-2 text-xs font-medium">Entre semana</p>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <Label className="text-[10px] text-muted-foreground">Desde</Label>
                        <Input
                          type="time"
                          value={form.schedule_weekdays_from}
                          onChange={(event) =>
                            setField("schedule_weekdays_from", event.target.value)
                          }
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-[10px] text-muted-foreground">Hasta</Label>
                        <Input
                          type="time"
                          value={form.schedule_weekdays_to}
                          onChange={(event) =>
                            setField("schedule_weekdays_to", event.target.value)
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="rounded-lg border border-border bg-background p-3">
                    <p className="mb-2 text-xs font-medium">Fin de semana</p>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <Label className="text-[10px] text-muted-foreground">Desde</Label>
                        <Input
                          type="time"
                          value={form.schedule_weekend_from}
                          onChange={(event) =>
                            setField("schedule_weekend_from", event.target.value)
                          }
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-[10px] text-muted-foreground">Hasta</Label>
                        <Input
                          type="time"
                          value={form.schedule_weekend_to}
                          onChange={(event) =>
                            setField("schedule_weekend_to", event.target.value)
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {offeringCatalog.length > 0 && (
              <div className="space-y-3 rounded-xl border border-border p-4">
                <div>
                  <p className="text-[13px] font-semibold font-poppins text-foreground">
                    Servicios iniciales
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Se enviarán dentro de offering_operations al registrar la propiedad.
                  </p>
                </div>

                <div className="space-y-2">
                  {offeringCatalog.map((offering) => {
                    const selected = form.offering_operations.find(
                      (item) =>
                        item.id_offering_operation === offering.id_offering_operation
                    );

                    return (
                      <div
                        key={offering.id_offering_operation}
                        className="flex flex-col gap-3 rounded-lg border border-border bg-muted/20 p-3 sm:flex-row sm:items-center sm:justify-between"
                      >
                        <div className="flex min-w-0 items-center gap-3">
                          <Switch
                            checked={Boolean(selected)}
                            onCheckedChange={(checked) =>
                              toggleOffering(offering, checked)
                            }
                          />
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-foreground">
                              {offering.operation_name}
                            </p>
                            <p className="text-[10px] text-muted-foreground">
                              ID {offering.id_offering_operation}
                            </p>
                          </div>
                        </div>

                        {selected && (
                          <Select
                            value={selected.cost_type}
                            onValueChange={(value) =>
                              updateOfferingCostType(
                                offering.id_offering_operation,
                                value as "COMPARTMENT" | "BUSINESS"
                              )
                            }
                          >
                            <SelectTrigger className="h-8 w-full text-xs sm:w-[170px]">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="COMPARTMENT">COMPARTMENT</SelectItem>
                              <SelectItem value="BUSINESS">BUSINESS</SelectItem>
                            </SelectContent>
                          </Select>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Switches */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs font-medium text-foreground cursor-pointer">
                  {t("companyPage.branchTable.by_contract") || "Por contrato"}
                </Label>
                <Switch
                  checked={form.by_contract}
                  onCheckedChange={(checked) => setField("by_contract", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label className="text-xs font-medium text-foreground cursor-pointer">
                  {t("companyPage.branchTable.request_carrier_code") || "Solicitar código de mensajería"}
                </Label>
                <Switch
                  checked={form.request_carrier_code}
                  onCheckedChange={(checked) => setField("request_carrier_code", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label className="text-xs font-medium text-foreground cursor-pointer">
                  {t("companyPage.branchTable.signature_carrier_require") || "Requerir firma de mensajería"}
                </Label>
                <Switch
                  checked={form.signature_carrier_require}
                  onCheckedChange={(checked) => setField("signature_carrier_require", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label className="text-xs font-medium text-foreground cursor-pointer">
                  {t("companyPage.branchTable.locker_extension_payment") || "Pago de extensión de locker"}
                </Label>
                <Switch
                  checked={form.locker_extension_payment}
                  onCheckedChange={(checked) => setField("locker_extension_payment", checked)}
                />
              </div>
            </div>

            {/* Latitud y Longitud */}
            <div className="grid grid-cols-2 gap-4">
              <Field
                label={t("companyPage.branchTable.latitud") || "Latitud"}
                value={form.latitude}
                onChange={(v) => setField("latitude", v)}
                placeholder="25.74682811"
                required
                error={errors.latitude}
                icon={<MapPin className="h-3.5 w-3.5" />}
              />
              <Field
                label={t("companyPage.branchTable.longitud") || "Longitud"}
                value={form.longitude}
                onChange={(v) => setField("longitude", v)}
                placeholder="-100.351334"
                required
                error={errors.longitude}
                icon={<MapPin className="h-3.5 w-3.5" />}
              />
            </div>

            {/* Botón agregar */}
            <div className="flex justify-end pt-2">
              <Button onClick={handleAddToList} className="gap-2">
                <Plus className="h-4 w-4" />
                {t("companyPage.forms.addToList") || "Agregar a lista"}
              </Button>
            </div>
          </div>

          {/* Mapa */}
          <div className="metric-card p-0 overflow-hidden lg:sticky lg:top-6">
            <div className="px-4 py-3 border-b border-border flex items-center justify-between">
              <p className="text-[13px] font-semibold font-poppins text-foreground">
                {t("companyPage.forms.property.selectLocation") || "Seleccionar ubicación"}
              </p>
              {(form.latitude || companyLat) && (
                <span className="text-xs text-muted-foreground font-mono">
                  {parseFloat(form.latitude || companyLat?.toString() || "0").toFixed(5)}, {" "}
                  {parseFloat(form.longitude || companyLng?.toString() || "0").toFixed(5)}
                </span>
              )}
            </div>

            <div className="h-[520px]">
              <SelectableMap 
                lat={mapLat} 
                lng={mapLng} 
                onLocationSelect={handleLocationSelect}
              />
            </div>

            <div className="px-4 py-2 border-t border-border bg-muted/30">
              <p className="text-xs text-muted-foreground text-center">
                {t("companyPage.forms.property.clickMapHint") || "Haz clic en el mapa para seleccionar la ubicación de la propiedad"}
              </p>
            </div>
          </div>
        </div>

        {/* Tabla de propiedades en staging */}
        {staging.length > 0 && (
          <div className="space-y-4">
            <p className="text-[13px] font-semibold font-poppins text-foreground">
              {t("companyPage.forms.stagingTitle") || "Propiedades por guardar"}
              <span className="text-secondary ml-2">{staging.length}</span>
            </p>

            <GenericTable
              data={staging.map((prop, i) => ({ ...prop, _index: i }))}
              columns={stagingColumns as any}
              enableSearch={false}
              enableDateRange={false}
            />

            <div className="flex justify-end gap-3">
              <Button 
                variant="outline" 
                onClick={() => navigate(`/company/${id_company}`)} 
                disabled={saving}
              >
                {t("common.cancel") || "Cancelar"}
              </Button>
              <Button onClick={handleSaveAll} disabled={saving} className="gap-2">
                {saving ? (
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                {saving 
                  ? (t("common.saving") || "Guardando...")
                  : `${t("companyPage.forms.saveAll") || "Guardar"} ${staging.length} ${staging.length > 1 ? (t("companyPage.forms.properties") || "propiedades") : (t("companyPage.forms.property_singular") || "propiedad")}`
                }
              </Button>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}