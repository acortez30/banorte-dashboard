// pages/TicketsOLCDetail.tsx
import { useNavigate, useParams } from "react-router-dom";
import {
  useState,
  useEffect,
  useCallback,
  useRef,
  useMemo,
} from "react";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { TicketHeader } from "@/components/ticket-details/TicketHeader";

import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";

import { AlertTriangle, Send, CheckCircle2, Loader2, Pencil } from "lucide-react";

import { olcTicketsService } from "@/services/olc-tickets.service";

import { Button } from "@/components/ui/button";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import type {
  OLCTicketDetail,
  OLCTicketMessage,
  OLCTicketStatus,
  OLCTicketPriority,
} from "@/types/olc-tickets.types";

// ─────────────────────────────────────────────────────────────
// Config (idealmente moverlo a lib/olc-tickets-config.ts)
// ─────────────────────────────────────────────────────────────

const POLLING_INTERVAL_MS = 30_000; // 30 segundos

type StatusConfigItem = { label: string; className: string; id: number };
type PriorityConfigItem = { label: string; className: string; id: number };

const statusConfig: Record<OLCTicketStatus, StatusConfigItem> = {
  open: {
    label: "ABIERTO",
    className: "bg-accent/10 text-accent border-accent/20",
    id: 166, // TODO: confirmar IDs reales con backend
  },
  in_progress: {
    label: "EN CURSO",
    className: "bg-secondary text-secondary-foreground border-border",
    id: 167,
  },
  resolved: {
    label: "RESUELTO",
    className: "bg-success text-success-foreground border-border",
    id: 169,
  },
  closed: {
    label: "CERRADO",
    className: "bg-muted text-muted-foreground",
    id: 170,
  },
};

const priorityConfig: Record<OLCTicketPriority, PriorityConfigItem> = {
  low: {
    label: "BAJA",
    className: "bg-muted text-muted-foreground text-xs px-2 py-1 rounded",
    id: 1,
  },
  medium: {
    label: "MEDIA",
    className: "bg-warning/10 text-warning text-xs px-2 py-1 rounded",
    id: 2,
  },
  high: {
    label: "ALTA",
    className: "bg-destructive/10 text-destructive text-xs px-2 py-1 rounded",
    id: 3,
  },
  critical: {
    label: "CRÍTICA",
    className:
      "bg-destructive text-destructive-foreground text-xs px-2 py-1 rounded",
    id: 4,
  },
};

const normalizeStatusName = (name: string): string =>
  name?.trim().toUpperCase().replace(/\s+/g, "_") ?? "";

const statusMap: Record<string, OLCTicketStatus> = {
  ABIERTO: "open",
  EN_CURSO: "in_progress",
  RESUELTO: "resolved",
  CERRADO: "closed",
};

const priorityMap: Record<string, OLCTicketPriority> = {
  BAJA: "low",
  MEDIA: "medium",
  ALTA: "high",
  CRITICA: "critical",
  CRÍTICA: "critical",
};

const formatRelativeDate = (dateStr: string): string => {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDays = Math.floor(diffHr / 24);

  if (diffMin < 1) return "ahora";
  if (diffMin < 60) return `hace ${diffMin} min`;
  if (diffHr < 24) return `hace ${diffHr} h`;
  if (diffDays < 7) return `hace ${diffDays} d`;
  return date.toLocaleString("es-MX");
};

type UpdatingField = "status" | "priority" | "resolve" | null;

// ─────────────────────────────────────────────────────────────
// Component
// ─────────────────────────────────────────────────────────────

export default function TicketsOLCDetail() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { id } = useParams<{ id: string }>();

  const [ticket, setTicket] = useState<OLCTicketDetail | null>(null);
  const [messages, setMessages] = useState<OLCTicketMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdatedAt, setLastUpdatedAt] = useState<Date | null>(null);
  const [isPolling, setIsPolling] = useState(false);

  const [messageText, setMessageText] = useState("");
  const [sendingMessage, setSendingMessage] = useState(false);
  const [messageError, setMessageError] = useState<string | null>(null);

  const [updatingField, setUpdatingField] = useState<UpdatingField>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // V3 edit dialog
  const [editOpen, setEditOpen] = useState(false);
  const [editTitle, setEditTitle] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editSlaAtRisk, setEditSlaAtRisk] = useState(false);
  const [savingEdit, setSavingEdit] = useState(false);

  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const pollingTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Refs para que el polling lea siempre el último valor sin re-crear el efecto
  const isBusyRef = useRef(false);
  const messageTextRef = useRef("");

  useEffect(() => {
    isBusyRef.current =
      sendingMessage || updatingField !== null || savingEdit;
  }, [sendingMessage, updatingField, savingEdit]);

  useEffect(() => {
    messageTextRef.current = messageText;
  }, [messageText]);

  // ─── Fetch (initial vs background) ────────────────────────

  const fetchTicket = useCallback(
    async (mode: "initial" | "background" = "initial") => {
      if (!id) {
        setError("Ticket ID not found");
        setLoading(false);
        return;
      }

      const isBackground = mode === "background";

      try {
        if (isBackground) {
          setIsPolling(true);
        } else {
          setError(null);
        }

        const response = await olcTicketsService.getTicketWithMessages(id);

        if (response?.ticket) {
          setTicket(response.ticket);
          setMessages(response.messages || []);
          setLastUpdatedAt(new Date());
        } else if (!isBackground) {
          setError("Ticket not found");
        }
      } catch (err) {
        // En background, fallar silenciosamente: no rompemos la UI por un poll
        if (!isBackground) {
          const msg =
            err instanceof Error ? err.message : "Error loading ticket";
          setError(msg);
          console.error("Error fetching OLC ticket:", err);
        } else {
          console.warn("Background poll failed (silent):", err);
        }
      } finally {
        if (isBackground) {
          setIsPolling(false);
        } else {
          setLoading(false);
        }
      }
    },
    [id]
  );

  // Carga inicial
  useEffect(() => {
    fetchTicket("initial");
  }, [fetchTicket]);

  // ─── Derived UI values ────────────────────────────────────

  const uiStatus = useMemo<OLCTicketStatus>(
    () =>
      ticket
        ? statusMap[normalizeStatusName(ticket.nombre_status)] ?? "open"
        : "open",
    [ticket]
  );

  const uiPriority = useMemo<OLCTicketPriority>(
    () =>
      ticket
        ? priorityMap[ticket.priority_name?.toUpperCase()] ?? "low"
        : "low",
    [ticket]
  );

  const isResolved = uiStatus === "resolved" || uiStatus === "closed";

  // ─── Polling cada 30s ─────────────────────────────────────

  useEffect(() => {
    // No iniciar polling si todavía no cargó la primera vez o el ticket está cerrado
    if (loading || !ticket || isResolved) {
      return;
    }

    const tick = () => {
      // Saltar si la pestaña está oculta
      if (document.visibilityState !== "visible") return;
      // Saltar si el usuario está en medio de algo
      if (isBusyRef.current) return;
      fetchTicket("background");
    };

    pollingTimerRef.current = setInterval(tick, POLLING_INTERVAL_MS);

    // Refresh inmediato cuando la pestaña vuelve a estar visible
    const handleVisibilityChange = () => {
      if (
        document.visibilityState === "visible" &&
        !isBusyRef.current
      ) {
        fetchTicket("background");
      }
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);

    return () => {
      if (pollingTimerRef.current) {
        clearInterval(pollingTimerRef.current);
        pollingTimerRef.current = null;
      }
      document.removeEventListener(
        "visibilitychange",
        handleVisibilityChange
      );
    };
  }, [loading, ticket, isResolved, fetchTicket]);

  // ─── Auto-scroll inteligente ──────────────────────────────

  // Hacer scroll al fondo solo si el usuario ya estaba cerca del fondo,
  // así no le movemos la vista si estaba leyendo mensajes viejos.
  const prevMessagesLengthRef = useRef(messages.length);
  useEffect(() => {
    const grew = messages.length > prevMessagesLengthRef.current;
    prevMessagesLengthRef.current = messages.length;

    if (!grew) return;

    const container = messagesContainerRef.current;
    if (!container) return;

    const distanceFromBottom =
      container.scrollHeight - container.scrollTop - container.clientHeight;

    // Si está a menos de 150px del fondo, lo bajamos. Si está más arriba (leyendo), no.
    if (distanceFromBottom < 150) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages.length]);

  // ─── Handlers ─────────────────────────────────────────────

  const handleSendMessage = async () => {
    const trimmed = messageText.trim();
    if (!trimmed || !id) return;

    setSendingMessage(true);
    setMessageError(null);

    const optimisticId = Date.now();
    const optimisticMsg: OLCTicketMessage = {
      id_olc_ticket_message: optimisticId,
      message: trimmed,
      sent_at: new Date().toISOString(),
      registration_date: new Date().toISOString(),
      id_user: (user as any)?.id_user ?? 0,
      sender_name: (user as any)?.name ?? "Tú",
      sender_email: (user as any)?.email ?? "",
      id_user_type: 0,
      sender_type: "OLC",
    };
    setMessages((prev) => [...prev, optimisticMsg]);
    setMessageText("");

    try {
      const response = await olcTicketsService.sendMessage(id, trimmed);
      if (response?.messages) {
        setMessages(response.messages);
        setLastUpdatedAt(new Date());
      }
    } catch (err) {
      setMessages((prev) =>
        prev.filter((m) => m.id_olc_ticket_message !== optimisticId)
      );
      setMessageText(trimmed);
      const msg = err instanceof Error ? err.message : "Error sending message";
      setMessageError(msg);
      console.error("Error sending message:", err);
    } finally {
      setSendingMessage(false);
    }
  };

  const handleMessageKeyDown = (
    e: React.KeyboardEvent<HTMLTextAreaElement>
  ) => {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleStatusChange = async (newStatus: OLCTicketStatus) => {
    if (!id || newStatus === uiStatus) return;
    setUpdatingField("status");
    setActionError(null);
    try {
      await olcTicketsService.updateTicketStatus(
        id,
        statusConfig[newStatus].id
      );
      await fetchTicket("initial");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Error updating status";
      setActionError(msg);
    } finally {
      setUpdatingField(null);
    }
  };

  const handlePriorityChange = async (newPriority: OLCTicketPriority) => {
    if (!id || newPriority === uiPriority) return;
    setUpdatingField("priority");
    setActionError(null);
    try {
      await olcTicketsService.updateTicketPriority(
        id,
        priorityConfig[newPriority].id
      );
      await fetchTicket("initial");
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : "Error updating priority";
      setActionError(msg);
    } finally {
      setUpdatingField(null);
    }
  };

  const handleResolve = async () => {
    if (!id) return;
    setUpdatingField("resolve");
    setActionError(null);
    try {
      await olcTicketsService.resolveTicket(id);
      await fetchTicket("initial");
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : "Error resolving ticket";
      setActionError(msg);
    } finally {
      setUpdatingField(null);
    }
  };

  const handleOpenEdit = () => {
    if (!ticket) return;

    setEditTitle(ticket.title || "");
    setEditDescription(ticket.description || "");
    setEditSlaAtRisk(ticket.sla_at_risk === 1);
    setActionError(null);
    setEditOpen(true);
  };

  const handleSaveEdit = async () => {
    if (!id || !ticket) return;

    const title = editTitle.trim();
    const description = editDescription.trim();

    if (!title) {
      setActionError("El título del ticket es obligatorio.");
      return;
    }

    setSavingEdit(true);
    setActionError(null);

    try {
      await olcTicketsService.updateTicket(id, {
        title,
        description,
        sla_at_risk: editSlaAtRisk,
      });

      setEditOpen(false);
      await fetchTicket("initial");
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : "Error updating ticket";
      setActionError(msg);
    } finally {
      setSavingEdit(false);
    }
  };

  // ─── Render guards ────────────────────────────────────────

  if (loading) {
    return (
      <DashboardLayout>
        <LoadingSpinner fullPage text={t("common.loading")} />
      </DashboardLayout>
    );
  }

  if (error || !ticket) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <p className="text-destructive">{error || "Ticket not found"}</p>
            <Button
              className="mt-4"
              variant="outline"
              onClick={() => navigate("/tickets-olc")}
              aria-label={t("olc.back") || "Back to tickets list"}
            >
              {t("olc.back") || "Back"}
            </Button>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  // ─── Render ───────────────────────────────────────────────

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <TicketHeader
          ticket={{
            id: ticket.ticket_code,
            title: ticket.title,
            status: uiStatus,
          }}
          statusConfig={statusConfig}
          currentModel="olc"
          navigate={() => navigate("/tickets-olc")}
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Description */}
            <section className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-lg font-semibold mb-4">
                {t("olc.description") || "Description"}
              </h2>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                {ticket.description ||
                  t("olc.noDescription") ||
                  "No description available"}
              </p>
            </section>

            {/* Messages */}
            <section className="bg-card border border-border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold">
                  {t("olc.messages") || "Messages"} ({messages.length})
                </h2>
                {isPolling && (
                  <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Loader2 className="h-3 w-3 animate-spin" />
                    {t("olc.refreshing") || "Actualizando..."}
                  </span>
                )}
              </div>

              <div
                ref={messagesContainerRef}
                className="space-y-3 mb-6 max-h-96 overflow-y-auto pr-2"
                aria-live="polite"
                aria-label={t("olc.messages") || "Messages"}
              >
                {messages.length > 0 ? (
                  messages.map((msg) => {
                    const isMine =
                      msg.id_user === (user as any)?.id_user;
                    return (
                      <div
                        key={msg.id_olc_ticket_message}
                        className={`border-l-2 pl-4 py-2 rounded-r ${
                          isMine
                            ? "border-primary bg-primary/5"
                            : "border-muted bg-muted/30"
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <div>
                            <p className="text-sm font-semibold">
                              {msg.sender_name}
                              {isMine && (
                                <span className="ml-2 text-xs text-muted-foreground font-normal">
                                  ({t("olc.you") || "tú"})
                                </span>
                              )}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {msg.sender_type}
                            </p>
                          </div>
                          <span
                            className="text-xs text-muted-foreground"
                            title={new Date(msg.sent_at).toLocaleString()}
                          >
                            {formatRelativeDate(msg.sent_at)}
                          </span>
                        </div>
                        <p className="text-sm whitespace-pre-wrap">
                          {msg.message}
                        </p>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-8">
                    {t("olc.noMessages") || "No messages yet"}
                  </p>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Input */}
              <div className="space-y-3 border-t border-border pt-4">
                <Textarea
                  placeholder={
                    t("olc.typeMessage") ||
                    "Type your message... (Cmd/Ctrl + Enter to send)"
                  }
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  onKeyDown={handleMessageKeyDown}
                  disabled={sendingMessage || isResolved}
                  className="min-h-24"
                />

                {messageError && (
                  <p className="text-xs text-destructive">{messageError}</p>
                )}

                {isResolved && (
                  <p className="text-xs text-muted-foreground italic">
                    {t("olc.ticketClosedHint") ||
                      "Este ticket está cerrado. Reábrelo para enviar mensajes."}
                  </p>
                )}

                <Button
                  onClick={handleSendMessage}
                  disabled={
                    !messageText.trim() || sendingMessage || isResolved
                  }
                  className="w-full"
                >
                  {sendingMessage ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4 mr-2" />
                  )}
                  {sendingMessage
                    ? t("olc.sending") || "Sending..."
                    : t("olc.send") || "Send"}
                </Button>
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <aside className="bg-card border border-border rounded-lg p-6 h-fit space-y-6">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="text-lg font-semibold">
                  {t("olc.details") || "Details"}
                </h2>
                {lastUpdatedAt && (
                  <span
                    className="text-[10px] text-muted-foreground"
                    title={lastUpdatedAt.toLocaleString()}
                  >
                    {t("olc.updated") || "Actualizado"}{" "}
                    {formatRelativeDate(lastUpdatedAt.toISOString())}
                  </span>
                )}
              </div>

              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleOpenEdit}
                disabled={savingEdit || updatingField !== null}
                className="shrink-0"
              >
                <Pencil className="h-4 w-4 mr-2" />
                {t("olc.editTicket") || "Editar"}
              </Button>
            </div>

            {actionError && (
              <div className="bg-destructive/10 border border-destructive/20 rounded p-3">
                <p className="text-xs text-destructive">{actionError}</p>
              </div>
            )}

            {/* Status (editable) */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2">
                {t("olc.status") || "Status"}
              </p>
              <Select
                value={uiStatus}
                onValueChange={(v) =>
                  handleStatusChange(v as OLCTicketStatus)
                }
                disabled={updatingField !== null}
              >
                <SelectTrigger className="w-full">
                  <SelectValue>
                    <Badge className={statusConfig[uiStatus].className}>
                      {statusConfig[uiStatus].label}
                    </Badge>
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {(Object.keys(statusConfig) as OLCTicketStatus[]).map(
                    (k) => (
                      <SelectItem key={k} value={k}>
                        {statusConfig[k].label}
                      </SelectItem>
                    )
                  )}
                </SelectContent>
              </Select>
            </div>

            {/* Priority (editable) */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2">
                {t("olc.priority") || "Priority"}
              </p>
              <Select
                value={uiPriority}
                onValueChange={(v) =>
                  handlePriorityChange(v as OLCTicketPriority)
                }
                disabled={updatingField !== null}
              >
                <SelectTrigger className="w-full">
                  <SelectValue>
                    <Badge
                      variant="outline"
                      className={priorityConfig[uiPriority].className}
                    >
                      {priorityConfig[uiPriority].label}
                    </Badge>
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {(Object.keys(priorityConfig) as OLCTicketPriority[]).map(
                    (k) => (
                      <SelectItem key={k} value={k}>
                        {priorityConfig[k].label}
                      </SelectItem>
                    )
                  )}
                </SelectContent>
              </Select>
            </div>

            {/* Category */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2">
                {t("olc.category") || "Category"}
              </p>
              <p className="text-sm">{ticket.category_name}</p>
            </div>

            {/* Origin */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2">
                {t("olc.origin") || "Origin"}
              </p>
              <p className="text-sm">{ticket.origin_name}</p>
            </div>

            {/* Assigned User */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2">
                {t("olc.assignee") || "Assigned To"}
              </p>
              <p className="text-sm">{ticket.assigned_user_name}</p>
              {ticket.assigned_user_email && (
                <p className="text-xs text-muted-foreground break-all">
                  {ticket.assigned_user_email}
                </p>
              )}
            </div>

            {/* Hub */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2">
                {t("olc.hub") || "Hub"}
              </p>
              <p className="text-sm">{ticket.hub_name}</p>
              <p className="text-xs text-muted-foreground">{ticket.hub_code}</p>
            </div>

            {/* Dates */}
            <div className="border-t border-border pt-4 space-y-4">
              <div>
                <p className="text-xs font-semibold text-muted-foreground mb-1">
                  {t("olc.created") || "Created"}
                </p>
                <p
                  className="text-xs"
                  title={new Date(ticket.registration_date).toLocaleString()}
                >
                  {formatRelativeDate(ticket.registration_date)}
                </p>
              </div>

              <div>
                <p className="text-xs font-semibold text-muted-foreground mb-1">
                  {t("olc.lastUpdate") || "Last Update"}
                </p>
                <p
                  className="text-xs"
                  title={new Date(ticket.update_date).toLocaleString()}
                >
                  {formatRelativeDate(ticket.update_date)}
                </p>
              </div>

              {ticket.resolved_at && (
                <div>
                  <p className="text-xs font-semibold text-muted-foreground mb-1">
                    {t("olc.resolved") || "Resolved"}
                  </p>
                  <p
                    className="text-xs"
                    title={new Date(ticket.resolved_at).toLocaleString()}
                  >
                    {formatRelativeDate(ticket.resolved_at)}
                  </p>
                </div>
              )}
            </div>

            {/* SLA Risk */}
            {ticket.sla_at_risk === 1 && !isResolved && (
              <div className="bg-destructive/10 border border-destructive/20 rounded p-3">
                <p className="text-xs font-semibold text-destructive">
                  ⚠️ {t("olc.slaAtRisk") || "SLA en riesgo"}
                </p>
              </div>
            )}

            {/* Resolve action */}
            {!isResolved && (
              <Button
                onClick={handleResolve}
                disabled={updatingField !== null}
                variant="default"
                className="w-full"
              >
                {updatingField === "resolve" ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <CheckCircle2 className="h-4 w-4 mr-2" />
                )}
                {t("olc.resolveTicket") || "Resolver ticket"}
              </Button>
            )}
          </aside>
        </div>
      </div>
    </DashboardLayout>
  );
}