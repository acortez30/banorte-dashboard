import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";

const models = [
  { key: "box", path: "/box" },
  { key: "home", path: "/home" },
  { key: "work", path: "/home" },
];

export default function ModelSelect() {
  const navigate = useNavigate();
  const { t } = useLanguage();

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center p-6"
      style={{ background: "linear-gradient(180deg, hsl(var(--gradient-sidebar-from)) 0%, hsl(var(--gradient-sidebar-to)) 100%)" }}
    >
      <h1 className="text-3xl font-bold font-poppins text-white mb-2">Droppi</h1>
      <p className="text-white/70 font-inter text-sm mb-10">{t("model.selectDesc")}</p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 w-full max-w-3xl">
        {models.map((m) => (
          <button
            key={m.key}
            onClick={() => navigate(m.path)}
            className="group rounded-2xl bg-white/10 border border-white/15 backdrop-blur-sm p-8 hover:bg-white/20 transition-all duration-200 flex flex-col items-center gap-4"
          >
            <div className="h-16 w-16 rounded-2xl bg-white/15 flex items-center justify-center">
              <span className="text-2xl font-bold font-poppins text-white">
                {m.key[0].toUpperCase()}
              </span>
            </div>
            <div className="text-center">
              <p className="text-lg font-semibold font-poppins text-white">
                {t(`model.${m.key}`)}
              </p>
              <p className="text-xs font-inter text-white/60 mt-1">
                {t(`model.${m.key}Desc`)}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
