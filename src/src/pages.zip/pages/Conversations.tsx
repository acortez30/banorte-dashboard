import { useEffect, useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

type Conversation = {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
};

function formatTimeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "Ahora";
  if (mins < 60) return `Hace ${mins}m`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `Hace ${hours}h`;
  const days = Math.floor(hours / 24);
  return `Hace ${days}d`;
}

export default function Conversations() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [search, setSearch] = useState("");
  const navigate = useNavigate();

  const fetchAll = useCallback(async () => {
    // const { data } = await supabase
    //   .from("conversations")
    //   .select("*")
    //   .order("updated_at", { ascending: false });
    // if (data) setConversations(data as unknown as Conversation[]);
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const filtered = conversations.filter((c) =>
    c.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-xl font-bold font-poppins text-foreground">Todas las conversaciones</h1>
          <Button variant="outline" size="sm" className="font-inter text-xs" onClick={() => navigate("/")}>
            ← Volver
          </Button>
        </div>
        <Input
          placeholder="Buscar conversación..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="mb-4 font-inter text-sm"
        />
        {filtered.length === 0 ? (
          <p className="text-sm text-muted-foreground font-inter text-center py-8">No hay conversaciones</p>
        ) : (
          <div className="space-y-2">
            {filtered.map((conv) => (
              <div
                key={conv.id}
                onClick={() => navigate(`/?chat=${conv.id}`)}
                className="rounded-xl bg-card border border-border p-4 hover:shadow-md hover:-translate-y-0.5 transition-all cursor-pointer flex items-center"
              >
                <div className="w-[2px] h-8 shrink-0 rounded-full mr-3" style={{ background: "linear-gradient(180deg, hsl(var(--gradient-sidebar-from)), hsl(var(--primary)))" }} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold font-poppins text-foreground truncate">{conv.title}</p>
                </div>
                <span className="text-[11px] text-muted-foreground font-inter shrink-0 ml-3">
                  {formatTimeAgo(conv.updated_at)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
