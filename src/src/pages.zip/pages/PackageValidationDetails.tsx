import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Download,
  Expand,
  ImageOff,
  Loader2,
  RefreshCw,
  RotateCcw,
  SearchCheck,
  TriangleAlert,
  UserCheck,
} from "lucide-react";
import {
  useNavigate,
  useParams,
} from "react-router-dom";
import { toast } from "sonner";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";
import {
  buildVisionPackageResolutionPayload,
  createPackageValidationFormData,
  extractVisionPackageApiItems,
  extractVisionPackageDetail,
  getCurrentUserDisplayName,
  getPackageDisplayTracking,
  getPackageDoorLabel,
  mapDetailAvailableUsers,
  mapVisionPackage,
  mapVisionPackageDetail,
  normalizeValidationStatus,
} from "@/mappers/package-validation.mapper";
import { packageService } from "@/services/package.service";
import type {
  PackageValidation,
  PackageValidationFormData,
  ValidationUserOption,
  VisionAssignmentStatus,
} from "@/types/package-validation";

type EditableField =
  keyof PackageValidationFormData;

interface ValidationFieldProps {
  label: string;
  value: string;
  placeholder: string;
  missingMessage: string;
  multiline?: boolean;
  onChange: (value: string) => void;
}

interface InformationItemProps {
  label: string;
  value:
    | string
    | number
    | null
    | undefined;
  className?: string;
}

interface InformationCardProps {
  title: string;
  children: React.ReactNode;
}

const EMPTY_FORM: PackageValidationFormData = {
  carrier: "",
  tracking: "",
  recipient: "",
  phone: "",
  sender: "",
  address: "",
  unit: "",
};

function safeNumber(
  value: unknown
): number | null {
  const parsed = Number(value);

  return Number.isFinite(parsed) &&
    parsed > 0
    ? parsed
    : null;
}

function getCachedValidation(
  idPackage: string | undefined
): PackageValidation | null {
  if (!idPackage) {
    return null;
  }

  const cacheKey =
    `vision-package:${idPackage}`;

  try {
    const raw =
      sessionStorage.getItem(cacheKey);

    if (!raw) {
      return null;
    }

    const parsed = JSON.parse(
      raw
    ) as PackageValidation & {
      assignment_status?:
        VisionAssignmentStatus;
    };

    if (!parsed?.idPackage) {
      sessionStorage.removeItem(cacheKey);
      return null;
    }

    const status =
      normalizeValidationStatus(
        parsed.status ??
          parsed.assignment_status,
        {
          needsReview:
            parsed.needsReview,
          isDefaultUser:
            parsed.currentUser
              ?.is_default_user,
          imageIssue:
            parsed.imageIssue,
        }
      );

    const normalized: PackageValidation = {
      ...parsed,
      status,
      images: Array.isArray(parsed.images)
        ? parsed.images
        : [],
      candidates: Array.isArray(
        parsed.candidates
      )
        ? parsed.candidates
        : [],
    };

    sessionStorage.setItem(
      cacheKey,
      JSON.stringify(normalized)
    );

    return normalized;
  } catch (error) {
    console.warn(
      "Unable to read cached vision package:",
      error
    );

    sessionStorage.removeItem(cacheKey);
    return null;
  }
}

function ValidationField({
  label,
  value,
  placeholder,
  missingMessage,
  multiline = false,
  onChange,
}: ValidationFieldProps) {
  const missing =
    value.trim().length === 0;

  return (
    <div className="space-y-1.5">
      <label className="text-xs font-medium">
        {label}
      </label>

      {multiline ? (
        <Textarea
          value={value}
          onChange={(event) =>
            onChange(event.target.value)
          }
          placeholder={placeholder}
          className={cn(
            "min-h-[92px] resize-none",
            missing &&
              "border-amber-400 bg-amber-50/50 focus-visible:ring-amber-400 dark:bg-amber-950/15"
          )}
        />
      ) : (
        <Input
          value={value}
          onChange={(event) =>
            onChange(event.target.value)
          }
          placeholder={placeholder}
          className={cn(
            missing &&
              "border-amber-400 bg-amber-50/50 focus-visible:ring-amber-400 dark:bg-amber-950/15"
          )}
        />
      )}

      {missing && (
        <p className="flex items-center gap-1.5 text-xs text-amber-700 dark:text-amber-300">
          <TriangleAlert className="h-3.5 w-3.5 shrink-0" />
          {missingMessage}
        </p>
      )}
    </div>
  );
}

function InformationItem({
  label,
  value,
  className,
}: InformationItemProps) {
  const displayValue =
    value === null ||
    value === undefined ||
    value === ""
      ? "---"
      : String(value);

  return (
    <div className={className}>
      <p className="text-xs font-semibold text-foreground">
        {label}
      </p>

      <p className="mt-1 break-words text-sm text-muted-foreground">
        {displayValue}
      </p>
    </div>
  );
}

function InformationCard({
  title,
  children,
}: InformationCardProps) {
  return (
    <section className="rounded-xl border bg-card p-4 shadow-sm">
      <h2 className="mb-4 text-sm font-semibold">
        {title}
      </h2>

      {children}
    </section>
  );
}

function getStatusBannerClass(
  status: VisionAssignmentStatus
) {
  switch (status) {
    case "IMAGE_ISSUE":
      return "border-red-300 bg-red-50 text-red-950 dark:border-red-900 dark:bg-red-950/25 dark:text-red-100";

    case "REVIEW":
      return "border-blue-300 bg-blue-50 text-blue-950 dark:border-blue-900 dark:bg-blue-950/25 dark:text-blue-100";

    case "UNASSIGNED":
      return "border-amber-300 bg-amber-50 text-amber-950 dark:border-amber-900 dark:bg-amber-950/25 dark:text-amber-100";

    case "ASSIGNED":
      return "border-emerald-300 bg-emerald-50 text-emerald-950 dark:border-emerald-900 dark:bg-emerald-950/25 dark:text-emerald-100";
  }
}

export default function PackageValidationDetails() {
  const { t, language } =
    useLanguage();

  const navigate = useNavigate();

  const { validationId } =
    useParams<{
      validationId: string;
    }>();

  const cachedValidation =
    useMemo(
      () =>
        getCachedValidation(
          validationId
        ),
      [validationId]
    );

  const [validation, setValidation] =
    useState<PackageValidation | null>(
      cachedValidation
    );

  const [form, setForm] =
    useState<PackageValidationFormData>(
      cachedValidation
        ? createPackageValidationFormData(
            cachedValidation
          )
        : EMPTY_FORM
    );

  const [users, setUsers] =
    useState<ValidationUserOption[]>([]);

  const [
    selectedUserId,
    setSelectedUserId,
  ] = useState<number>(
    cachedValidation &&
      !cachedValidation.currentUser
        .is_default_user
      ? cachedValidation.currentUser
          .id_user
      : 0
  );

  const [loading, setLoading] =
    useState(!cachedValidation);

  const [
    loadingUsers,
    setLoadingUsers,
  ] = useState(false);

  const [saving, setSaving] =
    useState(false);

  const [loadError, setLoadError] =
    useState<Error | null>(null);

  const [activeImage, setActiveImage] =
    useState(0);

  const [rotation, setRotation] =
    useState(0);

  const [imageFailed, setImageFailed] =
    useState(false);

  const imageContainerRef =
    useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setValidation(cachedValidation);

    setForm(
      cachedValidation
        ? createPackageValidationFormData(
            cachedValidation
          )
        : EMPTY_FORM
    );

    setUsers([]);

    setSelectedUserId(
      cachedValidation &&
        !cachedValidation.currentUser
          .is_default_user
        ? cachedValidation.currentUser
            .id_user
        : 0
    );

    setActiveImage(0);
    setRotation(0);
    setImageFailed(false);
    setLoadError(null);
  }, [
    cachedValidation,
    validationId,
  ]);

  const loadPackage =
    useCallback(async () => {
      const idPackage =
        safeNumber(validationId);

      if (!idPackage) {
        setLoadError(
          new Error(
            t(
              "orders.validation.details.invalidPackageId"
            )
          )
        );

        setLoading(false);
        return;
      }

      setLoading(true);
      setLoadingUsers(true);

      try {
        const [
          detailResult,
          trayResult,
        ] = await Promise.allSettled([
          packageService.getMetadataLabel(
            idPackage,
            language
          ),

          packageService.getVisionPackages({
            language,
          }),
        ]);

        if (
          detailResult.status ===
          "rejected"
        ) {
          throw detailResult.reason;
        }

        const detail =
          extractVisionPackageDetail(
            detailResult.value
          );

        if (!detail) {
          throw new Error(
            t(
              "orders.validation.details.invalidResponse"
            )
          );
        }

        let baseValidation =
          cachedValidation;

        if (
          trayResult.status ===
          "fulfilled"
        ) {
          const trayItem =
            extractVisionPackageApiItems(
              trayResult.value
            ).find(
              (item) =>
                Number(
                  item.id_package
                ) === idPackage
            );

          if (trayItem) {
            baseValidation =
              mapVisionPackage(
                trayItem
              );
          }
        } else {
          console.warn(
            "Unable to load vision package tray:",
            trayResult.reason
          );
        }

        const mapped =
          mapVisionPackageDetail(
            detail,
            baseValidation
          );

        const availableUsers =
          mapDetailAvailableUsers(
            detail.available_users
          );

        setValidation(mapped);
        setUsers(availableUsers);

        setForm(
          createPackageValidationFormData(
            mapped
          )
        );

        setSelectedUserId(
          mapped.currentUser
            .is_default_user
            ? 0
            : mapped.currentUser.id_user
        );

        setActiveImage(0);
        setRotation(0);
        setImageFailed(false);
        setLoadError(null);

        try {
          sessionStorage.setItem(
            `vision-package:${mapped.idPackage}`,
            JSON.stringify(mapped)
          );
        } catch {
          // El caché es opcional.
        }
      } catch (error) {
        console.error(
          "Error loading package validation:",
          error
        );

        setLoadError(
          error instanceof Error
            ? error
            : new Error(
                t(
                  "orders.validation.details.loadError"
                )
              )
        );
      } finally {
        setLoading(false);
        setLoadingUsers(false);
      }
    }, [
      cachedValidation,
      language,
      t,
      validationId,
    ]);

  useEffect(() => {
    void loadPackage();
  }, [loadPackage]);

  const currentImage =
    validation?.images[
      activeImage
    ] ?? "";

  const canDisplayImage =
    Boolean(currentImage) &&
    !imageFailed;

  const imageCount =
    validation?.images.length ?? 0;

  useEffect(() => {
    setImageFailed(false);
    setRotation(0);
  }, [
    activeImage,
    currentImage,
  ]);

  const userMap = useMemo(
    () =>
      new Map(
        users.map((user) => [
          user.idUser,
          user,
        ])
      ),
    [users]
  );

  const orderedUsers =
    useMemo(() => {
      if (!validation) {
        return users;
      }

      const orderedIds = [
        ...validation.candidates.map(
          (candidate) =>
            candidate.id_user
        ),

        ...(!validation.currentUser
          .is_default_user
          ? [
              validation.currentUser
                .id_user,
            ]
          : []),

        ...users.map(
          (user) => user.idUser
        ),
      ];

      const seen = new Set<number>();
      const result:
        ValidationUserOption[] = [];

      for (const idUser of orderedIds) {
        if (
          !idUser ||
          seen.has(idUser)
        ) {
          continue;
        }

        seen.add(idUser);

        const knownUser =
          userMap.get(idUser);

        result.push(
          knownUser ?? {
            idUser,
            name: t(
              "orders.validation.details.userNumber",
              {
                id: idUser,
              }
            ),
            unit: "",
            email: "",
            phone: "",
          }
        );
      }

      return result;
    }, [
      t,
      userMap,
      users,
      validation,
    ]);

  const candidateIds = useMemo(
    () =>
      new Set(
        validation?.candidates.map(
          (candidate) =>
            candidate.id_user
        ) ?? []
      ),
    [validation]
  );

  const updateField = (
    field: EditableField,
    value: string
  ) => {
    setForm((current) => ({
      ...current,
      [field]: value,
    }));
  };

  const previousImage = () => {
    if (
      !validation ||
      validation.images.length <= 1
    ) {
      return;
    }

    setActiveImage((current) =>
      current <= 0
        ? validation.images.length -
          1
        : current - 1
    );
  };

  const nextImage = () => {
    if (
      !validation ||
      validation.images.length <= 1
    ) {
      return;
    }

    setActiveImage((current) =>
      current >=
      validation.images.length - 1
        ? 0
        : current + 1
    );
  };

  const rotateImage = () => {
    if (!canDisplayImage) {
      return;
    }

    setRotation(
      (current) =>
        (current + 90) % 360
    );
  };

  const openFullscreen =
    async () => {
      if (!canDisplayImage) {
        return;
      }

      try {
        await imageContainerRef
          .current?.requestFullscreen();
      } catch (error) {
        console.error(
          "Unable to open fullscreen:",
          error
        );
      }
    };

  const downloadImage = () => {
    if (
      !currentImage ||
      imageFailed ||
      !validation
    ) {
      return;
    }

    const link =
      document.createElement("a");

    link.href = currentImage;
    link.target = "_blank";
    link.rel =
      "noopener noreferrer";

    link.download =
      `package-${validation.idPackage}-${activeImage + 1}`;

    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const validatePackage =
    async () => {
      if (!validation) {
        return;
      }

      const selectedUserIsCurrentDefault =
        validation.currentUser
          .is_default_user &&
        selectedUserId ===
          validation.currentUser.id_user;

      if (
        !selectedUserId ||
        selectedUserIsCurrentDefault
      ) {
        toast.error(
          t(
            "orders.validation.details.selectRecipientError"
          )
        );

        return;
      }

      setSaving(true);

      try {        const payload =
          buildVisionPackageResolutionPayload(
            validation,
            form,
            selectedUserId
          );

        await packageService.resolveVisionPackage(
          validation.idPackage,
          language,
          payload
        );

        sessionStorage.removeItem(
          `vision-package:${validation.idPackage}`
        );

        toast.success(
          t(
            "orders.validation.details.validatedMessage"
          )
        );

        navigate(
          "/orders?tab=validation",
          {
            replace: true,
          }
        );
      } catch (error) {
        console.error(
          "Error resolving package validation:",
          error
        );

        toast.error(
          error instanceof Error
            ? error.message
            : t(
                "orders.validation.details.saveError"
              )
        );
      } finally {
        setSaving(false);
      }
    };

  if (
    loading &&
    !validation
  ) {
    return (
      <DashboardLayout>
        <div className="flex min-h-[520px] items-center justify-center">
          <LoadingSpinner
            text={t(
              "orders.validation.details.loading"
            )}
          />
        </div>
      </DashboardLayout>
    );
  }

  if (!validation) {
    return (
      <DashboardLayout>
        <div className="flex min-h-[500px] flex-col items-center justify-center rounded-xl border bg-card p-8 text-center">
          <SearchCheck className="mb-4 h-10 w-10 text-muted-foreground" />

          <h1 className="text-lg font-semibold">
            {t(
              "orders.validation.details.notFound"
            )}
          </h1>

          <p className="mt-2 max-w-md text-sm text-muted-foreground">
            {loadError?.message ||
              t(
                "orders.validation.details.notFoundDescription"
              )}
          </p>

          <div className="mt-6 flex gap-3">
            <Button
              variant="outline"
              onClick={() =>
                navigate(
                  "/orders?tab=validation"
                )
              }
            >
              <ArrowLeft className="mr-2 h-4 w-4" />

              {t(
                "orders.validation.details.back"
              )}
            </Button>

            <Button
              onClick={() =>
                void loadPackage()
              }
            >
              <RefreshCw className="mr-2 h-4 w-4" />

              {t(
                "orders.validation.retry"
              )}
            </Button>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  const validationStatus =
    normalizeValidationStatus(
      validation.status,
      {
        needsReview:
          validation.needsReview,
        isDefaultUser:
          validation.currentUser
            .is_default_user,
        imageIssue:
          validation.imageIssue,
      }
    );

  const tracking =
    getPackageDisplayTracking(
      validation
    );

  const currentUserName =
    getCurrentUserDisplayName(
      validation.currentUser
    ) ||
    t(
      "orders.validation.details.userNumber",
      {
        id: validation.currentUser
          .id_user,
      }
    );

  const selectedUser =
    userMap.get(selectedUserId);

  const doorLabel =
    getPackageDoorLabel(
      validation
    );

  return (
    <DashboardLayout>
      <div className="space-y-4 animate-fade-in">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="icon"
              className="h-10 w-10 shrink-0"
              onClick={() =>
                navigate(
                  "/orders?tab=validation"
                )
              }
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>

            <div>
              <h1 className="text-xl font-semibold">
                {t(
                  "orders.validation.details.title"
                )}
              </h1>

              <p className="mt-1 text-sm text-muted-foreground">
                {tracking ||
                  t(
                    "orders.validation.details.packageNumber",
                    {
                      id: validation.idPackage,
                    }
                  )}
              </p>
            </div>
          </div>

          <span
            className={cn(
              "inline-flex w-fit rounded-full border px-3 py-1 text-xs font-medium",
              getStatusBannerClass(
                validationStatus
              )
            )}
          >
            {t(
              `orders.validation.status.${validationStatus}`
            )}
          </span>
        </div>

        {loadError && (
          <div className="flex items-start gap-2 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-950 dark:border-amber-900 dark:bg-amber-950/20 dark:text-amber-100">
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />

            <span>
              {t(
                "orders.validation.details.cachedDataWarning"
              )}
            </span>
          </div>
        )}

        <section
          className={cn(
            "rounded-xl border p-4",
            getStatusBannerClass(
              validationStatus
            )
          )}
        >
          <div className="flex gap-3">
            <TriangleAlert className="mt-0.5 h-6 w-6 shrink-0" />

            <div>
              <h2 className="font-semibold">
                {t(
                  `orders.validation.details.banner.${validationStatus}.title`
                )}
              </h2>

              <p className="mt-1 text-sm opacity-90">
                {t(
                  `orders.validation.details.banner.${validationStatus}.description`
                )}
              </p>
            </div>
          </div>
        </section>

        <div className="grid gap-4 xl:grid-cols-[minmax(0,1.05fr)_minmax(430px,1fr)]">
          <section className="overflow-hidden rounded-xl border bg-card shadow-sm">
            <div className="flex items-center justify-between border-b p-3">
              <div>
                <p className="text-sm font-semibold">
                  {t(
                    "orders.validation.details.packageImage"
                  )}
                </p>

                <p className="text-xs text-muted-foreground">
                  {imageCount > 0
                    ? t(
                        "orders.validation.details.imageCounter",
                        {
                          current:
                            activeImage +
                            1,
                          total:
                            imageCount,
                        }
                      )
                    : t(
                        "orders.validation.details.imageUnavailable"
                      )}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  title={t(
                    "orders.validation.details.imageActions.rotate"
                  )}
                  onClick={
                    rotateImage
                  }
                  disabled={
                    !canDisplayImage
                  }
                >
                  <RotateCcw className="h-4 w-4" />
                </Button>

                <Button
                  variant="outline"
                  size="icon"
                  title={t(
                    "orders.validation.details.imageActions.download"
                  )}
                  onClick={
                    downloadImage
                  }
                  disabled={
                    !canDisplayImage
                  }
                >
                  <Download className="h-4 w-4" />
                </Button>

                <Button
                  variant="outline"
                  size="icon"
                  title={t(
                    "orders.validation.details.imageActions.fullscreen"
                  )}
                  onClick={() =>
                    void openFullscreen()
                  }
                  disabled={
                    !canDisplayImage
                  }
                >
                  <Expand className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div
              ref={
                imageContainerRef
              }
              className="flex min-h-[520px] items-center justify-center overflow-hidden bg-muted/60 p-4"
            >
              {canDisplayImage ? (
                <img
                  src={
                    currentImage
                  }
                  alt={t(
                    "orders.validation.details.packageImageAlt"
                  )}
                  onError={() =>
                    setImageFailed(
                      true
                    )
                  }
                  className="max-h-[680px] max-w-full object-contain transition-transform duration-300"
                  style={{
                    transform:
                      `rotate(${rotation}deg)`,
                  }}
                />
              ) : (
                <div className="flex min-h-[420px] max-w-md flex-col items-center justify-center px-6 text-center">
                  <div className="flex h-20 w-20 items-center justify-center rounded-full bg-muted">
                    <ImageOff className="h-10 w-10 text-muted-foreground" />
                  </div>

                  <p className="mt-5 font-semibold">
                    {t(
                      "orders.validation.details.imageUnavailable"
                    )}
                  </p>

                  <p className="mt-2 text-sm text-muted-foreground">
                    {validation.imageIssue ||
                      t(
                        "orders.validation.details.imageUnavailableDescription"
                      )}
                  </p>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between border-t p-3">
              <Button
                variant="outline"
                size="icon"
                onClick={
                  previousImage
                }
                disabled={
                  imageCount <= 1
                }
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>

              <span className="text-sm font-medium">
                {imageCount > 0
                  ? `${activeImage + 1} / ${imageCount}`
                  : "0 / 0"}
              </span>

              <Button
                variant="outline"
                size="icon"
                onClick={nextImage}
                disabled={
                  imageCount <= 1
                }
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </section>

          <div className="space-y-4">
            <InformationCard
              title={t(
                "orders.validation.details.assignmentInformation"
              )}
            >
              <div className="space-y-4">
                <div className="rounded-lg border bg-muted/25 p-3">
                  <p className="text-xs font-semibold text-muted-foreground">
                    {t(
                      "orders.validation.details.currentAssignment"
                    )}
                  </p>

                  <p className="mt-1 font-medium">
                    {currentUserName}
                  </p>

                  <p className="mt-1 text-xs text-muted-foreground">
                    {validation.currentUser
                      .is_default_user
                      ? t(
                          "orders.validation.details.defaultUser"
                        )
                      : t(
                          "orders.validation.details.assignedUser"
                        )}
                  </p>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-medium">
                    {t(
                      "orders.validation.details.recipientSelection"
                    )}
                  </label>

                  <Select
                    value={
                      selectedUserId >
                      0
                        ? String(
                            selectedUserId
                          )
                        : undefined
                    }
                    onValueChange={(
                      value
                    ) =>
                      setSelectedUserId(
                        Number(value)
                      )
                    }
                  >
                    <SelectTrigger>
                      <SelectValue
                        placeholder={
                          loadingUsers
                            ? t(
                                "orders.validation.details.loadingRecipients"
                              )
                            : t(
                                "orders.validation.details.selectRecipient"
                              )
                        }
                      />
                    </SelectTrigger>

                    <SelectContent className="max-h-[320px]">
                      {orderedUsers.map(
                        (user) => (
                          <SelectItem
                            key={
                              user.idUser
                            }
                            value={String(
                              user.idUser
                            )}
                          >
                            {user.name}

                            {user.unit
                              ? ` · ${user.unit}`
                              : ""}

                            {candidateIds.has(
                              user.idUser
                            )
                              ? ` · ${t(
                                  "orders.validation.details.suggested"
                                )}`
                              : ""}
                          </SelectItem>
                        )
                      )}
                    </SelectContent>
                  </Select>

                  {selectedUser && (
                    <p className="text-xs text-muted-foreground">
                      {[
                        selectedUser.unit,
                        selectedUser.email,
                      ]
                        .filter(Boolean)
                        .join(" · ")}
                    </p>
                  )}
                </div>

                {validation.candidates
                  .length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground">
                      {t(
                        "orders.validation.details.suggestedCandidates"
                      )}
                    </p>

                    <div className="mt-2 flex flex-wrap gap-2">
                      {validation.candidates.map(
                        (
                          candidate
                        ) => {
                          const candidateUser =
                            userMap.get(
                              candidate.id_user
                            );

                          return (
                            <button
                              key={
                                candidate.id_user
                              }
                              type="button"
                              onClick={() =>
                                setSelectedUserId(
                                  candidate.id_user
                                )
                              }
                              className={cn(
                                "rounded-full border px-3 py-1 text-xs transition-colors",
                                selectedUserId ===
                                  candidate.id_user
                                  ? "border-primary bg-primary text-primary-foreground"
                                  : "bg-background hover:bg-muted"
                              )}
                            >
                              {candidateUser?.name ||
                                t(
                                  "orders.validation.details.userNumber",
                                  {
                                    id: candidate.id_user,
                                  }
                                )}
                            </button>
                          );
                        }
                      )}
                    </div>
                  </div>
                )}
              </div>
            </InformationCard>

            <InformationCard
              title={t(
                "orders.validation.details.packageMetadata"
              )}
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <ValidationField
                  label={t(
                    "orders.validation.details.fields.carrier"
                  )}
                  value={
                    form.carrier
                  }
                  placeholder={t(
                    "orders.validation.details.placeholders.carrier"
                  )}
                  missingMessage={t(
                    "orders.validation.details.fieldNotDetected"
                  )}
                  onChange={(value) =>
                    updateField(
                      "carrier",
                      value
                    )
                  }
                />

                <ValidationField
                  label={t(
                    "orders.validation.details.fields.tracking"
                  )}
                  value={
                    form.tracking
                  }
                  placeholder={t(
                    "orders.validation.details.placeholders.tracking"
                  )}
                  missingMessage={t(
                    "orders.validation.details.fieldNotDetected"
                  )}
                  onChange={(value) =>
                    updateField(
                      "tracking",
                      value
                    )
                  }
                />

                <ValidationField
                  label={t(
                    "orders.validation.details.fields.recipient"
                  )}
                  value={
                    form.recipient
                  }
                  placeholder={t(
                    "orders.validation.details.placeholders.recipient"
                  )}
                  missingMessage={t(
                    "orders.validation.details.fieldNotDetected"
                  )}
                  onChange={(value) =>
                    updateField(
                      "recipient",
                      value
                    )
                  }
                />

                <ValidationField
                  label={t(
                    "orders.validation.details.fields.phone"
                  )}
                  value={
                    form.phone
                  }
                  placeholder={t(
                    "orders.validation.details.placeholders.phone"
                  )}
                  missingMessage={t(
                    "orders.validation.details.fieldNotDetected"
                  )}
                  onChange={(value) =>
                    updateField(
                      "phone",
                      value
                    )
                  }
                />

                <ValidationField
                  label={t(
                    "orders.validation.details.fields.sender"
                  )}
                  value={
                    form.sender
                  }
                  placeholder={t(
                    "orders.validation.details.placeholders.sender"
                  )}
                  missingMessage={t(
                    "orders.validation.details.fieldNotDetected"
                  )}
                  onChange={(value) =>
                    updateField(
                      "sender",
                      value
                    )
                  }
                />

                <ValidationField
                  label={t(
                    "orders.validation.details.fields.unit"
                  )}
                  value={form.unit}
                  placeholder={t(
                    "orders.validation.details.placeholders.unit"
                  )}
                  missingMessage={t(
                    "orders.validation.details.fieldNotDetected"
                  )}
                  onChange={(value) =>
                    updateField(
                      "unit",
                      value
                    )
                  }
                />

                <div className="sm:col-span-2">
                  <ValidationField
                    label={t(
                      "orders.validation.details.fields.address"
                    )}
                    value={
                      form.address
                    }
                    placeholder={t(
                      "orders.validation.details.placeholders.address"
                    )}
                    missingMessage={t(
                      "orders.validation.details.fieldNotDetected"
                    )}
                    multiline
                    onChange={(value) =>
                      updateField(
                        "address",
                        value
                      )
                    }
                  />
                </div>
              </div>
            </InformationCard>

            <div className="grid gap-4 md:grid-cols-2">
              <InformationCard
                title={t(
                  "orders.validation.details.locationInformation"
                )}
              >
                <div className="grid gap-4 sm:grid-cols-2">
                  <InformationItem
                    label={t(
                      "orders.validation.details.propertyId"
                    )}
                    value={
                      validation.idProperty
                    }
                  />

                  <InformationItem
                    label={t(
                      "orders.validation.details.lockerId"
                    )}
                    value={
                      validation.idLocker
                    }
                  />

                  <InformationItem
                    label={t(
                      "orders.validation.details.door"
                    )}
                    value={doorLabel}
                  />

                  <InformationItem
                    label={t(
                      "orders.validation.details.column"
                    )}
                    value={
                      validation.columnName
                    }
                  />

                  <InformationItem
                    label={t(
                      "orders.validation.details.position"
                    )}
                    value={
                      validation.position
                    }
                  />

                  <InformationItem
                    label={t(
                      "orders.validation.details.dimensionId"
                    )}
                    value={
                      validation.idLockerDimension
                    }
                  />
                </div>
              </InformationCard>

              <InformationCard
                title={t(
                  "orders.validation.details.packageInformation"
                )}
              >
                <div className="grid gap-4 sm:grid-cols-2">
                  <InformationItem
                    label={t(
                      "orders.validation.details.packageId"
                    )}
                    value={
                      validation.idPackage
                    }
                  />

                  <InformationItem
                    label={t(
                      "orders.validation.details.serviceId"
                    )}
                    value={
                      validation.idService
                    }
                  />

                  <InformationItem
                    label={t(
                      "orders.validation.details.packageCodeId"
                    )}
                    value={
                      validation.idPackageCode
                    }
                  />

                  <InformationItem
                    label={t(
                      "orders.validation.details.detectRecipientId"
                    )}
                    value={
                      validation.idPackageDetectRecipient
                    }
                  />

                  <InformationItem
                    className="sm:col-span-2"
                    label={t(
                      "orders.validation.details.registrationDate"
                    )}
                    value={
                      validation.registrationDate
                    }
                  />
                </div>
              </InformationCard>
            </div>
          </div>
        </div>

        <div className="sticky bottom-0 z-20 flex flex-col-reverse gap-3 border-t bg-background/95 py-4 backdrop-blur sm:flex-row sm:items-center sm:justify-end">
          <Button
            variant="outline"
            disabled={saving}
            onClick={() =>
              navigate(
                "/orders?tab=validation"
              )
            }
          >
            {t(
              "orders.validation.details.cancel"
            )}
          </Button>

          <Button
            disabled={saving}
            onClick={() =>
              void validatePackage()
            }
          >
            {saving ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <UserCheck className="mr-2 h-4 w-4" />
            )}

            {validationStatus ===
            "REVIEW"
              ? t(
                  "orders.validation.details.confirmAssignment"
                )
              : t(
                  "orders.validation.details.assignAndValidate"
                )}
          </Button>
        </div>
      </div>
    </DashboardLayout>
  );
}