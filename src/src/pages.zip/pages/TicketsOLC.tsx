// pages/TicketsOLC.tsx
import { useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { TabFilter } from "@/components/dashboard/TabFilter";

import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";

import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  AlertCircle,
} from "lucide-react";

import { useOLCTickets } from "@/hooks/useOLCTickets";

import { TicketsKPIs } from "@/components/tickets/TicketsKPIs";
import { TicketsTable } from "@/components/tickets/TicketsTable";

import { Button } from "@/components/ui/button";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";

import type { OLCTicket } from "@/types/olc-tickets.types";

// =====================================================
// CONSTANTS
// =====================================================

const POLLING_INTERVAL_MS = 30_000;

export default function TicketsOLC() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const { user } = useAuth();

  const {
    statusFilter,
    setStatusFilter,
    filteredTickets,
    loading,
    error,
    getStatusCount,
    kpis,
    refetch,
  } = useOLCTickets();

  // Evita encolar refetches si el anterior aún está corriendo.
  const inFlightRef = useRef(false);

  // =====================================================
  // POLLING CADA 30s
  // =====================================================
  useEffect(() => {
    const tick = async () => {
      // Pausa cuando la pestaña no está visible: ahorra peticiones
      // cuando el operador está en otra ventana.
      if (document.visibilityState !== "visible") return;
      if (inFlightRef.current) return;

      inFlightRef.current = true;
      try {
        await refetch();
      } catch (err) {
        // Silencioso: no toast cada 30s si la red falla.
        console.error("[TicketsOLC polling]", err);
      } finally {
        inFlightRef.current = false;
      }
    };

    const intervalId = window.setInterval(tick, POLLING_INTERVAL_MS);

    // Cuando el usuario regresa a la pestaña, refrescamos de inmediato.
    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        tick();
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);

    return () => {
      window.clearInterval(intervalId);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [refetch]);

  // =====================================================
  // OLC-specific status tabs (4 estados completos)
  // =====================================================
  const statusTabs = [
    {
      id: "all",
      label: t("tickets.all") || "Todos",
      count: getStatusCount("all"),
    },
    {
      id: "open",
      label: t("tickets.open") || "Abiertos",
      count: getStatusCount("open"),
    },
    {
      id: "in_progress",
      label: t("tickets.inProgress") || "En progreso",
      count: getStatusCount("in_progress"),
    },
    {
      id: "resolved",
      label: t("tickets.resolved") || "Resueltos",
      count: getStatusCount("resolved"),
    },
    {
      id: "closed",
      label: t("tickets.closed") || "Cerrados",
      count: getStatusCount("closed"),
    },
  ];

  const statusConfig = {
    open: {
      label: "ABIERTO",
      className: "bg-accent/10 text-accent border-accent/20",
    },
    in_progress: {
      label: "EN CURSO",
      className: "bg-secondary text-secondary-foreground border-border",
    },
    resolved: {
      label: "RESUELTO",
      className: "bg-success text-success-foreground border-border",
    },
    closed: {
      label: "CERRADO",
      className: "bg-muted text-muted-foreground",
    },
  };

  const priorityConfig = {
    low: {
      label: t("tickets.priority.low"),
      className: "bg-muted text-muted-foreground",
    },
    medium: {
      label: t("tickets.priority.medium"),
      className: "bg-warning/10 text-warning",
    },
    high: {
      label: t("tickets.priority.high"),
      className: "bg-destructive/10 text-destructive",
    },
    critical: {
      label: t("tickets.priority.critical"),
      className: "bg-destructive text-destructive-foreground",
    },
  };

  const categoryLabels = {
    maintenance: "Mantenimiento",
    technical: "Técnico",
    access: "Acceso",
    billing: "Facturación",
    other: "Otro",
  };

  const kpisData = [
    {
      label: "Activos",
      value: kpis.totalActive.toString(),
      icon: AlertTriangle,
      color: "text-warning",
    },
    {
      label: "En Curso",
      value: kpis.inProgress.toString(),
      icon: Clock,
      color: "text-info",
    },
    {
      label: "Resueltos Este Mes",
      value: kpis.resolvedThisMonth.toString(),
      icon: CheckCircle2,
      color: "text-success",
    },
    {
      label: "En Riesgo SLA",
      value: kpis.slaAtRisk.toString(),
      icon: AlertCircle,
      color: "text-destructive",
    },
  ];

  // Solo mostramos el spinner global en la CARGA INICIAL.
  // Si ya hay tickets en pantalla, un refetch en segundo plano no
  // debería cubrir todo con el LoadingSpinner.
  const isInitialLoading = loading && filteredTickets.length === 0;

  if (isInitialLoading) {
    return (
      <DashboardLayout>
        <LoadingSpinner fullPage text={t("common.loading")} />
      </DashboardLayout>
    );
  }

  if (error && filteredTickets.length === 0) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <p className="text-destructive">{error}</p>
            <Button
              className="mt-4"
              variant="outline"
              onClick={() => refetch()}
            >
              {t("common.retry") || "Retry"}
            </Button>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  // Transform OLC tickets to the format expected by TicketsTable
  const transformedTickets = filteredTickets.map((olcTicket: OLCTicket) => ({
    id: olcTicket.id,
    id_consumer_ticket: olcTicket.id_olc_ticket,
    title: olcTicket.title,
    category: olcTicket.category,
    status: olcTicket.status,
    priority: olcTicket.priority,
    assignee: olcTicket.assignee,
    lockerRef: olcTicket.hub,
    createdDate: olcTicket.createdDate,
    rawData: olcTicket,
    code: olcTicket.code,
    hubCode: olcTicket.hubCode,
    slaAtRisk: olcTicket.slaAtRisk,
  }));

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between">
          <DashboardHeader
            title="OLC Tickets"
            subtitle={t("tickets.subtitle") || "Manage support tickets for OLC"}
          />
        </div>

        {/* KPIs */}
        <TicketsKPIs kpis={kpisData} />

        {/* Tabs */}
        <div className="mt-6">
          <TabFilter
            tabs={statusTabs}
            activeTab={statusFilter}
            onTabChange={setStatusFilter}
          />
        </div>

        {/* Table */}
        {transformedTickets.length > 0 ? (
          <TicketsTable
            tickets={transformedTickets}
            onRowClick={(ticket: any) => {
              const ticketId = ticket?.id_olc_ticket || ticket?.id;
              if (ticketId) {
                navigate(`/tickets-olc/${ticketId}`);
              } else {
                console.error("No ticket ID found", ticket);
              }
            }}
            statusConfig={statusConfig as any}
            priorityConfig={priorityConfig}
            categoryLabels={categoryLabels}
          />
        ) : (
          <div className="flex items-center justify-center h-96">
            <div className="text-center">
              <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">
                {t("common.noData") || "No tickets found"}
              </p>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}