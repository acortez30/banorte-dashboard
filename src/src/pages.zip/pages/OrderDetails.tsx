import {
  useEffect,
  useMemo,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import { useParams } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import OrderHeader from "@/components/order-detail/OrderHeader";
import OrderMetrics from "@/components/order-detail/OrderMetrics";
import OrderClientCard from "@/components/order-detail/OrderClientCard";
import OrderClientSection from "@/components/order-detail/OrderClientSection";
import OrderEvidence from "@/components/order-detail/OrderEvidence";
import OrderNotifications from "@/components/order-detail/OrderNotifications";
import { orderDetailService } from "@/services/orderDetail.service";
import QRCode from "react-qr-code";
import { mapOrderDetail } from "@/utils/orderDetail.mapper";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import {
  ORDER_STATUS_BADGE,
  QR_ALLOWED_STATUSES,
  type OrderDetail,
  type OrderStatus,
} from "@/types/orders.types";

const translateOrFallback = (
  t: (key: string) => string,
  key: string,
  fallback: string
) => {
  const value = t(key);
  return value && value !== key ? value : fallback;
};

const getStatusLabels = (
  t: (key: string) => string
): Record<OrderStatus, string> => ({
  completed: translateOrFallback(
    t,
    "orderDetail.completed",
    "Completada"
  ),

  expired: translateOrFallback(
    t,
    "orderDetail.expired",
    "Expirada"
  ),

  in_locker: translateOrFallback(
    t,
    "orderDetail.inLocker",
    "En locker"
  ),

  in_transit: translateOrFallback(
    t,
    "orderDetail.inTransit",
    "En tránsito"
  ),

  pending_validate: translateOrFallback(
    t,
    "orderDetail.pendingValidate",
    "Pendiente de validar"
  ),

  pending_payment: translateOrFallback(
    t,
    "orderDetail.pendingPayment",
    "Pendiente de pago"
  ),

  in_progress: translateOrFallback(
    t,
    "orderDetail.inProgress",
    "En proceso"
  ),

  returned: translateOrFallback(
    t,
    "orderDetail.returned",
    "Retornada"
  ),

  canceled: translateOrFallback(
    t,
    "orderDetail.canceled",
    "Cancelada"
  ),

  canceled_locker: translateOrFallback(
    t,
    "orderDetail.canceledLocker",
    "Cancelada en locker"
  ),

  canceled_picked: translateOrFallback(
    t,
    "orderDetail.canceledPicked",
    "Cancelado recolectado"
  ),

  scheduled: translateOrFallback(
    t,
    "orderDetail.schedule",
    "Agendado"
  ),

  failure: translateOrFallback(
    t,
    "orderDetail.failure",
    "Falla"
  ),

  processing: translateOrFallback(
    t,
    "orderDetail.processing",
    "Procesando"
  ),

  delivered: translateOrFallback(
    t,
    "orderDetail.delivered",
    "Entregada"
  ),
});

const SectionCard = ({
  children,
  className = "",
  style,
}: {
  children: ReactNode;
  className?: string;
  style?: CSSProperties;
}) => (
  <div
    className={`rounded-2xl border border-border bg-card p-5 ${className}`}
    style={{ boxShadow: "var(--shadow-card)", ...style }}
  >
    {children}
  </div>
);

const SectionTitle = ({
  children,
  action,
}: {
  children: ReactNode;
  action?: ReactNode;
}) => (
  <div className="flex items-center justify-between mb-4">
    <h3 className="text-sm font-semibold font-poppins text-foreground">
      {children}
    </h3>
    {action}
  </div>
);

const InfoRow = ({ label, value }: { label: string; value: string }) => (
  <div className="flex flex-col gap-0.5">
    <p className="text-[11px] font-inter text-muted-foreground">{label}</p>
    <p className="text-xs font-inter font-medium text-foreground leading-snug">
      {value}
    </p>
  </div>
);

export default function OrderDetails() {
  const { id } = useParams();
  const { t, language } = useLanguage();
  const { user } = useAuth();

  const isHouseAccount = String(user?.user_type ?? "")
    .trim()
    .toUpperCase() === "HOUSE ACCOUNT";

  const tf = (key: string, fallback: string) =>
    translateOrFallback(t, key, fallback);

  const [qrModalOpen, setQrModalOpen] = useState(false);

  const [photoModal, setPhotoModal] = useState({
    open: false,
    src: "",
    title: "",
  });

  const [orderData, setOrderData] = useState<OrderDetail | null>(null);
  const [loading, setLoading] = useState(true);

  const statusLabels = useMemo(() => getStatusLabels(t), [t, language]);

  useEffect(() => {
    let isMounted = true;

    const fetchDetail = async () => {
      if (!id) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);

        const res = await orderDetailService.getDetailPackage(id, language);

        if (!isMounted) return;

        if (res?.mensaje_return?.CODE === 200) {
          const mapped = mapOrderDetail(res);
          setOrderData(mapped);
        } else {
          setOrderData(null);
        }
      } catch (error) {
        console.error("Error loading order detail:", error);

        if (isMounted) {
          setOrderData(null);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchDetail();

    return () => {
      isMounted = false;
    };
  }, [id, language]);

  if (loading) {
    return (
      <DashboardLayout>
        <LoadingSpinner
          fullPage
          text={tf("common.loading", "Cargando...")}
        />
      </DashboardLayout>
    );
  }

  if (!orderData) {
    return (
      <DashboardLayout>
        <div className="p-6 text-destructive">
          {tf("orderDetail.notFound", "Orden no encontrada")}
        </div>
      </DashboardLayout>
    );
  }

  const canGenerateQR = QR_ALLOWED_STATUSES.includes(orderData.status);

  const downloadQR = () => {
    const svg = document.getElementById("qr-code");
    if (!svg) return;

    const serializer = new XMLSerializer();
    const source = serializer.serializeToString(svg);

    const image = new Image();

    image.src =
      "data:image/svg+xml;charset=utf-8," + encodeURIComponent(source);

    image.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = 400;
      canvas.height = 400;

      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      ctx.fillStyle = "#FFFFFF";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(image, 0, 0, 400, 400);

      const link = document.createElement("a");
      link.download = `QR-${orderData.tracking_number}.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
    };
  };

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-[1800px] px-4 py-6 space-y-5">
        <OrderHeader
          orderData={orderData}
          statusLabels={statusLabels}
          statusBadgeClass={ORDER_STATUS_BADGE}
          t={t}
          InfoRow={InfoRow}
        />

        <OrderMetrics orderData={orderData} t={t} />

        <OrderClientCard
          orderData={orderData}
          t={t}
          setQrModalOpen={(open: boolean) => {
            if (!canGenerateQR) {
              toast.error(
                tf("orderDetail.qrNotAvailable", "No se puede generar QR")
              );
              return;
            }

            setQrModalOpen(open);
          }}
          SectionCard={SectionCard}
          SectionTitle={SectionTitle}
          InfoRow={InfoRow}
        />

        <OrderClientSection
          orderData={orderData}
          t={t}
          SectionCard={SectionCard}
          SectionTitle={SectionTitle}
        />

        <OrderEvidence
          orderData={orderData}
          t={t}
          setPhotoModal={setPhotoModal}
          language={language}
          showDeliveryPhotos={isHouseAccount}
          SectionCard={SectionCard}
          SectionTitle={SectionTitle}
        />

        <OrderNotifications
          orderData={orderData}
          t={t}
          SectionCard={SectionCard}
          SectionTitle={SectionTitle}
        />
      </div>

      <Dialog open={qrModalOpen} onOpenChange={setQrModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">
              {tf("orderDetail.qrCode", "Código QR")}
            </DialogTitle>
          </DialogHeader>

          <div className="flex flex-col items-center space-y-4 py-4">
            <QRCode
              id="qr-code"
              value={orderData.hash_package || orderData.tracking_number}
              size={180}
            />

            <div className="flex gap-3 w-full">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  downloadQR();
                  toast.success(
                    tf("orderDetail.qrDownloaded", "QR descargado")
                  );
                }}
              >
                {tf("orderDetail.download", "Descargar")}
              </Button>

              <Button
                variant="outline"
                className="flex-1"
                onClick={() => window.print()}
              >
                {tf("orderDetail.print", "Imprimir")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog
        open={photoModal.open}
        onOpenChange={(open) =>
          setPhotoModal((prev) => ({
            ...prev,
            open,
          }))
        }
      >
        <DialogContent className="sm:max-w-3xl">
          <DialogHeader>
            <DialogTitle>{photoModal.title}</DialogTitle>
          </DialogHeader>

          {photoModal.src ? (
            <img
              src={photoModal.src}
              alt={photoModal.title}
              className="max-h-[75vh] w-full rounded-xl object-contain"
            />
          ) : (
            <p className="text-sm text-muted-foreground">
              {tf("orderDetail.noEvidence", "No hay evidencia disponible.")}
            </p>
          )}
        </DialogContent>
      </Dialog>

    </DashboardLayout>
  );
}