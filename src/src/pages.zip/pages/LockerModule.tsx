import React, { useMemo, useCallback, memo } from "react";
import { Copy, ExternalLink, Package, UserRound, Hash, Box, Search } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

import { useLanguage } from "@/contexts/LanguageContext";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";

/* =====================================================
   TYPES
===================================================== */

interface Props {
	module: any[]; // array de elementos crudos del backend
	onLockerSelected?: (item: any) => void;
  canSelectDoor?: (item: any) => boolean;
  isSuperUser?: boolean;
  onSearchPackageInTable?: (packageInfo: any) => void;
}

/* =====================================================
   STATUS COLORS
===================================================== */

const STATUS_CLASS: Record<string, string> = {
  cerrado:
    "bg-locker-available-fill text-locker-available border-locker-available " +
    "hover:bg-locker-available " +
    "dark:bg-locker-available-dark-fill dark:text-locker-available-dark dark:border-locker-available-dark " +
    "dark:hover:bg-locker-available-dark-hover",

  ocupado:
    "bg-locker-occupied-fill text-locker-occupied border-locker-occupied " +
    "hover:bg-locker-occupied " +
    "dark:bg-locker-occupied-dark-fill dark:text-locker-occupied-dark dark:border-locker-occupied-dark " +
    "dark:hover:bg-locker-occupied-dark-hover",

  abierto:
    "bg-locker-open-fill text-locker-open border-locker-open " +
    "hover:bg-locker-open " +
    "dark:bg-locker-open-dark-fill dark:text-locker-open-dark dark:border-locker-open-dark " +
    "dark:hover:bg-locker-open-dark-hover",

  schedule:
    "bg-locker-schedule-fill text-locker-schedule border-locker-schedule " +
    "hover:bg-locker-schedule " +
    "dark:bg-locker-schedule-dark-fill dark:text-locker-schedule-dark dark:border-locker-schedule-dark " +
    "dark:hover:bg-locker-schedule-dark-hover",

  expirado:
    "bg-locker-expired-fill text-locker-expired border-locker-expired " +
    "hover:bg-locker-expired " +
    "dark:bg-locker-expired-dark-fill dark:text-locker-expired-dark dark:border-locker-expired-dark " +
    "dark:hover:bg-locker-expired-dark-hover",

  fallo:
    "bg-locker-defective-fill text-locker-defective border-locker-defective " +
    "hover:bg-locker-defective " +
    "dark:bg-locker-defective-dark-fill dark:text-locker-defective-dark dark:border-locker-defective-dark " +
    "dark:hover:bg-locker-defective-dark-hover",
};

const PACKAGE_STATUS_BADGE_CLASS: Record<string, string> = {
  expired:
    "border-amber-400/40 bg-amber-50 text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300",
  scheduled:
    "border-fuchsia-400/40 bg-fuchsia-50 text-fuchsia-700 dark:border-fuchsia-500/30 dark:bg-fuchsia-500/10 dark:text-fuchsia-300",
  completed:
    "border-emerald-400/40 bg-emerald-50 text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300",
  in_locker:
    "border-indigo-400/40 bg-indigo-50 text-indigo-700 dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-300",
  in_transit:
    "border-cyan-400/40 bg-cyan-50 text-cyan-700 dark:border-cyan-500/30 dark:bg-cyan-500/10 dark:text-cyan-300",
  failure:
    "border-red-400/40 bg-red-50 text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300",
  canceled:
    "border-slate-300 bg-slate-50 text-slate-600 dark:border-slate-600 dark:bg-slate-800/60 dark:text-slate-300",
  default:
    "border-border bg-background text-foreground",
};

function normalizePackageStatus(value: unknown) {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[\s-]+/g, "_");
}

function getPackageStatusBadgeClass(value: unknown) {
  const status = normalizePackageStatus(value);

  if (["vencido", "expirado", "expired"].includes(status)) {
    return PACKAGE_STATUS_BADGE_CLASS.expired;
  }

  if (["agendado", "scheduled", "schedule"].includes(status)) {
    return PACKAGE_STATUS_BADGE_CLASS.scheduled;
  }

  if (["completado", "completed", "entregado", "delivered"].includes(status)) {
    return PACKAGE_STATUS_BADGE_CLASS.completed;
  }

  if (["en_locker", "in_locker", "ocupado", "in_origin_locker", "in_destination_locker"].includes(status)) {
    return PACKAGE_STATUS_BADGE_CLASS.in_locker;
  }

  if (["en_transito", "in_transit", "transito"].includes(status)) {
    return PACKAGE_STATUS_BADGE_CLASS.in_transit;
  }

  if (["fallo", "failure", "defectuoso", "defective"].includes(status)) {
    return PACKAGE_STATUS_BADGE_CLASS.failure;
  }

  if (["cancelado", "cancelada", "canceled", "cancelled"].includes(status)) {
    return PACKAGE_STATUS_BADGE_CLASS.canceled;
  }

  return PACKAGE_STATUS_BADGE_CLASS.default;
}
/* =====================================================
   COMPONENT
===================================================== */

export default function LockerModule({
  module,
  onLockerSelected,
  canSelectDoor,
  isSuperUser = false,
  onSearchPackageInTable,
}: Props) {
	if (!module || module.length === 0) return null;

	const moduleType = module[0]?.name_module;
	const columnNames = module[0]?.column_name ?? [];

	/* =====================================================
	   Extract Doors
	====================================================== */

	const doors = useMemo(
		() => module.map((m: any) => m.DOOR?.[0]).filter(Boolean),
		[module],
	);

	/* =====================================================
	   Build Columns (rank_order reset)
	====================================================== */

	const buildColumns = useCallback((doors: any[]) => {
		const columns: any[] = [];
		let current: any[] = [];

		doors.forEach((door, i) => {
			if (door.rank_order === 1 && i !== 0) {
				columns.push(current);
				current = [];
			}
			current.push(door);
		});

		if (current.length) columns.push(current);

		return columns;
	}, []);

	const columns = useMemo(() => buildColumns(doors), [doors, buildColumns]);

	/* =====================================================
	   MODULE CM
	====================================================== */

	if (moduleType === "CM") {
		return (
			<div className="flex gap-0">
				{columns.map((col, colIndex) => {
					const renderItems: any[] = [];

					col.forEach((door: any) => {
						renderItems.push({ type: "door", data: door });

						// SCREEN siempre en segunda columna después del rank 2
						if (colIndex === 1 && door.rank_order === 2) {
							renderItems.push({ type: "screen" });
						}
					});

					return (
						<div key={colIndex} className="flex flex-col items-center justify-end">
							<div className="mb-2 font-semibold">{columnNames[colIndex]}</div>

							<div
								className="grid gap-[2px]"
								style={{
									gridTemplateColumns: "78px",
									gridAutoRows: "18px",
								}}
							>
								{renderItems.map((item, i) => {
									if (item.type === "screen") {
  return (
    <div
      key={`screen-${colIndex}-${i}`}
      className="rounded-md border border-border overflow-hidden flex items-center justify-center bg-muted"
      style={{ gridRow: "span 5" }}
    >
      <img
        src="https://package-hub.vivipost.com/assets/images/image-locker-hub.png"
        alt="Locker Screen"
        className="w-full h-full object-cover"
        onError={(e) => {
          // Fallback si la imagen no carga
          const target = e.currentTarget;
          target.style.display = "none";
          target.parentElement!.innerHTML = '<span class="text-xs font-bold text-muted-foreground">SCREEN</span>';
        }}
      />
    </div>
  );
}

									return (
										<LockerCell
											key={item.data.rank_order}
											door={item.data}
											onLockerSelected={onLockerSelected}
											canSelectDoor={canSelectDoor}
											isSuperUser={isSuperUser}
											onSearchPackageInTable={onSearchPackageInTable}
											style={{
												gridRow: `span ${item.data.GRID.rows}`,
											}}
										/>
									);
								})}
							</div>
						</div>
					);
				})}
			</div>
		);
	}

	/* =====================================================
	   MODULE D
	====================================================== */

	if (moduleType === "D") {
		return (
			<div className="flex gap-0">
				{columns.map((col, colIndex) => {
					const maxCols = Math.max(...col.map((d) => d.GRID.cols));

					return (
						<div key={colIndex} className="flex flex-col items-center justify-end">
							<div className="mb-2 font-semibold">{columnNames[colIndex]}</div>

							<div
								className="grid gap-[2px]"
								style={{
									gridTemplateColumns: `repeat(${maxCols}, minmax(28px, 30px))`,
									gridAutoRows: "29px",
								}}
							>
								{col.map((door) => (
									<LockerCell
										key={door.rank_order}
										door={door}
										onLockerSelected={onLockerSelected}
										canSelectDoor={canSelectDoor}
										isSuperUser={isSuperUser}
										onSearchPackageInTable={onSearchPackageInTable}
										style={{
											gridColumn: `span ${door.GRID.cols}`,
											gridRow: `span ${door.GRID.rows}`,
										}}
									/>
								))}
							</div>
						</div>
					);
				})}
			</div>
		);
	}

if (moduleType === "FOOD_01") {

	const foodDoors = [...doors].sort(
		(a, b) => a.rank_order - b.rank_order
	);

	// 🔥 MISMAS POSICIONES QUE PRUEBA
	const positions = [
		{ col: 1, row: 1, span: 1 },
		{ col: 3, row: 1, span: 1 },

		{ col: 1, row: 2, span: 1 },
		{ col: 3, row: 2, span: 1 },

		{ col: 1, row: 3, span: 3 },
		{ col: 1, row: 4, span: 3 },
		{ col: 1, row: 5, span: 3 },

		{ col: 1, row: 6, span: 1 },
		{ col: 3, row: 6, span: 1 },

		{ col: 1, row: 7, span: 1 },
		{ col: 3, row: 7, span: 1 },
	];

	return (
		<div className="flex flex-col items-center justify-end">

			<div className="mb-2 font-semibold">
				{columnNames?.[0] ?? "FOOD"}
			</div>

			<div
				className="grid gap-[1px]"
				style={{
					gridTemplateColumns: "78px 0px 78px",
					gridTemplateRows: `
						70px
						70px
						18px
						18px
						18px
						70px
						70px
					`,
				}}
			>
				{foodDoors.map((door, index) => {
					const pos = positions[index];
					if (!pos) return null;

					return (
						<LockerCell
							key={door.rank_order}
							door={door}
							onLockerSelected={onLockerSelected}
              canSelectDoor={canSelectDoor}
              isSuperUser={isSuperUser}
              onSearchPackageInTable={onSearchPackageInTable}
							style={{
								gridColumn: `${pos.col} / span ${pos.span}`,
								gridRow: pos.row,
							}}
						/>
					);
				})}
			</div>

		</div>
	);
}

/* =====================================================
   MODULE FOOD_02
====================================================== */

if (moduleType === "FOOD_02") {
  // El backend envía rank_order 12,1,2...9.
  // door_number sí es consecutivo: 32...41.
  const foodDoors = [...doors].sort(
    (a, b) => a.door_number - b.door_number,
  );

  /*
        E          F

      ┌────┐     ┌────┐
      │ 32 │     │ 37 │
      ├────┤     ├────┤
      │ 33 │     │ 38 │
      ├────┤     ├────┤
      │ 34 │     │ 39 │
      ├────┤     ├────┤
      │ 35 │     │ 40 │
      ├────┤     ├────┤
      │ 36 │     │ 41 │
      └────┘     └────┘
  */

  const leftDoors = foodDoors.slice(0, 5);
  const rightDoors = foodDoors.slice(5, 10);

  return (
    <div className="flex gap-[2px]">
      {/* ================= LEFT / E ================= */}

      <div className="flex flex-col items-center justify-center">
        <div className="mb-2 font-semibold">
          {columnNames?.[0] ?? "E"}
        </div>

        <div
          className="grid gap-[2px]"
          style={{
            gridTemplateColumns: "78px",
            gridTemplateRows: "repeat(5, 66px)",
          }}
        >
          {leftDoors.map((door) => (
            <LockerCell
              key={door.id_locker_dimension}
              door={door}
              onLockerSelected={onLockerSelected}
              canSelectDoor={canSelectDoor}
              isSuperUser={isSuperUser}
              onSearchPackageInTable={onSearchPackageInTable}
            />
          ))}
        </div>
      </div>

      {/* ================= RIGHT / F ================= */}

      <div className="flex flex-col items-center justify-center">
        <div className="mb-2 font-semibold">
          {columnNames?.[1] ?? "F"}
        </div>

        <div
          className="grid gap-[2px]"
          style={{
            gridTemplateColumns: "78px",
            gridTemplateRows: "repeat(5, 66px)",
          }}
        >
          {rightDoors.map((door) => (
            <LockerCell
              key={door.id_locker_dimension}
              door={door}
              onLockerSelected={onLockerSelected}
              canSelectDoor={canSelectDoor}
              isSuperUser={isSuperUser}
              onSearchPackageInTable={onSearchPackageInTable}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

if (moduleType === "PRUEBA") {

	const sorted = [...doors].sort((a,b)=>a.rank_order-b.rank_order)

	const layout = [
  { id: 1, col: 1, row: 1, span: 1 },
  { id: 2, col: 3, row: 1, span: 1 },
  { id: 3, col: 1, row: 2, span: 1 },
  { id: 4, col: 3, row: 2, span: 1 },

  { id: 5, col: 1, row: 3, span: 3 },
  { id: 6, col: 1, row: 4, span: 3 },
  { id: 7, col: 1, row: 5, span: 3 },

  { id: 8, col: 1, row: 6, span: 1 },
  { id: 9, col: 3, row: 6, span: 1 },
  { id: 10, col: 1, row: 7, span: 1 },
  { id: 11, col: 3, row: 7, span: 1 },
	];


	return (
		<div className="flex justify-center" style={{ alignItems: "center", flexDirection:"column" }}>

			<div className="mb-2 font-semibold">
				{columnNames?.[0]}
			</div>

			<div
				className="grid gap-[1px]"
				style={{
					gridTemplateColumns:"78px 0px 78px",
					gridTemplateRows: `
    70px
    70px
    18px
    18px
    18px
    70px
    70px
  `,
				}}
			>


				{sorted.map((door,i)=>{

					const pos = layout[i]

					return (
						<LockerCell
							key={door.rank_order}
							door={door}
							onLockerSelected={onLockerSelected}
              canSelectDoor={canSelectDoor}
              isSuperUser={isSuperUser}
              onSearchPackageInTable={onSearchPackageInTable}
							style={{
								gridColumn:`${pos.col} / span ${pos.span}`,
								gridRow:pos.row
							}}
						/>
					)

				})}

			</div>

		</div>
	)
}


	/* =====================================================
	   DEFAULT MODULES (B, E, etc.)
	====================================================== */

	return (
		<div className="flex gap-0">
			{columns.map((col, index) => (
				<div key={index} className="flex flex-col items-center justify-end" >
					<div className="mb-2 font-semibold">{columnNames[index]}</div>

					<div
						className="grid gap-[2px]"
						style={{
							gridTemplateColumns: "78px",
							gridAutoRows: "18px",
						}}
					>
						{col.map((door) => (
							<LockerCell
								key={door.rank_order}
								door={door}
								onLockerSelected={onLockerSelected}
								canSelectDoor={canSelectDoor}
								isSuperUser={isSuperUser}
								onSearchPackageInTable={onSearchPackageInTable}
								style={{
									gridRow: `span ${door.GRID.rows}`,
								}}
							/>
						))}
					</div>
				</div>
			))}
		</div>
	);
}

/* =====================================================
   LOCKER CELL (MEMOIZED)
===================================================== */

// const LockerCell = memo(({ door, onLockerSelected, style }: any) => {
// 	const handleClick = useCallback(() => {
// 		onLockerSelected?.(door);
// 	}, [door, onLockerSelected]);


// 	const statusKey = useMemo(() => {
// 		const packageStatus = door.PACKAGE?.[0]?.status_name?.toLowerCase();
// 		// Si el paquete está vencido, forzamos estado expirado
// 		if (packageStatus === "vencido") {
// 			return "expirado";
// 		}

// 		return door.name_status?.toLowerCase();
// 	}, [door]);

// 	return (
// 		<div
// 			onClick={handleClick}
// 			className={`
//           ${STATUS_CLASS[statusKey] || "bg-gray-200"}
//           border border-gray-400
//           flex justify-end items-start
//           text-[10px] font-semibold pr-1
//           cursor-pointer
//           transition-all duration-200 ease-in-out
//           hover:shadow-lg hover:shadow-black/10
//           hover:-translate-y-0.5
//           active:scale-95
//         `}
// 			style={style}
// 		>
// 			{door.door_number}
// 		</div>
// 	);
// });

// LockerCell.displayName = "LockerCell";
const LockerCell = memo(
  ({
    door,
    onLockerSelected,
    canSelectDoor,
    isSuperUser,
    onSearchPackageInTable,
    style,
  }: any) => {
    const navigate = useNavigate();
    const { t } = useLanguage();

    const packageInfo = door.PACKAGE?.[0] ?? null;
    const hasPackage = Boolean(packageInfo);

    const isSelectable = useMemo(
      () => Boolean(onLockerSelected) && (canSelectDoor ? canSelectDoor(door) : true),
      [canSelectDoor, door, onLockerSelected],
    );

    const handleClick = useCallback(() => {
      if (!isSelectable) return;
      onLockerSelected?.(door);
    }, [door, isSelectable, onLockerSelected]);

    const statusKey = useMemo(() => {
      const doorStatus = door.name_status?.toLowerCase();
      const packageStatus = packageInfo?.status_name?.toLowerCase();

      // Un fallo físico de puerta siempre tiene prioridad visual para que
      // soporte pueda identificar y seleccionar el compartimento.
      if (doorStatus === "fallo") return "fallo";
      if (packageStatus === "vencido") return "expirado";

      return doorStatus;
    }, [door, packageInfo]);

    const packageStatusLabel =
      packageInfo?.status_name || t("lockerDetail.packageStatusUnknown");
    const packageStatusBadgeClass = getPackageStatusBadgeClass(
      packageInfo?.status_name,
    );

    const recipientName =
      [packageInfo?.first_name, packageInfo?.surname].filter(Boolean).join(" ") || "---";

    // El endpoint de detalle usa id_service. El grid actual no siempre lo regresa,
    // por eso el acceso al detalle se muestra únicamente cuando venga disponible.
    const idService = packageInfo?.id_service ?? door?.id_service;

    const copyToClipboard = useCallback(
      async (value: string | number | null | undefined, successKey: string) => {
        if (value === null || value === undefined || String(value).trim() === "") return;

        const text = String(value);

        try {
          await navigator.clipboard.writeText(text);
          toast.success(t(successKey));
        } catch {
          const textarea = document.createElement("textarea");
          textarea.value = text;
          textarea.style.position = "fixed";
          textarea.style.opacity = "0";
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand("copy");
          document.body.removeChild(textarea);
          toast.success(t(successKey));
        }
      },
      [t],
    );

    const cell = (
      <div
        onClick={handleClick}
        role={isSelectable ? "button" : undefined}
        tabIndex={isSelectable ? 0 : undefined}
        onKeyDown={(event) => {
          if (isSelectable && (event.key === "Enter" || event.key === " ")) {
            event.preventDefault();
            handleClick();
          }
        }}
        aria-label={
          hasPackage
            ? `${t("lockerDetail.door")} ${door.door_number ?? door.rank_order}. ${t("lockerDetail.packageContext.hasPackage")}`
            : isSelectable
              ? `Abrir acciones de soporte para la puerta ${door.door_number ?? door.rank_order}`
              : undefined
        }
        className={`
          ${STATUS_CLASS[statusKey] || "bg-muted"}
          border
          rounded-md
          backdrop-blur-sm
          flex items-center justify-center
          text-[11px] font-semibold
          ${
            isSelectable
              ? "cursor-pointer hover:scale-[1.03] hover:shadow-lg hover:shadow-black/10 dark:hover:shadow-white/5"
              : hasPackage
                ? "cursor-context-menu hover:scale-[1.02] hover:shadow-md"
                : "cursor-default"
          }
          transition-all duration-200
        `}
        style={style}
      >
        <span className="text-foreground">{door.rank_order}</span>
      </div>
    );

    if (!hasPackage) return cell;

    return (
      <ContextMenu>
        <ContextMenuTrigger asChild>{cell}</ContextMenuTrigger>

        <ContextMenuContent className="w-[320px] overflow-hidden rounded-xl p-0 shadow-xl">
          <div className="border-b border-border bg-muted/30 px-4 py-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex min-w-0 items-center gap-2">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Package className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-foreground">
                    {t("lockerDetail.packageContext.title")}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    {t("lockerDetail.door")} {door.door_number ?? door.rank_order}
                    {door.compartment_name ? ` · ${door.compartment_name}` : ""}
                  </p>
                </div>
              </div>

              <span
                className={`shrink-0 rounded-full border px-2 py-1 text-[10px] font-semibold ${packageStatusBadgeClass}`}
              >
                {packageStatusLabel}
              </span>
            </div>
          </div>

          <div className="space-y-2 px-4 py-3 text-xs">
            <PackageContextRow
              icon={<Hash className="h-3.5 w-3.5" />}
              label={t("lockerDetail.packageContext.order")}
              value={packageInfo?.order_number || "---"}
            />
            <PackageContextRow
              icon={<Box className="h-3.5 w-3.5" />}
              label={t("lockerDetail.tracking")}
              value={packageInfo?.tracking_number || "---"}
            />
            <PackageContextRow
              icon={<UserRound className="h-3.5 w-3.5" />}
              label={t("lockerDetail.packageContext.recipient")}
              value={recipientName}
            />
            <PackageContextRow
              icon={<Package className="h-3.5 w-3.5" />}
              label={t("lockerDetail.packageContext.service")}
              value={packageInfo?.name_service || "---"}
            />
            {isSuperUser && (
              <PackageContextRow
                icon={<Hash className="h-3.5 w-3.5" />}
                label={t("lockerDetail.packageContext.packageId")}
                value={packageInfo?.id_package ?? "---"}
              />
            )}
          </div>

          <ContextMenuSeparator className="m-0" />

          <div className="p-1.5">
            {onSearchPackageInTable && (
              <ContextMenuItem
                className="gap-2 rounded-lg"
                onSelect={() => onSearchPackageInTable(packageInfo)}
              >
                <Search className="h-4 w-4 text-muted-foreground" />
                {t("lockerDetail.packageContext.searchInTable")}
              </ContextMenuItem>
            )}

            {idService && (
              <ContextMenuItem
                className="gap-2 rounded-lg"
                onSelect={() => navigate(`/orders/${idService}`)}
              >
                <ExternalLink className="h-4 w-4 text-muted-foreground" />
                {t("lockerDetail.packageContext.viewDetail")}
              </ContextMenuItem>
            )}

            {packageInfo?.tracking_number && (
              <ContextMenuItem
                className="gap-2 rounded-lg"
                onSelect={() =>
                  copyToClipboard(
                    packageInfo.tracking_number,
                    "lockerDetail.packageContext.trackingCopied",
                  )
                }
              >
                <Copy className="h-4 w-4 text-muted-foreground" />
                {t("lockerDetail.packageContext.copyTracking")}
              </ContextMenuItem>
            )}

            {packageInfo?.order_number && (
              <ContextMenuItem
                className="gap-2 rounded-lg"
                onSelect={() =>
                  copyToClipboard(
                    packageInfo.order_number,
                    "lockerDetail.packageContext.orderCopied",
                  )
                }
              >
                <Copy className="h-4 w-4 text-muted-foreground" />
                {t("lockerDetail.packageContext.copyOrder")}
              </ContextMenuItem>
            )}

            {packageInfo?.url_evidence && (
              <ContextMenuItem
                className="gap-2 rounded-lg"
                onSelect={() =>
                  window.open(packageInfo.url_evidence, "_blank", "noopener,noreferrer")
                }
              >
                <ExternalLink className="h-4 w-4 text-muted-foreground" />
                {t("lockerDetail.packageContext.viewEvidence")}
              </ContextMenuItem>
            )}
          </div>
        </ContextMenuContent>
      </ContextMenu>
    );
  },

  /* 👇 ESTO ES LO QUE ELIMINA LOS RERENDERS */
  (prev, next) => {
    const prevPackage = prev.door.PACKAGE?.[0];
    const nextPackage = next.door.PACKAGE?.[0];

    return (
      prev.door.door_number === next.door.door_number &&
      prev.door.id_locker_dimension === next.door.id_locker_dimension &&
      prev.door.name_status === next.door.name_status &&
      prev.door.compartment_name === next.door.compartment_name &&
      prevPackage?.id_package === nextPackage?.id_package &&
      prevPackage?.order_number === nextPackage?.order_number &&
      prevPackage?.tracking_number === nextPackage?.tracking_number &&
      prevPackage?.first_name === nextPackage?.first_name &&
      prevPackage?.surname === nextPackage?.surname &&
      prevPackage?.id_status === nextPackage?.id_status &&
      prevPackage?.status_package === nextPackage?.status_package &&
      prevPackage?.id_status_package === nextPackage?.id_status_package &&
      prevPackage?.id_status_code_package === nextPackage?.id_status_code_package &&
      prevPackage?.status_name === nextPackage?.status_name &&
      prevPackage?.name_service === nextPackage?.name_service &&
      prevPackage?.url_evidence === nextPackage?.url_evidence &&
      prevPackage?.id_service === nextPackage?.id_service &&
      prev.onLockerSelected === next.onLockerSelected &&
      prev.canSelectDoor === next.canSelectDoor &&
      prev.isSuperUser === next.isSuperUser &&
      prev.onSearchPackageInTable === next.onSearchPackageInTable
    );
  },
);

function PackageContextRow({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="grid grid-cols-[18px_86px_1fr] items-start gap-2">
      <span className="mt-0.5 text-muted-foreground">{icon}</span>
      <span className="text-muted-foreground">{label}</span>
      <span className="min-w-0 break-words text-right font-medium text-foreground">
        {value}
      </span>
    </div>
  );
}

LockerCell.displayName = "LockerCell";
