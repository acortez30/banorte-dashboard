import { useState, useMemo, useEffect } from "react";
import { Link } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { toast } from "sonner";
import { useLanguage } from "@/contexts/LanguageContext";
import { Pencil, Trash2, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";

import { unitsService } from "@/services/units.service";
import { clientsService } from "@/services/client.service";
import { parseExcelFile } from "@/lib/exportUtils";


import { UnitsKPIs } from "@/components/units/UnitsKPIs";
import { UnitsHeader } from "@/components/units/UnitsHeader";
import { AddUnitDialog } from "@/components/units/AddUnitDialog";
import { DeleteUnitDialog } from "@/components/units/DeleteUnitDialog";
import { AddResidentDialog } from "@/components/units/AddResidentDialog";
import { EditUnitDialog } from "@/components/units/EditUnitDialog";
import {
  ImportUnitsResultDialog,
  type UnitImportResultItem,
} from "@/components/units/ImportUnitsResultDialog";
import { Column } from "@/components/ui/types";
import { GenericTable } from "@/components/ui/GenericTable";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";

interface Unit {
  id: number;
  number: string;
  code: string;
  registeredUsers: number;
  activeUsers: number;
  packagesMonth: number;
  packagesTotal: number;
}

export default function Units() {
  const { t, language } = useLanguage();

  const [units, setUnits] = useState<Unit[]>([]);
  const [loading, setLoading] = useState(false);

  const [addUnitOpen, setAddUnitOpen] = useState(false);
  const [addClientOpen, setAddClientOpen] = useState(false);
  const [selectedUnit, setSelectedUnit] = useState<Unit | null>(null);

  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editUnit, setEditUnit] = useState<Unit | null>(null);
  const [editLoading, setEditLoading] = useState(false);

  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<{ id: number | null; number: string }>({
    id: null,
    number: "",
  });
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [residentLoading, setResidentLoading] = useState(false);
  const [importResultsOpen, setImportResultsOpen] = useState(false);
  const [importResults, setImportResults] = useState<UnitImportResultItem[]>([]);

  const companyData = JSON.parse(localStorage.getItem("company") || "{}");
  const propertyId = companyData?.id_propierty;
  const lang = language;

  /* ========================= */
  /* ===== EXPORT HEADERS ==== */
  /* ========================= */

  const exportHeaders = [
    { key: "number",          label: "Unidad"               },
    { key: "code",            label: "Código"               },
    { key: "registeredUsers", label: "Usuarios Registrados" },
    { key: "activeUsers",     label: "Usuarios Activos"     },
    { key: "packagesMonth",   label: "Paquetes del Mes"     },
    { key: "packagesTotal",   label: "Total Paquetes"       },
  ];

  /* ========================= */
  /* ===== IMPORT ============ */
  /* ========================= */

  const handleImport = async (file: File): Promise<void> => {
    if (!propertyId) {
      toast.error(t("units.import.invalidProperty"));
      return;
    }

    const showResults = (results: UnitImportResultItem[]) => {
      setImportResults(results.sort((a, b) => a.row - b.row));
      setImportResultsOpen(true);
    };

    const normalizeHeader = (value: string) =>
      value
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .trim()
        .toLowerCase();

    const supportedHeaders = new Set([
      "unidad",
      "unit",
      "numero de unidad",
      "unit number",
    ]);

    const readUnitValue = (row: Record<string, unknown>) => {
      const unitKey = Object.keys(row).find((key) =>
        supportedHeaders.has(normalizeHeader(key)),
      );

      return unitKey ? String(row[unitKey] ?? "").trim() : "";
    };

    // Permite identificadores como AIM101, 1000, TH 7 y A-101.
    const isValidUnit = (value: string) =>
      /^[A-Za-z0-9]+(?:[ -][A-Za-z0-9]+)*$/.test(value.trim());

    try {
      const rows = await parseExcelFile(file);

      if (rows.length === 0) {
        showResults([
          {
            row: 1,
            unit: "",
            status: "error",
            message: t("units.import.error.noRows"),
          },
        ]);
        return;
      }

      const hasSupportedColumn = rows.some((row) =>
        Object.keys(row).some((key) => supportedHeaders.has(normalizeHeader(key))),
      );

      if (!hasSupportedColumn) {
        showResults([
          {
            row: 1,
            unit: "",
            status: "error",
            message: t("units.import.error.missingColumn"),
          },
        ]);
        return;
      }

      const results: UnitImportResultItem[] = [];
      const candidates: { row: number; unit: string }[] = [];
      const existingUnits = new Set(
        units
          .map((unit) => unit.number?.trim().toUpperCase())
          .filter(Boolean),
      );
      const seenInFile = new Set<string>();

      rows.forEach((row, index) => {
        const excelRow = index + 2;
        const rawUnit = readUnitValue(row);
        const unit = rawUnit.toUpperCase();

        if (!rawUnit) {
          results.push({
            row: excelRow,
            unit: "",
            status: "error",
            message: t("units.import.error.empty"),
          });
          return;
        }

        if (!isValidUnit(rawUnit)) {
          results.push({
            row: excelRow,
            unit: rawUnit,
            status: "error",
            message: t("units.import.error.invalidFormat"),
          });
          return;
        }

        if (seenInFile.has(unit)) {
          results.push({
            row: excelRow,
            unit,
            status: "skipped",
            message: t("units.import.error.duplicateFile"),
          });
          return;
        }

        seenInFile.add(unit);

        if (existingUnits.has(unit)) {
          results.push({
            row: excelRow,
            unit,
            status: "skipped",
            message: t("units.import.error.alreadyExists"),
          });
          return;
        }

        candidates.push({ row: excelRow, unit });
      });

      // Se procesa por unidad para que un error del backend no cancele las demás.
      // La concurrencia limitada evita saturar el endpoint en archivos grandes.
      const IMPORT_CONCURRENCY = 6;

      for (let start = 0; start < candidates.length; start += IMPORT_CONCURRENCY) {
        const batch = candidates.slice(start, start + IMPORT_CONCURRENCY);

        const batchResults = await Promise.all(
          batch.map(async (candidate): Promise<UnitImportResultItem> => {
            try {
              await unitsService.postUnit(propertyId, 0, {
                units: [{ unit: candidate.unit }],
              });

              return {
                row: candidate.row,
                unit: candidate.unit,
                status: "success",
                message: t("units.import.success.created"),
              };
            } catch (error) {
              console.error(`Error importing unit ${candidate.unit}:`, error);

              return {
                row: candidate.row,
                unit: candidate.unit,
                status: "error",
                message:
                  error instanceof Error && error.message
                    ? error.message
                    : t("units.import.error.server"),
              };
            }
          }),
        );

        results.push(...batchResults);
      }

      const importedCount = results.filter(
        (result) => result.status === "success",
      ).length;
      const notImportedCount = results.length - importedCount;

      if (importedCount > 0) {
        try {
          await refreshUnits();
        } catch (refreshError) {
          console.error("Error refreshing units after import:", refreshError);
        }
      }

      showResults(results);

      if (importedCount === results.length) {
        toast.success(t("units.import.toast.success", { count: importedCount }));
      } else if (importedCount > 0) {
        toast.warning(
          t("units.import.toast.partial", {
            success: importedCount,
            failed: notImportedCount,
          }),
        );
      } else {
        toast.error(t("units.import.toast.none"));
      }
    } catch (error) {
      console.error(error);
      showResults([
        {
          row: 1,
          unit: "",
          status: "error",
          message:
            error instanceof Error && error.message
              ? error.message
              : t("units.import.error.readFile"),
        },
      ]);
      toast.error(t("units.import.toast.none"));
    }
  };

  const refreshUnits = async () => {
    if (!propertyId) return;
    const updated = await unitsService.getAllUnits(propertyId, lang);
    setUnits(updated);
  };

  /* ========================= */
  /* ===== FETCH ============= */
  /* ========================= */

  useEffect(() => {
    if (!propertyId) return;

    const fetchUnits = async () => {
      try {
        setLoading(true);
        const response = await unitsService.getAllUnits(propertyId, lang);
        setUnits(response);
      } catch (error) {
        console.error(error);
        toast.error("Error al cargar unidades");
      } finally {
        setLoading(false);
      }
    };

    fetchUnits();
  }, [propertyId]);

  /* ========================= */
  /* ===== COLUMNS =========== */
  /* ========================= */

  const columns: Column<Unit>[] = useMemo(() => [
    {
      key: "number",
      header: t("units.unitNumber"),
      sortable: true,
      render: (row) => (
        <Link to={`/units/${row.id}`} className="text-primary font-medium">
          {row.number}
        </Link>
      ),
    },
    {
      key: "code",
      header: t("units.unitCode"),
      sortable: true,
      render: (row) => (
        <span className="text-muted-foreground">{row.code}</span>
      ),
    },
    {
      key: "registeredUsers",
      header: t("units.registeredUsers"),
      sortable: true,
    },
    {
      key: "activeUsers",
      header: t("units.activeUsers"),
      sortable: true,
    },
    {
      key: "packagesMonth",
      header: t("units.packagesThisMonth"),
      sortable: true,
    },
    {
      key: "packagesTotal",
      header: t("units.totalPackages"),
      sortable: true,
    },
    {
      key: "id", // key dummy — se usa render
      header: t("units.actions"),
      sortable: false,
      render: (row) => (
        <div className="flex items-center gap-1">

          {/* Botón EDITAR */}
    <Button
      size="icon"
      variant="ghost"
      className="h-8 w-8 text-muted-foreground hover:text-foreground"
      onClick={(e) => {
        e.stopPropagation();
        setEditUnit(row);
        setEditModalOpen(true);
      }}
    >
      <Pencil className="h-4 w-4" />
    </Button>
    
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
            onClick={(e) => {
              e.stopPropagation();
              setDeleteTarget({ id: row.id, number: row.number });
              setDeleteModalOpen(true);
            }}
          >
            <Trash2 className="h-4 w-4" />
          </Button>

          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8 text-muted-foreground hover:text-foreground"
            onClick={(e) => {
              e.stopPropagation();
              setSelectedUnit(row);
              setAddClientOpen(true);
            }}
          >
            <UserPlus className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ], [t]);

  /* ========================= */
  /* ===== RENDER ============ */
  /* ========================= */

  if (loading) {
    return (
      <DashboardLayout>
        <LoadingSpinner fullPage text={t("common.loading")} />
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">

        <UnitsHeader
          units={units as any}
          exportHeaders={exportHeaders}
          onImport={handleImport}
          onAddUnit={() => setAddUnitOpen(true)}
        />

        <UnitsKPIs units={units} />

        <GenericTable<Unit>
          data={units}
          columns={columns}
          loading={loading}
          enableSearch
          enableDateRange={false}
          searchFields={["number", "code"]}
          defaultSort={{ key: "number", direction: "asc" }}
          pageSizeOptions={[10, 25, 50, 100]}
          defaultPageSize={10}
        />

      </div>

      {/* MODALS */}

      <AddUnitDialog
        open={addUnitOpen}
        onClose={() => setAddUnitOpen(false)}
        onCreate={async (unitNumber) => {
          if (!propertyId) {
            toast.error("Propiedad no válida");
            return;
          }

          try {
            setLoading(true);

            const exists = units.some(
              (u) => u.number.toLowerCase() === unitNumber.toLowerCase()
            );

            if (exists) {
              toast.error("La unidad ya existe");
              return;
            }

            await unitsService.postUnit(propertyId, 0, {
              units: [{ unit: unitNumber }],
            });

            const updated = await unitsService.getAllUnits(propertyId, lang);
            setUnits(updated);

            toast.success("Unidad creada correctamente");
            setAddUnitOpen(false);
          } catch (error) {
            console.error(error);
            toast.error("Error al crear la unidad");
          } finally {
            setLoading(false);
          }
        }}
      />

      <AddResidentDialog
        open={addClientOpen}
        unit={selectedUnit}
        loading={residentLoading}
        onClose={() => setAddClientOpen(false)}
        onSubmit={async (data) => {
          if (!selectedUnit || !propertyId) return;

          setResidentLoading(true);

          try {
            await clientsService.registerConsumerFromUnit(
              propertyId,
              selectedUnit.id,
              data
            );

            const updated = await unitsService.getAllUnits(propertyId, lang);
            setUnits(updated);

            toast.success("Residente agregado correctamente");
            setAddClientOpen(false);
          } catch {
            toast.error("Error al registrar residente");
          } finally {
            setResidentLoading(false);
          }
        }}
      />

      <DeleteUnitDialog
        open={deleteModalOpen}
        unit={deleteTarget}
        loading={deleteLoading}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={async (unitId) => {
          if (!propertyId) return;

          setDeleteLoading(true);

          try {
            await unitsService.deleteUnit(propertyId, unitId);
            await refreshUnits();
            toast.success("Unidad eliminada correctamente");
            setDeleteModalOpen(false);
          } catch {
            toast.error("Error al eliminar unidad");
          } finally {
            setDeleteLoading(false);
          }
        }}
      />

      <EditUnitDialog
        open={editModalOpen}
        unit={editUnit}
        loading={editLoading}
        onClose={() => setEditModalOpen(false)}
        onConfirm={async (unitId, newUnit) => {
          if (!propertyId) return;

          setEditLoading(true);

          try {
            const exists = units.some(
              (u) =>
                u.number.toLowerCase() === newUnit.toLowerCase() &&
                u.id !== unitId
            );

            if (exists) {
              toast.error("La unidad ya existe");
              return;
            }

            await unitsService.editUnit(propertyId, unitId, {
              unit: { unit: newUnit },
            });

            await refreshUnits();
            toast.success("Unidad actualizada correctamente");
            setEditModalOpen(false);
          } catch (error) {
            console.error(error);
            toast.error("Error al actualizar la unidad");
          } finally {
            setEditLoading(false);
          }
        }}
      />

      <ImportUnitsResultDialog
        open={importResultsOpen}
        onOpenChange={setImportResultsOpen}
        results={importResults}
      />


    </DashboardLayout>
  );
}