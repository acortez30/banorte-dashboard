import { memo, useMemo, useState, type ReactNode } from "react"
import { useNavigate } from "react-router-dom"
import {
  ArrowLeft,
  Boxes,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Loader2,
  MapPin,
  RotateCcw,
  Save,
  Server,
} from "lucide-react"

import { DashboardLayout } from "@/components/layout/DashboardLayout"
import { WizardModuleBuilder } from "@/components/locker-wizard/WizardModuleBuilder"
import { WizardSidebar } from "@/components/locker-wizard/WizardSidebar"
import { WizardStep1 } from "@/components/locker-wizard/WizardStep1"
import { WizardStep2 } from "@/components/locker-wizard/WizardStep2"
import { WizardStep3 } from "@/components/locker-wizard/WizardStep3"
import { WizardStep4 } from "@/components/locker-wizard/WizardStep4"
import { WizardStep5 } from "@/components/locker-wizard/WizardStep5"

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

import {
  WIZARD_STEPS,
  type WizardStepId,
} from "@/features/locker-create/locker-create.config"
import { useLockerCatalogs } from "@/features/locker-create/useLockerCatalogs"
import { useLockerWizard } from "@/features/locker-create/useLockerWizard"

export type { LockerFormState } from "@/features/locker-create/locker-create.types"
export { WIZARD_STEPS } from "@/features/locker-create/locker-create.config"

const MemoStep1 = memo(WizardStep1)
const MemoStep2 = memo(WizardStep2)
const MemoStep3 = memo(WizardStep3)
const MemoStep4 = memo(WizardStep4)
const MemoStep5 = memo(WizardStep5)
const MemoModuleBuilder = memo(WizardModuleBuilder)

const BUILDER_STEP = WIZARD_STEPS.length as WizardStepId
const DATA_STEP_COUNT = WIZARD_STEPS.length - 1

export const LockerAdd = () => {
  const navigate = useNavigate()
  const wizard = useLockerWizard()
  const catalogs = useLockerCatalogs()

  const [cancelDialogOpen, setCancelDialogOpen] = useState(false)
  const [resetDialogOpen, setResetDialogOpen] = useState(false)
  const [saveDialogOpen, setSaveDialogOpen] = useState(false)

  const isBuilderMode = wizard.currentStep === BUILDER_STEP
  const isLastDataStep = wizard.currentStep === DATA_STEP_COUNT

  const currentStepConfig = WIZARD_STEPS.find(
    (step) => step.id === wizard.currentStep,
  )

  const selectedModules = useMemo(() => {
    return wizard.selectedModuleIds
      .map((id) =>
        catalogs.modules.find((module) => module.id_locker_module === id),
      )
      .filter(Boolean)
  }, [catalogs.modules, wizard.selectedModuleIds])

  const selectedDoorCount = useMemo(
    () =>
      selectedModules.reduce(
        (total, module) => total + Number(module?.door_total ?? 0),
        0,
      ),
    [selectedModules],
  )

  const handleCancel = () => {
    if (wizard.isDirty) {
      setCancelDialogOpen(true)
      return
    }
    navigate(-1)
  }

  const confirmCancel = () => {
    wizard.clearDraft()
    setCancelDialogOpen(false)
    navigate(-1)
  }

  const renderDataStep = (step: WizardStepId) => {
    switch (step) {
      case 1:
        return (
          <MemoStep1
            form={wizard.form}
            updateForm={wizard.updateForm}
            lockerTypes={catalogs.lockerTypes}
            lockerEnvironments={catalogs.lockerEnvironments}
            lockerModels={catalogs.lockerModels}
            lockerPrivacy={catalogs.lockerPrivacy}
            states={catalogs.states}
            cities={catalogs.cities}
            loadCities={catalogs.loadCities}
          />
        )

      case 2:
        return <MemoStep2 form={wizard.form} updateForm={wizard.updateForm} />

      case 3:
        return <MemoStep3 form={wizard.form} updateForm={wizard.updateForm} />

      case 4:
        return (
          <MemoStep4
            form={wizard.form}
            updatePcLocker={wizard.updatePcLocker}
            updateApLocker={wizard.updateApLocker}
          />
        )

      case 5:
        return <MemoStep5 form={wizard.form} updateForm={wizard.updateForm} />

      default:
        return null
    }
  }

  if (catalogs.loading) {
    return (
      <DashboardLayout>
        <PageState
          icon={<Loader2 className="h-8 w-8 animate-spin text-primary" />}
          title="Preparando nuevo locker"
          description="Estamos cargando tipos, modelos, ubicaciones y módulos disponibles."
        />
      </DashboardLayout>
    )
  }

  if (catalogs.error) {
    return (
      <DashboardLayout>
        <PageState
          icon={<Server className="h-8 w-8 text-destructive" />}
          title="No pudimos cargar el configurador"
          description={catalogs.error}
          action={
            <Button variant="outline" onClick={catalogs.retry}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Reintentar
            </Button>
          }
        />
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="flex h-[calc(100vh-80px)] min-h-[680px] flex-col bg-muted/20">
        {/* =====================================================
            HEADER
            En el constructor ya no mostramos "Paso 6 de 6" como si fuera
            otro formulario: es una etapa final independiente.
        ====================================================== */}
        <header className="z-20 shrink-0 border-b bg-background/95 backdrop-blur">
          <div className="px-4 py-4 sm:px-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex min-w-0 items-start gap-3">
                <Button
                  variant="ghost"
                  size="icon"
                  className="mt-0.5 shrink-0"
                  onClick={
                    isBuilderMode
                      ? () => wizard.goToStep(DATA_STEP_COUNT)
                      : handleCancel
                  }
                  disabled={wizard.saving}
                  aria-label={isBuilderMode ? "Volver a datos" : "Volver"}
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>

                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h1 className="text-xl font-semibold tracking-tight">
                      {isBuilderMode ? "Construye tu locker" : "Nuevo locker"}
                    </h1>

                    {isBuilderMode ? (
                      <Badge className="gap-1 border-emerald-500/20 bg-emerald-500/10 text-emerald-700 hover:bg-emerald-500/10 dark:text-emerald-300">
                        <CheckCircle2 className="h-3 w-3" />
                        Configuración completa
                      </Badge>
                    ) : (
                      wizard.hasRestoredDraft && (
                        <Badge variant="secondary">Borrador restaurado</Badge>
                      )
                    )}
                  </div>

                  <p className="mt-1 text-sm text-muted-foreground">
                    {isBuilderMode
                      ? `${wizard.form.locker_name || "Nuevo locker"} · Paso final: distribución física`
                      : `Paso ${wizard.currentStep} de ${DATA_STEP_COUNT}${
                          currentStepConfig ? ` · ${currentStepConfig.name}` : ""
                        }`}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end md:self-auto">
                <Badge
                  variant="outline"
                  className={
                    isBuilderMode
                      ? "border-emerald-500/30 bg-emerald-500/5 text-emerald-700 tabular-nums dark:text-emerald-300"
                      : "tabular-nums"
                  }
                >
                  {Math.round(wizard.progress)}%
                </Badge>

                {wizard.isDirty && !isBuilderMode && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setResetDialogOpen(true)}
                    disabled={wizard.saving}
                  >
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Reiniciar
                  </Button>
                )}

                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleCancel}
                  disabled={wizard.saving}
                >
                  Cancelar
                </Button>
              </div>
            </div>

            <div className="mt-4">
              <Progress value={wizard.progress} className="h-1.5" />
            </div>
          </div>
        </header>

        {/* =====================================================
            BODY
            Pasos 1–5: sidebar + formulario.
            Constructor: ocupa TODO el ancho disponible.
        ====================================================== */}
        <div className="flex min-h-0 flex-1">
          {!isBuilderMode && (
            <aside className="hidden shrink-0 border-r bg-background lg:block lg:w-[280px]">
              <WizardSidebar
                currentStep={wizard.currentStep}
                onStepClick={wizard.goToStep}
                completedSteps={wizard.completedSteps}
                stepValidation={wizard.stepValidation}
                errors={wizard.errors}
                isSaving={wizard.saving}
              />
            </aside>
          )}

          <main className="flex min-w-0 flex-1 flex-col overflow-hidden">
            {isBuilderMode ? (
              <>
                {/* Barra compacta: sustituye el resumen grande para dejar el
                    máximo espacio posible al canvas. */}
                <BuilderIdentityBar
                  name={wizard.form.locker_name}
                  serial={wizard.form.serial_locker}
                  address={wizard.form.locker_address}
                  moduleCount={wizard.selectedModuleIds.length}
                  doorCount={selectedDoorCount}
                  onEditData={() => wizard.goToStep(DATA_STEP_COUNT)}
                />

                <div className="min-h-0 flex-1 overflow-hidden">
                  <MemoModuleBuilder
                    modules={catalogs.modules}
                    selectedModuleIds={wizard.selectedModuleIds}
                    onModulesChange={wizard.setSelectedModuleIds}
                    fullHeight
                  />
                </div>
              </>
            ) : (
              <div className="min-h-0 flex-1 overflow-y-auto px-4 py-6 sm:px-6 lg:px-8">
                <div className="mx-auto w-full max-w-[1480px]">
                  <div className="mb-6">
                    <h2 className="text-lg font-semibold">
                      {currentStepConfig?.name}
                    </h2>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {currentStepConfig?.description}
                    </p>
                  </div>

                  {renderDataStep(wizard.currentStep)}
                </div>
              </div>
            )}

            {/* =================================================
                FOOTER
            ================================================== */}
            <footer className="z-10 shrink-0 border-t bg-background/95 px-4 py-4 backdrop-blur sm:px-6">
              <div className="flex w-full items-center justify-between gap-3">
                <Button
                  variant="outline"
                  onClick={
                    isBuilderMode
                      ? () => wizard.goToStep(DATA_STEP_COUNT)
                      : wizard.goToPreviousStep
                  }
                  disabled={
                    (!isBuilderMode && wizard.currentStep === 1) || wizard.saving
                  }
                >
                  <ChevronLeft className="mr-2 h-4 w-4" />
                  {isBuilderMode ? "Volver a datos" : "Anterior"}
                </Button>

                <div className="hidden text-xs text-muted-foreground md:block">
                  {isBuilderMode
                    ? "Los datos ya están completos. Diseña la distribución física final del locker."
                    : isLastDataStep && wizard.dataStepsComplete
                      ? "Configuración completa. Continúa para construir el locker."
                      : wizard.isDirty
                        ? "Los cambios se guardan como borrador en este navegador."
                        : "Completa la información para continuar."}
                </div>

                {isBuilderMode ? (
                  <Button
                    onClick={() => setSaveDialogOpen(true)}
                    disabled={wizard.saving || wizard.selectedModuleIds.length === 0}
                  >
                    {wizard.saving ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="mr-2 h-4 w-4" />
                    )}
                    {wizard.saving ? "Guardando..." : "Guardar locker"}
                  </Button>
                ) : (
                  <Button
                    onClick={wizard.goToNextStep}
                    disabled={wizard.saving}
                  >
                    {isLastDataStep ? (
                      <>
                        Construir locker
                        <Boxes className="ml-2 h-4 w-4" />
                      </>
                    ) : (
                      <>
                        Siguiente
                        <ChevronRight className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                )}
              </div>
            </footer>
          </main>
        </div>
      </div>

      <AlertDialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Salir de la creación del locker?</AlertDialogTitle>
            <AlertDialogDescription>
              Tienes cambios sin finalizar. Si sales, eliminaremos el borrador de este locker.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Continuar editando</AlertDialogCancel>
            <AlertDialogAction onClick={confirmCancel}>
              Salir y descartar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Reiniciar el formulario?</AlertDialogTitle>
            <AlertDialogDescription>
              Se borrarán los datos ingresados, los módulos seleccionados y el borrador guardado.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                wizard.resetWizard()
                setResetDialogOpen(false)
              }}
            >
              Reiniciar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Crear nuevo locker</AlertDialogTitle>
            <AlertDialogDescription>
              Se creará <strong>{wizard.form.locker_name || "este locker"}</strong> con{" "}
              {wizard.selectedModuleIds.length} módulo(s) y aproximadamente {selectedDoorCount} puerta(s).
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={wizard.saving}>Revisar</AlertDialogCancel>
            <AlertDialogAction
              disabled={wizard.saving}
              onClick={async (event) => {
                event.preventDefault()
                const created = await wizard.handleSave()
                if (created) setSaveDialogOpen(false)
              }}
            >
              {wizard.saving && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Crear locker
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  )
}

function BuilderIdentityBar({
  name,
  serial,
  address,
  moduleCount,
  doorCount,
  onEditData,
}: {
  name: string
  serial: string
  address: string
  moduleCount: number
  doorCount: number
  onEditData: () => void
}) {
  return (
    <section className="shrink-0 border-b bg-card px-4 py-3 sm:px-6">
      <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-base font-semibold">Distribución física final</h2>
            <Badge variant="outline" className="text-[10px]">
              Constructor
            </Badge>
          </div>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Agrega, duplica y reordena módulos. Esta distribución será la base del mapa de puertas.
          </p>
        </div>

        <div className="flex min-w-0 flex-wrap items-center gap-2">
          <BuilderInfo
            icon={<Server className="h-3.5 w-3.5" />}
            label="Locker"
            value={name || "Sin nombre"}
          />
          <BuilderInfo
            icon={<Server className="h-3.5 w-3.5" />}
            label="Serie"
            value={serial || "Sin serie"}
          />
          <BuilderInfo
            icon={<MapPin className="h-3.5 w-3.5" />}
            label="Ubicación"
            value={address || "Sin dirección"}
            wide
          />

          <div className="flex h-9 items-center gap-3 rounded-lg border bg-muted/10 px-3 text-[11px]">
            <span>
              <span className="text-muted-foreground">Módulos</span>{" "}
              <b className="tabular-nums">{moduleCount}</b>
            </span>
            <span>
              <span className="text-muted-foreground">Puertas</span>{" "}
              <b className="tabular-nums">{doorCount}</b>
            </span>
          </div>

          <Button variant="ghost" size="sm" onClick={onEditData}>
            Editar datos
          </Button>
        </div>
      </div>
    </section>
  )
}

function BuilderInfo({
  icon,
  label,
  value,
  wide = false,
}: {
  icon: ReactNode
  label: string
  value: string
  wide?: boolean
}) {
  return (
    <div
      className={`hidden h-9 min-w-0 items-center gap-2 rounded-lg border bg-background px-2.5 lg:flex ${
        wide ? "max-w-[360px]" : "max-w-[220px]"
      }`}
      title={value}
    >
      <span className="shrink-0 text-primary">{icon}</span>
      <div className="min-w-0">
        <p className="text-[8px] font-medium uppercase tracking-wide text-muted-foreground">
          {label}
        </p>
        <p className="truncate text-[11px] font-medium">{value}</p>
      </div>
    </div>
  )
}

function PageState({
  icon,
  title,
  description,
  action,
}: {
  icon: ReactNode
  title: string
  description: string
  action?: ReactNode
}) {
  return (
    <div className="flex min-h-[calc(100vh-80px)] items-center justify-center p-6">
      <div className="w-full max-w-md rounded-xl border bg-card p-8 text-center shadow-sm">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-muted">
          {icon}
        </div>
        <h2 className="font-semibold">{title}</h2>
        <p className="mt-2 text-sm text-muted-foreground">{description}</p>
        {action && <div className="mt-5">{action}</div>}
      </div>
    </div>
  )
}

export default LockerAdd
