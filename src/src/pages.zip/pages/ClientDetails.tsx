import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  Link,
  useNavigate,
  useParams,
} from "react-router-dom";
import { ArrowLeft } from "lucide-react";

import { ExtendPackageAction } from "@/components/package-actions/ExtendPackageAction";
import { toast } from "sonner";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { PackageQueryPanel } from "@/components/Orders/PackageQueryPanel";
import type { OrdersStatusTabValue } from "@/components/Orders/OrdersStatusTabs";
import type {
  OrdersPriorityStatusValue,
  OrdersSortByValue,
} from "@/components/Orders/OrdersTableToolbar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useLanguage } from "@/contexts/LanguageContext";
import { clientsService } from "@/services/client.service";
import { getStoredUser, isHouseAccountUser } from "@/utils/houseAccount";
import {
  ordersService,
  supportsOrdersQueryControls,
  type OrdersPriorityStatus,
  type OrdersQueryParams,
  type OrdersSortDir,
  type PackageSearchBy,
} from "@/services/orders.service";
import { KpiGrid } from "@/components/dashboard/KpiGrid";
import { KpiCard } from "@/components/dashboard/KpiCard";

/* =============================== */
/* HELPERS                         */
/* =============================== */

const safeValue = (
  value: unknown,
  fallback: unknown = "---",
): unknown => {
  if (
    value === null ||
    value === undefined ||
    value === "null" ||
    value === "undefined" ||
    value === ""
  ) {
    return fallback;
  }

  return value;
};

const normalizeArray = (value: unknown): any[] =>
  Array.isArray(value) ? value : [];

const readPaginationMeta = (
  response: any,
  fallbackLength: number,
  pageSize: number,
) => {
  const rawTotal =
    response?.total ??
    response?.pagination?.total ??
    response?.result?.total ??
    response?.meta?.total;

  const parsedTotal = Number(rawTotal);

  const total = Number.isFinite(parsedTotal)
    ? Math.max(0, parsedTotal)
    : fallbackLength;

  const rawTotalPages =
    response?.total_pages ??
    response?.pagination?.total_pages ??
    response?.pagination?.totalPages ??
    response?.result?.total_pages ??
    response?.meta?.total_pages;

  const parsedTotalPages = Number(rawTotalPages);

  const totalPages =
    Number.isFinite(parsedTotalPages) &&
    parsedTotalPages > 0
      ? parsedTotalPages
      : Math.max(
          1,
          Math.ceil(
            total / Math.max(1, pageSize),
          ),
        );

  return {
    total,
    totalPages,
  };
};

const getCompanyId = (): number | undefined => {
  try {
    const companyData = JSON.parse(
      localStorage.getItem("company") || "{}",
    );

    const parsedCompanyId = Number(
      companyData?.id_company,
    );

    if (
      Number.isFinite(parsedCompanyId) &&
      parsedCompanyId > 0
    ) {
      return parsedCompanyId;
    }
  } catch {
    return undefined;
  }

  return undefined;
};

function getDateRange() {
  const now = new Date();

  const start = new Date(
    now.getFullYear(),
    now.getMonth() - 1,
    1,
    0,
    0,
    0,
  );

  const end = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate(),
    23,
    59,
    59,
  );

  return {
    date_start: start.getTime(),
    date_end: end.getTime(),
  };
}

/* =============================== */
/* STATUS                          */
/* =============================== */

type OrderStatus =
  | "completed"
  | "expired"
  | "in_locker"
  | "in_transit"
  | "pending_validate"
  | "pending_payment"
  | "in_progress"
  | "returned"
  | "canceled_locker"
  | "canceled_picked"
  | "scheduled";

const STATUS_MAP: Record<string, OrderStatus> = {
  "16-18": "completed",
  "14-17": "in_locker",
  "47-17": "in_locker",
  "57-17": "in_locker",
  "14-32": "expired",
  "33-32": "returned",

  "49-17": "in_transit",
  "53-17": "in_transit",
  "97-17": "in_transit",
  "117-17": "in_transit",
  "179-17": "in_transit",

  "14-20": "canceled_locker",
  "33-20": "canceled_picked",
};

const SERVICE_STATUS_MAP: Record<number, OrderStatus> = {
  35: "scheduled",
  42: "pending_validate",
  12: "pending_payment",
  37: "in_transit",
};

const STATUS_LABELS_EN: Record<OrderStatus, string> = {
  completed: "Completed",
  expired: "Expired",
  in_locker: "In Locker",
  in_transit: "In transit",
  pending_validate: "Pending validation",
  pending_payment: "Pending payment",
  in_progress: "In progress",
  returned: "Returned",
  canceled_locker: "Canceled",
  canceled_picked: "Canceled",
  scheduled: "Scheduled",
};

const STATUS_LABELS_ES: Record<OrderStatus, string> = {
  completed: "Completado",
  expired: "Expirado",
  in_locker: "En Locker",
  in_transit: "En tránsito",
  pending_validate: "Pendiente de validar",
  pending_payment: "Pendiente de pago",
  in_progress: "En proceso",
  returned: "Devuelto",
  canceled_locker: "Cancelado",
  canceled_picked: "Cancelado",
  scheduled: "Agendado",
};

const getOrderStatus = (
  order: ClientOrder,
): OrderStatus => {
  if (order.statusType) {
    return order.statusType;
  }

  const key =
    `${order.statusCode}-${order.idStatusCodePackage}`;

  let status = STATUS_MAP[key];

  const normalizedStatusName = String(
    order.status ?? "",
  )
    .trim()
    .toUpperCase();

  const normalizedCodeStatusName = String(
    order.codeStatusName ?? "",
  )
    .trim()
    .toUpperCase();

  if (!status) {
    if (
      normalizedStatusName.includes("IN_TRANSIT") ||
      normalizedStatusName.includes("ROUTE") ||
      normalizedStatusName.includes("WAREHOUSE") ||
      normalizedStatusName.includes("CEDIS") ||
      normalizedStatusName.includes("ALMACEN") ||
      normalizedStatusName.includes("ALMACÉN") ||
      normalizedStatusName.includes("ASSIGNED_CARRIER") ||
      normalizedCodeStatusName === "ASIGNADO"
    ) {
      status = "in_transit";
    } else if (
      normalizedStatusName.includes("IN_LOCKER")
    ) {
      status = "in_locker";
    }
  }

  const serviceStatus = Number(
    order.idStatusService,
  );

  if (
    !status &&
    SERVICE_STATUS_MAP[serviceStatus]
  ) {
    status = SERVICE_STATUS_MAP[serviceStatus];
  }

  if (!status) {
    if (normalizedStatusName === "SCHEDULED") {
      return "scheduled";
    }

    if (
      normalizedStatusName === "TO_BE_APPROVED" ||
      normalizedStatusName === "PENDING_VALIDATE"
    ) {
      return "pending_validate";
    }

    if (
      normalizedStatusName === "PENDIENTE_POR_PAGO" ||
      normalizedStatusName === "PENDING_PAYMENT"
    ) {
      return "pending_payment";
    }

    return "in_progress";
  }

  return status;
};

/* =============================== */
/* TYPES                           */
/* =============================== */

interface Client {
  id: string;
  id_user: number;
  id_line_service?: number;
  userName: string;
  unitNumber: string;
  email: string;
  telephone: string;
  monthlyUsage: number;
  registrationDate: string;
  clientStatus: boolean;
  serviceStatus: boolean;
}

interface ClientOrder {
  tracking: string;
  locker: string;
  email: string;
  expirationDate?: string | null;
  status?: string;
  statusCode?: number | string;
  idStatusCodePackage?: number | string;
  idStatusService?: number | string;
  codeStatusName?: string;
  hasDebt?: boolean;
  statusType?: OrderStatus;
}

const InfoItem = ({
  label,
  value,
}: {
  label: string;
  value: string | number;
}) => (
  <div className="flex flex-col gap-0.5">
    <p className="text-[11px] font-semibold text-muted-foreground">
      {label}
    </p>
    <p className="text-xs font-medium text-foreground">
      {String(value)}
    </p>
  </div>
);

/* =============================== */
/* COMPONENT                       */
/* =============================== */

export default function ClientDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t, language } = useLanguage();

  const isHouseAccount = useMemo(
    () => isHouseAccountUser(getStoredUser()),
    [],
  );

  const [client, setClient] =
    useState<Client | null>(null);

  const [loading, setLoading] =
    useState(true);

  const [ordersLoading, setOrdersLoading] =
    useState(false);

  const [orders, setOrders] =
    useState<ClientOrder[]>([]);

  const [activeStatus, setActiveStatus] =
    useState<OrdersStatusTabValue>("all");

  const [searchQuery, setSearchQuery] =
    useState("");

  const [searchBy, setSearchBy] =
    useState<PackageSearchBy>("tracking");

  const [debouncedSearch, setDebouncedSearch] =
    useState("");

  const [sortBy, setSortBy] =
    useState<OrdersSortByValue>("default");

  const [sortDir, setSortDir] =
    useState<OrdersSortDir>("desc");

  const [priorityStatus, setPriorityStatus] =
    useState<OrdersPriorityStatusValue>("none");

  const [resultsPerPage, setResultsPerPage] =
    useState("10");

  const [page, setPage] =
    useState(1);

  const [total, setTotal] =
    useState(0);

  const [serverTotalPages, setServerTotalPages] =
    useState(1);

  const orderRequestIdRef =
    useRef(0);

  const {
    date_start,
    date_end,
  } = useMemo(
    () => getDateRange(),
    [],
  );

  const perPage = Number(resultsPerPage);

  const isServerSearch =
    debouncedSearch.length > 0;

  const usesQueryPackageCompany =
    !isServerSearch && supportsOrdersQueryControls(activeStatus);

  const usesServerPagination =
    usesQueryPackageCompany;

  const getOrderStatusLabel =
    useCallback(
      (order: ClientOrder): string => {
        const status =
          getOrderStatus(order);

        const labels =
          language === "es"
            ? STATUS_LABELS_ES
            : STATUS_LABELS_EN;

        return (
          labels[status] ||
          (language === "es"
            ? "Desconocido"
            : "Unknown")
        );
      },
      [language],
    );

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setDebouncedSearch(
        searchQuery.trim(),
      );
    }, 350);

    return () =>
      window.clearTimeout(timer);
  }, [searchQuery]);

  // search-packages no acepta id_consumer ni status_filter.
  // Durante una búsqueda mostramos la vista general y después validamos
  // por email para evitar mezclar paquetes de otros residentes.
  useEffect(() => {
    if (
      isServerSearch &&
      activeStatus !== "all"
    ) {
      setActiveStatus("all");
      setPage(1);
    }
  }, [activeStatus, isServerSearch]);

  /* =============================== */
  /* LOAD CLIENT                     */
  /* =============================== */

  useEffect(() => {
    if (!id) return;

    let cancelled = false;

    const loadClient = async () => {
      try {
        setLoading(true);

        const response =
          await clientsService.queryClients({
            page: 1,
            limit: 100,
          });

        if (cancelled) return;

        const backendClients =
          response?.result_return || [];

        const found =
          backendClients.find(
            (item: any) =>
              String(item.id_consumer) === id,
          );

        if (!found) {
          toast.error(
            t("clientDetail.clientNotFound"),
          );

          navigate("/clients");

          return;
        }

        const adaptedClient: Client = {
          id: String(found.id_consumer),
          id_user: found.id_user,
          id_line_service:
            found.lines_service?.[0]
              ?.id_line_service,
          userName: found.full_name,
          unitNumber: found.unit,
          email: found.email,
          telephone:
            found.main_tlf ?? "",
          monthlyUsage:
            found.packages
              ?.current_month_package ?? 0,
          registrationDate:
            found.registration_date ?? "",
          clientStatus:
            found.id_status_propierty === 1,
          serviceStatus:
            found.lines_service?.[0]
              ?.id_status_service_locker === 1,
        };

        setClient(adaptedClient);
      } catch (error: any) {
        if (cancelled) return;

        toast.error(
          error?.message ||
            t("common.error"),
        );
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    void loadClient();

    return () => {
      cancelled = true;
    };
  }, [
    id,
    navigate,
    t,
  ]);

  /* =============================== */
  /* LOAD ORDERS                     */
  /* =============================== */

  useEffect(() => {
    if (!client?.id) return;

    const requestId =
      ++orderRequestIdRef.current;

    const loadOrders = async () => {
      try {
        setOrdersLoading(true);

        let response: any;

        if (isServerSearch) {
          response =
            await ordersService.searchPackages({
              search_by: searchBy,
              search: debouncedSearch,
              page: 1,
              page_size: 200,
              language:
                language || "es",
            });
        } else {
          const params: OrdersQueryParams = {
            language:
              language || "es",
            id_company:
              getCompanyId(),
            id_consumer:
              client.id,
            date_start,
            date_end,
          };

          if (usesQueryPackageCompany) {
            params.page = page;
            params.limit = perPage;

            if (sortBy !== "default") {
              params.sort_by = sortBy;
              params.sort_dir = sortDir;
            }

            if (priorityStatus !== "none") {
              params.priority_status =
                priorityStatus as OrdersPriorityStatus;
            }
          }

          response =
            await ordersService.getOrdersByStatus(
              activeStatus,
              params,
            );
        }

        if (
          requestId !==
          orderRequestIdRef.current
        ) {
          return;
        }

        const code = Number(
          response?.mensaje_return?.CODE,
        );

        const rawPackages =
          code === 1103
            ? []
            : normalizeArray(
                response?.return_result,
              );

        const mappedOrders: ClientOrder[] =
          rawPackages.map(
            (pkg: any) => {
              let statusType:
                | OrderStatus
                | undefined;

              if (
                activeStatus === "scheduled" &&
                !isServerSearch
              ) {
                statusType = "scheduled";
              }

              if (
                activeStatus === "canceled" &&
                !isServerSearch
              ) {
                statusType =
                  "canceled_locker";
              }

              return {
                // El número de orden ya no se usa como columna ni como fallback
                // visual. El historial trabaja con tracking / código de servicio.
                tracking: String(
                  safeValue(
                    pkg.tracking_number,
                    safeValue(
                      pkg.code_service,
                      "---",
                    ),
                  ),
                ),
                locker: String(
                  safeValue(
                    pkg.locker_name,
                  ),
                ),
                email: String(
                  safeValue(
                    pkg.email,
                    "",
                  ),
                ),
                expirationDate:
                  pkg.expiration_date ??
                  pkg.package_expiration_date ??
                  null,
                status:
                  pkg.name_status_package ??
                  pkg.status_name ??
                  pkg.nombre_status,
                statusCode:
                  pkg.status_package ??
                  pkg.id_status_package,
                idStatusCodePackage:
                  pkg.id_status_code_package,
                idStatusService:
                  pkg.id_status_service ??
                  pkg.id_status ??
                  pkg.service_status ??
                  pkg.id_service_status,
                codeStatusName:
                  pkg.nombre_status_code_package,
                hasDebt:
                  Boolean(pkg.has_debt),
                statusType,
              };
            },
          );

        const scopedOrders = isServerSearch
          ? mappedOrders.filter((order) => {
              const orderEmail =
                order.email
                  .trim()
                  .toLowerCase();
              const clientEmail =
                client.email
                  .trim()
                  .toLowerCase();

              return (
                Boolean(clientEmail) &&
                orderEmail === clientEmail
              );
            })
          : mappedOrders;

        setOrders(scopedOrders);

        if (usesServerPagination) {
          const pagination =
            readPaginationMeta(
              response,
              scopedOrders.length,
              perPage,
            );

          setTotal(
            pagination.total,
          );

          setServerTotalPages(
            pagination.totalPages,
          );

          if (
            page >
            pagination.totalPages
          ) {
            setPage(
              pagination.totalPages,
            );
          }
        } else {
          setTotal(
            scopedOrders.length,
          );

          setServerTotalPages(1);
        }
      } catch (error: any) {
        if (
          requestId !==
          orderRequestIdRef.current
        ) {
          return;
        }

        console.error(
          "Error loading client orders:",
          error,
        );

        setOrders([]);
        setTotal(0);
        setServerTotalPages(1);
      } finally {
        if (
          requestId ===
          orderRequestIdRef.current
        ) {
          setOrdersLoading(false);
        }
      }
    };

    void loadOrders();
  }, [
    activeStatus,
    client?.id,
    client?.email,
    date_end,
    date_start,
    debouncedSearch,
    isServerSearch,
    language,
    page,
    perPage,
    priorityStatus,
    searchBy,
    sortBy,
    sortDir,
    usesQueryPackageCompany,
    usesServerPagination,
  ]);

  /* =============================== */
  /* TAB CHANGE                      */
  /* =============================== */

  const handleStatusChange = (
    status: OrdersStatusTabValue,
  ) => {
    setActiveStatus(status);
    setPage(1);
  };

  /* =============================== */
  /* FILTER                          */
  /* =============================== */

  const filteredOrders =
    useMemo(() => {
      const normalizedSearch =
        searchQuery
          .trim()
          .toLowerCase();

      if (!normalizedSearch) {
        return orders;
      }

      return orders.filter(
        (order) =>
          order.tracking
            .toLowerCase()
            .includes(normalizedSearch) ||
          order.email
            .toLowerCase()
            .includes(normalizedSearch) ||
          order.locker
            .toLowerCase()
            .includes(normalizedSearch),
      );
    }, [
      orders,
      searchQuery,
    ]);

  /*
   * query-package-company ya viene paginado.
   * schedule y cancel-package se mantienen con paginación local
   * porque esos endpoints no garantizan total/total_pages.
   */
  const displayedOrders =
    usesServerPagination
      ? filteredOrders
      : filteredOrders.slice(
          (page - 1) * perPage,
          page * perPage,
        );

  const totalPages =
    usesServerPagination
      ? serverTotalPages
      : Math.max(
          1,
          Math.ceil(
            filteredOrders.length /
              perPage,
          ),
        );

  const paginationTotal =
    usesServerPagination
      ? total
      : filteredOrders.length;

  const firstResult =
    paginationTotal === 0
      ? 0
      : (page - 1) * perPage + 1;

  const lastResult =
    paginationTotal === 0
      ? 0
      : Math.min(
          page * perPage,
          paginationTotal,
        );

  /* =============================== */
  /* BADGE                           */
  /* =============================== */

  function getPackageBadge(
    order: ClientOrder,
  ) {
    if (order.hasDebt) {
      return "bg-red-700/10 text-red-800";
    }

    const status =
      getOrderStatus(order);

    switch (status) {
      case "completed":
        return "bg-green-500/10 text-green-600";

      case "in_locker":
        return "bg-blue-500/10 text-blue-600";

      case "in_transit":
        return "bg-cyan-500/10 text-cyan-700";

      case "pending_validate":
        return "bg-amber-500/10 text-amber-700";

      case "pending_payment":
        return "bg-orange-500/10 text-orange-700";

      case "in_progress":
        return "bg-slate-500/10 text-slate-700";

      case "expired":
        return "bg-red-500/10 text-red-600";

      case "returned":
        return "bg-purple-500/10 text-purple-600";

      case "canceled_locker":
      case "canceled_picked":
        return "bg-gray-500/10 text-gray-600";

      case "scheduled":
      default:
        return "bg-gray-500/10 text-gray-600";
    }
  }

  /* =============================== */
  /* RENDER                          */
  /* =============================== */

  if (loading) {
    return (
      <DashboardLayout>
        <LoadingSpinner
          fullPage
          text={t("common.loading")}
        />
      </DashboardLayout>
    );
  }

  if (!client) {
    return (
      <DashboardLayout>
        <div className="p-10 text-center text-muted-foreground">
          {t(
            "clientDetail.clientNotFound",
          )}
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* HEADER */}
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() =>
              navigate("/clients")
            }
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>

          <div>
            <nav className="flex items-center gap-2 text-xs text-muted-foreground">
              <Link to="/clients">
                {t(
                  "clientDetail.clients",
                )}
              </Link>

              <span>/</span>

              <span className="font-semibold text-foreground">
                {client.userName}
              </span>
            </nav>

            <h1 className="text-xl font-bold">
              {t(
                "clientDetail.clientDetail",
              )}
            </h1>
          </div>
        </div>

        {/* INFO CARD */}
        <div className="rounded-2xl border border-border bg-card p-5">
          <h3 className="mb-5 text-sm font-semibold">
            {t(
              "clientDetail.residentInfo",
            )}
          </h3>

          <div className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
            <InfoItem
              label={t(
                "clientDetail.name",
              )}
              value={
                client.userName
              }
            />

            <InfoItem
              label={t(
                "clientDetail.phone",
              )}
              value={
                client.telephone
              }
            />

            <InfoItem
              label={t(
                "clientDetail.unit",
              )}
              value={
                client.unitNumber
              }
            />

            <InfoItem
              label={t(
                "clientDetail.email",
              )}
              value={
                client.email
              }
            />

            <InfoItem
              label={t(
                "clientDetail.registrationDate",
              )}
              value={
                client.registrationDate
                  ? new Date(
                      client.registrationDate,
                    ).toLocaleString()
                  : "---"
              }
            />

            <div>
              <p className="text-[11px] font-semibold text-muted-foreground">
                {t(
                  "clientDetail.initialAccess",
                )}
              </p>

              <Badge
                className={`mt-1 ${
                  client.clientStatus
                    ? "border-success/20 bg-success/10 text-success"
                    : "border-destructive/20 bg-destructive/10 text-destructive"
                }`}
              >
                {client.clientStatus
                  ? t(
                      "clients.active",
                    )
                  : t(
                      "clients.inactive",
                    )}
              </Badge>
            </div>
          </div>
        </div>

{/* KPIs */}
<KpiGrid columns={2}>
  <KpiCard
    title={t("clientDetail.totalPackages")}
    value={client.monthlyUsage ?? 0}
    tooltip={t("clientDetail.tooltips.totalPackages")}
  />

  <KpiCard
    title={t("clientDetail.serviceStatus")}
    value={
      client.serviceStatus
        ? t("clients.active")
        : t("clients.inactive")
    }
    tooltip={t("clientDetail.tooltips.serviceStatus")}
    variant={client.serviceStatus ? "success" : "destructive"}
  />
</KpiGrid>

        {/* ORDER HISTORY */}
        <div>
          <PackageQueryPanel
            title={t("clientDetail.orderHistory")}
            status={activeStatus}
            onStatusChange={handleStatusChange}
            search={searchQuery}
            onSearchChange={(value) => {
              setSearchQuery(value);
              setPage(1);
            }}
            searchBy={searchBy}
            onSearchByChange={(value) => {
              setSearchBy(value);
              setPage(1);
            }}
            showQueryControls={!isServerSearch && usesQueryPackageCompany}
            sortBy={sortBy}
            sortDir={sortDir}
            priorityStatus={priorityStatus}
            onSortByChange={(value) => {
              setSortBy(value);
              setPage(1);
            }}
            onSortDirChange={(value) => {
              setSortDir(value);
              setPage(1);
            }}
            onPriorityStatusChange={(value) => {
              setPriorityStatus(value);
              setPage(1);
            }}
            onResetAll={() => {
              setSearchQuery("");
              setSearchBy("tracking");
              setActiveStatus("all");
              setSortBy("default");
              setSortDir("desc");
              setPriorityStatus("none");
              setPage(1);
            }}
          />

          <div className="overflow-hidden rounded-xl border border-border bg-card shadow-sm">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>
                    {t("clientDetail.tracking")}
                  </TableHead>

                  <TableHead>
                    {t("clientDetail.locker")}
                  </TableHead>

                  <TableHead>
                    {t("clientDetail.status")}
                  </TableHead>

                  {isHouseAccount && (
                    <TableHead className="text-right">
                      {t("packageExtension.actions")}
                    </TableHead>
                  )}
                </TableRow>
              </TableHeader>

              <TableBody>
                {ordersLoading ? (
                  <TableRow>
                    <TableCell
                      colSpan={isHouseAccount ? 4 : 3}
                      className="py-8"
                    >
                      <div className="flex justify-center">
                        <LoadingSpinner text={t("common.loading")} />
                      </div>
                    </TableCell>
                  </TableRow>
                ) : displayedOrders.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={isHouseAccount ? 4 : 3}
                      className="py-6 text-center text-muted-foreground"
                    >
                      {t("clientDetail.noOrders")}
                    </TableCell>
                  </TableRow>
                ) : (
                  displayedOrders.map((order, index) => (
                    <TableRow
                      key={`${order.tracking}-${order.locker}-${index}`}
                    >
                      <TableCell>{order.tracking}</TableCell>

                      <TableCell>{order.locker}</TableCell>

                      <TableCell>
                        <Badge className={getPackageBadge(order)}>
                          {getOrderStatusLabel(order)}
                        </Badge>
                      </TableCell>

                      {isHouseAccount && (
                        <TableCell className="text-right">
                          {getOrderStatus(order) === "expired" ? (
                            <div className="flex justify-end">
                              <ExtendPackageAction
                                tracking={order.tracking}
                                expirationDate={order.expirationDate}
                              />
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground">
                              No disponible
                            </span>
                          )}
                        </TableCell>
                      )}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>

            {/* PAGINATION */}
            <div className="flex flex-col gap-3 border-t p-4 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-5">
                <span>
                  {firstResult}-{lastResult} {t("common.of")} {paginationTotal}
                </span>

                <Select
                  value={resultsPerPage}
                  onValueChange={(value) => {
                    setResultsPerPage(value);
                    setPage(1);
                  }}
                >
                  <SelectTrigger className="w-24">
                    <SelectValue />
                  </SelectTrigger>

                  <SelectContent>
                    <SelectItem value="5">5</SelectItem>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="20">20</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={ordersLoading || page === 1}
                  onClick={() =>
                    setPage((current) => Math.max(1, current - 1))
                  }
                >
                  {t("common.previous")}
                </Button>

                <Button
                  size="sm"
                  variant="outline"
                  disabled={ordersLoading || page >= totalPages}
                  onClick={() =>
                    setPage((current) => Math.min(totalPages, current + 1))
                  }
                >
                  {t("common.next")}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
