import { useCallback, useEffect, useMemo, useState } from "react";
import { AlertCircle, RefreshCw } from "lucide-react";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { NotificationsBell } from "@/components/layout/NotificationsBell";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DonutChart } from "@/components/dashboard/DonutChart";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { WeeklyTrendChart } from "@/components/dashboard/WeeklyTrendChart";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useLanguage } from "@/contexts/LanguageContext";
import { dashboardService } from "@/services/dashboard.service";
import type { DashboardOverview } from "@/types/dashboard.types";

const EMPTY_OVERVIEW: DashboardOverview = {
  cards: {
    total_packages: { value: 0, variation: 0 },
    active_lockers: { value: 0, variation: 0 },
    pending_pickups: { value: 0, variation: 0 },
    delivery_rate: { value: 0, variation: 0 },
  },
  package_status_distribution: [],
  weekly_trend: [],
};

const statusColors: Record<string, string> = {
  in_transit: "hsl(195, 65%, 43%)",
  delivered: "hsl(var(--success))",
  pending: "hsl(var(--warning))",
};

export default function Home() {
  const { t } = useLanguage();

  const [overview, setOverview] = useState<DashboardOverview>(EMPTY_OVERVIEW);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadOverview = useCallback(async (isRefresh = false) => {
    if (isRefresh) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }

    setError(null);

    try {
      const response = await dashboardService.getOverview();
      setOverview(response.return_result ?? EMPTY_OVERVIEW);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : t("home.dashboard.loadError"),
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [t]);

  useEffect(() => {
    void loadOverview();
  }, [loadOverview]);

  const distributionData = useMemo(() => {
    const labelByStatus: Record<string, string> = {
      in_transit: t("home.dashboard.status.inTransit"),
      delivered: t("home.dashboard.status.delivered"),
      pending: t("home.dashboard.status.pending"),
    };

    return overview.package_status_distribution.map((item) => ({
      name: labelByStatus[item.status_group] ?? item.status_group,
      value: item.total,
      color: statusColors[item.status_group] ?? "hsl(var(--muted-foreground))",
    }));
  }, [overview.package_status_distribution, t]);

  const totalDistribution = useMemo(
    () => distributionData.reduce((total, item) => total + item.value, 0),
    [distributionData],
  );

  return (
    <DashboardLayout>
      <div className="space-y-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <DashboardHeader
            title={t("home.dashboard.title")}
            subtitle={t("home.dashboard.subtitle")}
          />

          <div className="flex items-center justify-end gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => void loadOverview(true)}
              disabled={loading || refreshing}
              className="gap-2"
            >
              <RefreshCw
                className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`}
              />
              {t("home.dashboard.refresh")}
            </Button>
            <NotificationsBell />
          </div>
        </div>

        {error && !loading && (
          <div className="flex flex-col gap-3 rounded-xl border border-destructive/30 bg-destructive/5 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3">
              <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
              <div>
                <p className="text-sm font-semibold text-foreground">
                  {t("home.dashboard.loadError")}
                </p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {error}
                </p>
              </div>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => void loadOverview()}
            >
              {t("home.dashboard.retry")}
            </Button>
          </div>
        )}

        {loading ? (
          <DashboardSkeleton />
        ) : (
          <>
            <section className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <MetricCard
                title={t("home.dashboard.totalPackages")}
                value={overview.cards.total_packages.value}
                change={overview.cards.total_packages.variation}
                color="primary"
                delay={0}
              />

              <MetricCard
                title={t("home.dashboard.activeLockers")}
                value={overview.cards.active_lockers.value}
                change={overview.cards.active_lockers.variation}
                color="success"
                delay={75}
              />

              <MetricCard
                title={t("home.dashboard.pendingPickups")}
                value={overview.cards.pending_pickups.value}
                change={overview.cards.pending_pickups.variation}
                color="warning"
                delay={150}
              />

              <MetricCard
                title={t("home.dashboard.deliveryRate")}
                value={`${overview.cards.delivery_rate.value}%`}
                change={overview.cards.delivery_rate.variation}
                color="info"
                delay={225}
              />
            </section>

            <section className="grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(320px,0.72fr)]">
              <div className="card-elevated p-4 sm:p-5">
                <div className="mb-2">
                  <h2 className="font-poppins text-base font-bold text-foreground">
                    {t("home.dashboard.weeklyTrend")}
                  </h2>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {t("home.dashboard.weeklyTrendSubtitle")}
                  </p>
                </div>

                {overview.weekly_trend.length > 0 ? (
                  <WeeklyTrendChart data={overview.weekly_trend} />
                ) : (
                  <EmptyChartState />
                )}
              </div>

              <div className="card-elevated p-4 sm:p-5">
                <div className="mb-2">
                  <h2 className="font-poppins text-base font-bold text-foreground">
                    {t("home.dashboard.packageDistribution")}
                  </h2>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {t("home.dashboard.packageDistributionSubtitle")}
                  </p>
                </div>

                {distributionData.length > 0 && totalDistribution > 0 ? (
                  <>
                    <DonutChart
                      data={distributionData}
                      centerLabel={t("home.dashboard.total")}
                      centerValue={totalDistribution}
                    />

                    <div className="grid gap-2 pt-1">
                      {distributionData.map((item) => (
                        <div
                          key={item.name}
                          className="flex items-center justify-between rounded-lg bg-muted/40 px-3 py-2"
                        >
                          <div className="flex items-center gap-2">
                            <span
                              className="h-2.5 w-2.5 rounded-full"
                              style={{ backgroundColor: item.color }}
                            />
                            <span className="text-xs font-medium text-foreground">
                              {item.name}
                            </span>
                          </div>
                          <span className="text-xs font-semibold tabular-nums text-foreground">
                            {item.value.toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <EmptyChartState />
                )}
              </div>
            </section>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, index) => (
          <Skeleton key={index} className="h-[90px] rounded-2xl" />
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(320px,0.72fr)]">
        <Skeleton className="h-[380px] rounded-xl" />
        <Skeleton className="h-[380px] rounded-xl" />
      </div>
    </div>
  );
}

function EmptyChartState() {
  const { t } = useLanguage();

  return (
    <div className="flex h-[290px] items-center justify-center rounded-xl border border-dashed border-border bg-muted/20">
      <p className="text-sm text-muted-foreground">
        {t("home.dashboard.noData")}
      </p>
    </div>
  );
}
