// src/pages/Services.tsx

import { useEffect, useMemo, useState, type ReactNode } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { BarChart3, AlertCircle, RefreshCw } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { ExportButton } from "@/components/ExportButton";
import { Column } from "@/components/ui/types";
import { GenericTable } from "@/components/ui/GenericTable";
import { DateRange } from "react-day-picker";
import { isWithinInterval, parseISO } from "date-fns";

// Imágenes originales del proyecto
import receiveWhite from "@/assets/services/receive_white.jpg";
import exchangeWhite from "@/assets/services/exchange_white.jpg";
import shipWhite from "@/assets/services/ship_white.jpg";
import returnWhite from "@/assets/services/return_white.jpg";
import receiveDark from "@/assets/services/receive_dark.jpg";
import exchangeDark from "@/assets/services/exchange_dark.jpg";
import shipDark from "@/assets/services/ship_dark.jpg";
import returnDark from "@/assets/services/return_dark.jpg";

import { ServiceTransaction } from "@/types/ServiceTransaction.types";
import { useTransactions } from "@/hooks/useTransactions";
import {
  useOfferings,
  OPERATION_ICON_TO_FILTER,
  Offering,
} from "@/hooks/useOfferings";

// ─────────────────────────────────────────────────────────────
// Traducciones locales de respaldo
// Sirven aunque el diccionario global no tenga las keys cargadas.
// ─────────────────────────────────────────────────────────────

type ServiceTranslationKey =
  | "services.title"
  | "services.subtitle"
  | "services.all"
  | "services.transactionId"
  | "services.service"
  | "services.client"
  | "services.package"
  | "services.status"
  | "services.dateTime"
  | "services.amount"
  | "services.view"
  | "services.withDebt"
  | "services.loadError"
  | "services.retry"
  | "services.statusLabels.scheduled"
  | "services.statusLabels.toBeApproved"
  | "services.statusLabels.pendingPayment"
  | "services.statusLabels.pendingSurchargePayment"
  | "services.statusLabels.assignedToCarrier"
  | "services.statusLabels.inTransit"
  | "services.statusLabels.inLocker"
  | "services.statusLabels.inLockerOrigin"
  | "services.statusLabels.inDestinationLocker"
  | "services.statusLabels.expiredInLocker"
  | "services.statusLabels.completed"
  | "services.statusLabels.expiredCollected"
  | "services.statusLabels.unknown"
  | "services.export.transactionId"
  | "services.export.service"
  | "services.export.resident"
  | "services.export.package"
  | "services.export.status"
  | "services.export.date"
  | "services.export.amount"
  | "services.export.property";

const SERVICE_TRANSLATIONS: Record<
  "es" | "en",
  Record<ServiceTranslationKey, string>
> = {
  es: {
    "services.title": "Servicios",
    "services.subtitle": "Consulta y administra las transacciones de servicios",
    "services.all": "Todos",
    "services.transactionId": "ID transacción",
    "services.service": "Servicio",
    "services.client": "Residente",
    "services.package": "Paquete",
    "services.status": "Estado",
    "services.dateTime": "Fecha y hora",
    "services.amount": "Monto",
    "services.view": "Ver",
    "services.withDebt": "Con deuda",
    "services.loadError": "Error al cargar transacciones",
    "services.retry": "Reintentar",

    "services.statusLabels.scheduled": "Programado",
    "services.statusLabels.toBeApproved": "Pendiente por validar",
    "services.statusLabels.pendingPayment": "Pendiente por pago",
    "services.statusLabels.pendingSurchargePayment": "Pendiente de cobro por recargo",
    "services.statusLabels.assignedToCarrier": "Asignado a transportista",
    "services.statusLabels.inTransit": "En tránsito",
    "services.statusLabels.inLocker": "En locker",
    "services.statusLabels.inLockerOrigin": "En locker origen",
    "services.statusLabels.inDestinationLocker": "En locker destino",
    "services.statusLabels.expiredInLocker": "Vencido en locker",
    "services.statusLabels.completed": "Completado",
    "services.statusLabels.expiredCollected": "Vencido recolectado",
    "services.statusLabels.unknown": "Sin estatus",

    "services.export.transactionId": "ID transacción",
    "services.export.service": "Servicio",
    "services.export.resident": "Residente",
    "services.export.package": "Paquete",
    "services.export.status": "Estado",
    "services.export.date": "Fecha",
    "services.export.amount": "Monto",
    "services.export.property": "Propiedad",
  },
  en: {
    "services.title": "Services",
    "services.subtitle": "View and manage service transactions",
    "services.all": "All",
    "services.transactionId": "Transaction ID",
    "services.service": "Service",
    "services.client": "Resident",
    "services.package": "Package",
    "services.status": "Status",
    "services.dateTime": "Date and time",
    "services.amount": "Amount",
    "services.view": "View",
    "services.withDebt": "With debt",
    "services.loadError": "Error loading transactions",
    "services.retry": "Retry",

    "services.statusLabels.scheduled": "Scheduled",
    "services.statusLabels.toBeApproved": "Pending validation",
    "services.statusLabels.pendingPayment": "Pending payment",
    "services.statusLabels.pendingSurchargePayment": "Pending surcharge payment",
    "services.statusLabels.assignedToCarrier": "Assigned to carrier",
    "services.statusLabels.inTransit": "In transit",
    "services.statusLabels.inLocker": "In locker",
    "services.statusLabels.inLockerOrigin": "In origin locker",
    "services.statusLabels.inDestinationLocker": "In destination locker",
    "services.statusLabels.expiredInLocker": "Expired in locker",
    "services.statusLabels.completed": "Completed",
    "services.statusLabels.expiredCollected": "Expired collected",
    "services.statusLabels.unknown": "Unknown status",

    "services.export.transactionId": "Transaction ID",
    "services.export.service": "Service",
    "services.export.resident": "Resident",
    "services.export.package": "Package",
    "services.export.status": "Status",
    "services.export.date": "Date",
    "services.export.amount": "Amount",
    "services.export.property": "Property",
  },
};

function getUiLanguage(): "es" | "en" {
  if (typeof window === "undefined") return "es";

  const rawLanguage = String(
    window.localStorage.getItem("lang") ??
      window.localStorage.getItem("language") ??
      "es"
  ).toLowerCase();

  return rawLanguage.startsWith("en") ? "en" : "es";
}

function tr(
  t: (key: string) => string,
  key: ServiceTranslationKey,
  language: "es" | "en"
): string {
  const translated = t(key);

  if (translated) {
    const normalizedTranslated = translated.trim().toLowerCase();
    const normalizedKey = key.toLowerCase();

    const isMissingKey =
      normalizedTranslated === normalizedKey ||
      normalizedTranslated.startsWith("services.");

    if (!isMissingKey) {
      return translated;
    }
  }

  return SERVICE_TRANSLATIONS[language][key] ?? SERVICE_TRANSLATIONS.es[key] ?? key;
}

// ─────────────────────────────────────────────────────────────
// ICON MAP
// ─────────────────────────────────────────────────────────────

interface ServiceImages {
  light: string;
  dark: string;
}

const OFFERING_ICON_IMAGES: Record<string, ServiceImages> = {
  send: { light: receiveWhite, dark: receiveDark },
  swap: { light: returnWhite, dark: returnDark },
  undo: { light: exchangeWhite, dark: exchangeDark },
  waa: { light: shipWhite, dark: shipDark },
};

const FALLBACK_IMAGES: ServiceImages = {
  light: receiveWhite,
  dark: receiveDark,
};

function getOfferingImages(iconKey: string): ServiceImages {
  return OFFERING_ICON_IMAGES[iconKey] ?? FALLBACK_IMAGES;
}

// ─────────────────────────────────────────────────────────────
// Operational status config
// p = id_status_package
// c = id_status_code_package
// ─────────────────────────────────────────────────────────────

type OperationalStatusKey =
  | "scheduled"
  | "to_be_approved"
  | "pending_payment"
  | "pending_surcharge_payment"
  | "assigned_to_carrier"
  | "in_transit"
  | "in_locker"
  | "completed"
  | "unknown";

type OperationalStatus = {
  key: OperationalStatusKey;
  labelKey: ServiceTranslationKey;
};

type StatusCfg = {
  className: string;
  dot: string;
};

type ServiceRow = ServiceTransaction & {
  operational_status: OperationalStatusKey;
  operational_status_label: string;
};

const STATUS_STYLE: Record<OperationalStatusKey, StatusCfg> = {
  scheduled: {
    className: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    dot: "bg-blue-500",
  },
  to_be_approved: {
    className: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
    dot: "bg-yellow-500",
  },
  pending_payment: {
    className: "bg-orange-500/10 text-orange-500 border-orange-500/20",
    dot: "bg-orange-500",
  },
  pending_surcharge_payment: {
    className: "bg-amber-500/10 text-amber-700 border-amber-500/20 dark:text-amber-400",
    dot: "bg-amber-500",
  },
  assigned_to_carrier: {
    className: "bg-cyan-500/10 text-cyan-700 border-cyan-500/20 dark:text-cyan-400",
    dot: "bg-cyan-500",
  },
  in_transit: {
    className: "bg-info/10 text-info border-info/20",
    dot: "bg-info",
  },
  in_locker: {
    className: "bg-purple-500/10 text-purple-500 border-purple-500/20",
    dot: "bg-purple-500",
  },
  completed: {
    className: "bg-success/10 text-success border-success/20",
    dot: "bg-success",
  },
  unknown: {
    className: "bg-muted/50 text-muted-foreground border-border",
    dot: "bg-muted-foreground",
  },
};

/*
 * Contrato operativo consolidado
 * --------------------------------
 * tbl_service:
 *   12  -> PENDING_PAYMENT
 *   35  -> SCHEDULED
 *   37  -> IN_TRANSIT cuando p NO está en [14, 47, 57, 16, 33]
 *   40  -> COMPLETED (fallback de servicio)
 *   42  -> TO_BE_APPROVED
 *   46  -> PENDING_SURCHARGE_PAYMENT
 *   183 -> ASSIGNED_TO_CARRIER
 *
 * tbl_package (tiene prioridad sobre el 37):
 *   p=14, c=17 -> IN_LOCKER
 *   p=47, c=17 -> IN_LOCKER_ORIGIN
 *   p=57, c=17 -> IN_DESTINATION_LOCKER
 *   p=14, c=32 -> EXPIRED_IN_LOCKER
 *   p=16, c=18 -> COMPLETED
 *   p=33, c=32 -> EXPIRED_COLLECTED
 */

const SERVICE_STATUS_IDS = {
  PENDING_PAYMENT: 12,
  SCHEDULED: 35,
  IN_TRANSIT: 37,
  COMPLETED: 40,
  TO_BE_APPROVED: 42,
  PENDING_SURCHARGE_PAYMENT: 46,
  ASSIGNED_TO_CARRIER: 183,
} as const;

const IN_LOCKER_PACKAGE_RULES = [
  {
    p: 14,
    c: 17,
    labelKey: "services.statusLabels.inLocker",
  },
  {
    p: 47,
    c: 17,
    labelKey: "services.statusLabels.inLockerOrigin",
  },
  {
    p: 57,
    c: 17,
    labelKey: "services.statusLabels.inDestinationLocker",
  },
  {
    p: 14,
    c: 32,
    labelKey: "services.statusLabels.expiredInLocker",
  },
] as const;

const COMPLETED_PACKAGE_RULES = [
  {
    p: 16,
    c: 18,
    labelKey: "services.statusLabels.completed",
  },
  {
    p: 33,
    c: 32,
    labelKey: "services.statusLabels.expiredCollected",
  },
] as const;

function readField(row: unknown, key: string): unknown {
  return (row as Record<string, unknown>)?.[key];
}

function toNumber(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;

  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function getServiceStatusId(row: ServiceTransaction): number | null {
  return toNumber(readField(row, "id_status_service"));
}

function getPackageStatusId(row: ServiceTransaction): number | null {
  return toNumber(readField(row, "id_status_package"));
}

function getPackageStatusCodeId(row: ServiceTransaction): number | null {
  return toNumber(readField(row, "id_status_code_package"));
}

function matchesPackageRule(
  packageStatusId: number | null,
  packageStatusCodeId: number | null,
  rule: { p: number; c: number }
): boolean {
  if (packageStatusId !== rule.p) return false;

  /*
   * El contrato del backend define las reglas de tbl_package
   * usando la combinación:
   *
   *   p = id_status_package
   *   c = id_status_code_package
   *
   * Si c viene informado, exigimos coincidencia exacta.
   *
   * Si c no viene en este endpoint, permitimos resolver por p
   * únicamente para no perder los estados que el backend ya
   * clasificó por package. Para p = 14, el fallback visual será
   * "En locker"; cuando c venga informado distinguiremos:
   *   14 + 17 -> En locker
   *   14 + 32 -> Vencido en locker
   */
  if (packageStatusCodeId === null) return true;

  return packageStatusCodeId === rule.c;
}

const PACKAGE_STATUS_IDS_WITH_OWN_RULES = new Set<number>([
  ...IN_LOCKER_PACKAGE_RULES.map((rule) => rule.p),
  ...COMPLETED_PACKAGE_RULES.map((rule) => rule.p),
]);

function packageHasOwnOperationalRule(
  packageStatusId: number | null
): boolean {
  if (packageStatusId === null) return false;

  return PACKAGE_STATUS_IDS_WITH_OWN_RULES.has(packageStatusId);
}

function shouldResolveAsInTransit(
  serviceStatusId: number | null,
  packageStatusId: number | null
): boolean {
  /*
   * Regla acordada con backend:
   *
   * service.id_status = 37
   * y p (id_status_package) es distinto de todos los package
   * statuses con regla propia
   * -> IN_TRANSIT
   *
   * Package statuses con regla propia:
   *   14, 47, 57, 16, 33
   *
   * Si no hay package todavía (null), tampoco existe una regla
   * de tbl_package que lo excluya, por lo que 37 se interpreta
   * como En tránsito.
   */
  return (
    serviceStatusId === SERVICE_STATUS_IDS.IN_TRANSIT &&
    !packageHasOwnOperationalRule(packageStatusId)
  );
}

function resolveOperationalStatus(row: ServiceTransaction): OperationalStatus {
  const serviceStatusId = getServiceStatusId(row);
  const packageStatusId = getPackageStatusId(row);
  const packageStatusCodeId = getPackageStatusCodeId(row);

  // 46 = Pendiente de cobro por recargo.
  // Este estado bloquea el flujo hasta que se cubra el cargo adicional
  // (por ejemplo, cuando el paquete excede el peso permitido).
  if (
    serviceStatusId === SERVICE_STATUS_IDS.PENDING_SURCHARGE_PAYMENT
  ) {
    return {
      key: "pending_surcharge_payment",
      labelKey: "services.statusLabels.pendingSurchargePayment",
    };
  }

  // 183 = Asignado a transportista/carrier.
  // En el backend puede venir acompañado por id_status_package = 179.
  if (serviceStatusId === SERVICE_STATUS_IDS.ASSIGNED_TO_CARRIER) {
    return {
      key: "assigned_to_carrier",
      labelKey: "services.statusLabels.assignedToCarrier",
    };
  }

  const completedRule = COMPLETED_PACKAGE_RULES.find((rule) =>
    matchesPackageRule(packageStatusId, packageStatusCodeId, rule)
  );

  if (completedRule) {
    return {
      key: "completed",
      labelKey: completedRule.labelKey,
    };
  }

  const inLockerRule = IN_LOCKER_PACKAGE_RULES.find((rule) =>
    matchesPackageRule(packageStatusId, packageStatusCodeId, rule)
  );

  if (inLockerRule) {
    return {
      key: "in_locker",
      labelKey: inLockerRule.labelKey,
    };
  }

  if (serviceStatusId === SERVICE_STATUS_IDS.COMPLETED) {
    return {
      key: "completed",
      labelKey: "services.statusLabels.completed",
    };
  }

  if (serviceStatusId === SERVICE_STATUS_IDS.SCHEDULED) {
    return {
      key: "scheduled",
      labelKey: "services.statusLabels.scheduled",
    };
  }

  if (serviceStatusId === SERVICE_STATUS_IDS.TO_BE_APPROVED) {
    return {
      key: "to_be_approved",
      labelKey: "services.statusLabels.toBeApproved",
    };
  }

  if (serviceStatusId === SERVICE_STATUS_IDS.PENDING_PAYMENT) {
    return {
      key: "pending_payment",
      labelKey: "services.statusLabels.pendingPayment",
    };
  }

  /*
   * IMPORTANTE:
   * 37 NO se debe ignorar por tener un id_status_package.
   *
   * Si service.id_status = 37 y el package status NO pertenece
   * a los estados con regla propia (14, 47, 57, 16, 33),
   * el estado operativo es EN TRÁNSITO.
   */
  if (shouldResolveAsInTransit(serviceStatusId, packageStatusId)) {
    return {
      key: "in_transit",
      labelKey: "services.statusLabels.inTransit",
    };
  }

  /*
   * Caso defensivo:
   * si service = 37 pero p pertenece a una familia especial y no
   * pudo resolverse arriba (por ejemplo por un c nuevo/no esperado),
   * NO lo convertimos silenciosamente a En tránsito.
   * Lo dejamos como desconocido para detectar un contrato nuevo.
   */
  if (serviceStatusId === SERVICE_STATUS_IDS.IN_TRANSIT) {
    return {
      key: "unknown",
      labelKey: "services.statusLabels.unknown",
    };
  }

  return {
    key: "unknown",
    labelKey: "services.statusLabels.unknown",
  };
}
// ─────────────────────────────────────────────────────────────
// Skeleton row
// ─────────────────────────────────────────────────────────────

function SkeletonRow() {
  return (
    <tr className="border-b border-border animate-pulse">
      {[...Array(8)].map((_, i) => (
        <td key={i} className="px-4 py-3">
          <div
            className="h-3 bg-muted rounded-full"
            style={{ width: `${50 + (i % 4) * 15}%` }}
          />
        </td>
      ))}
    </tr>
  );
}

// ─────────────────────────────────────────────────────────────
// Helper — filterId para la tabla según el offering
// ─────────────────────────────────────────────────────────────

function getFilterIdForOffering(
  idOffering: number,
  offerings: Offering[]
): string {
  const offering = offerings.find((o) => o.id_offering === idOffering);

  if (!offering || offering.operations.length === 0) return "";

  const firstOp = offering.operations[0];

  return OPERATION_ICON_TO_FILTER[firstOp.operation_icon] ?? firstOp.operation_icon;
}

// ─────────────────────────────────────────────────────────────
// COMPONENT
// ─────────────────────────────────────────────────────────────

export default function Services() {
  const navigate = useNavigate();
  const { t } = useLanguage();

  const uiLanguage = getUiLanguage();

  const [selectedService, setSelectedService] = useState<string>("all");
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [hasLoadedOnce, setHasLoadedOnce] = useState(false);

  const { offerings } = useOfferings();

  const {
    data: transactions,
    loading,
    error,
    refetch,
  } = useTransactions({ language: uiLanguage });

  const serviceRows = useMemo<ServiceRow[]>(() => {
    return (transactions ?? []).map((txn) => {
      const operationalStatus = resolveOperationalStatus(txn);

      return {
        ...txn,
        operational_status: operationalStatus.key,
        operational_status_label: tr(t, operationalStatus.labelKey, uiLanguage),
      };
    });
  }, [transactions, t, uiLanguage]);

  useEffect(() => {
    if (!loading && (transactions !== null || error)) {
      setHasLoadedOnce(true);
    }
  }, [loading, transactions, error]);

  useEffect(() => {
    let isRefreshing = false;

    const intervalId = window.setInterval(async () => {
      if (isRefreshing) return;

      isRefreshing = true;

      try {
        await refetch();
      } catch (refreshError) {
        console.error("Error refreshing services transactions:", refreshError);
      } finally {
        isRefreshing = false;
      }
    }, 30_000);

    return () => {
      window.clearInterval(intervalId);
    };
  }, [refetch]);

  const filteredTransactions = serviceRows
    .filter((txn) => {
      if (selectedService === "all") return true;

      return getFilterIdForOffering(txn.id_offering, offerings) === selectedService;
    })
    .filter((txn) => {
      if (!dateRange?.from || !dateRange?.to || !txn.delivery_date) return true;

      try {
        return isWithinInterval(parseISO(txn.delivery_date), {
          start: dateRange.from,
          end: dateRange.to,
        });
      } catch {
        return true;
      }
    });

  const columns: Column<ServiceRow>[] = [
    {
      key: "id",
      header: tr(t, "services.transactionId", uiLanguage),
      sortable: true,
      render: (row) => (
        <span className="font-inter font-semibold text-xs text-foreground">
          {row.id}
        </span>
      ),
    },
    {
      key: "service_name",
      header: tr(t, "services.service", uiLanguage),
      render: (row) => {
        const offering = offerings.find(
          (item) => item.id_offering === row.id_offering
        );

        return (
          <div className="flex items-center gap-2 font-inter text-xs">
            <span className="font-medium text-foreground">
              {row.service_name}
            </span>

            {offering && (
              <Badge
                variant="outline"
                className="text-[10px] font-inter font-medium"
              >
                {offering.title}
              </Badge>
            )}
          </div>
        );
      },
    },
    {
      key: "customer",
      header: tr(t, "services.client", uiLanguage),
      sortable: true,
      render: (row) => (
        <span className="font-inter text-xs text-foreground">
          {row.customer}
        </span>
      ),
    },
    {
      key: "tracking_number",
      header: tr(t, "services.package", uiLanguage),
      render: (row) => (
        <span className="font-inter font-medium text-xs text-primary">
          {row.tracking_number}
        </span>
      ),
    },
    {
      key: "operational_status_label",
      header: tr(t, "services.status", uiLanguage),
      render: (row) => {
        const cfg = STATUS_STYLE[row.operational_status] ?? STATUS_STYLE.unknown;

        return (
          <div className="flex flex-col gap-1">
            <Badge
              variant="outline"
              className={`${cfg.className} gap-1.5 font-inter text-[11px] w-fit`}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${cfg.dot}`} />
              {row.operational_status_label}
            </Badge>

            {row.has_debt && (
              <Badge
                variant="outline"
                className="text-[10px] font-inter bg-orange-500/10 text-orange-500 border-orange-500/20 w-fit"
              >
                {tr(t, "services.withDebt", uiLanguage)}
              </Badge>
            )}
          </div>
        );
      },
    },
    {
      key: "delivery_date",
      header: tr(t, "services.dateTime", uiLanguage),
      sortable: true,
      render: (row) =>
        row.delivery_date
          ? new Date(row.delivery_date).toLocaleString(
              uiLanguage === "en" ? "en-US" : "es-MX",
              {
                day: "2-digit",
                month: "short",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
              }
            )
          : "—",
    },
    {
      key: "amount",
      header: tr(t, "services.amount", uiLanguage),
      sortable: true,
      render: (row) => (
        <span className="font-inter font-semibold text-xs text-foreground">
          {row.amount}
        </span>
      ),
    },
    {
      key: "id_service" as keyof ServiceRow,
      header: "",
      render: (row) => (
        <Button
          variant="ghost"
          size="sm"
          className="text-xs font-inter font-semibold text-primary hover:text-primary/80"
          onClick={(event) => {
            event.stopPropagation();
            navigate(`/services/transactions/${row.id_service}`);
          }}
        >
          {tr(t, "services.view", uiLanguage)}
        </Button>
      ),
    },
  ];

  const exportHeaders = [
    { key: "id", label: tr(t, "services.export.transactionId", uiLanguage) },
    { key: "service_name", label: tr(t, "services.export.service", uiLanguage) },
    { key: "customer", label: tr(t, "services.export.resident", uiLanguage) },
    {
      key: "tracking_number",
      label: tr(t, "services.export.package", uiLanguage),
    },
    {
      key: "operational_status_label",
      label: tr(t, "services.export.status", uiLanguage),
    },
    { key: "delivery_date", label: tr(t, "services.export.date", uiLanguage) },
    { key: "amount", label: tr(t, "services.export.amount", uiLanguage) },
    {
      key: "property_name",
      label: tr(t, "services.export.property", uiLanguage),
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* HEADER */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold font-poppins text-foreground sm:text-2xl">
              {tr(t, "services.title", uiLanguage)}
            </h1>

            <p className="mt-0.5 text-sm font-inter text-muted-foreground">
              {tr(t, "services.subtitle", uiLanguage)}
            </p>
          </div>

          <ExportButton
            data={filteredTransactions as unknown as Record<string, unknown>[]}
            headers={exportHeaders}
            filename="servicios"
          />
        </div>

        {/* TARJETAS DE FILTRO */}
        <div
          className="animate-slide-up"
          style={{ animationDelay: "100ms", animationFillMode: "backwards" }}
        >
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
            <ServiceCard
              isActive={selectedService === "all"}
              onClick={() => setSelectedService("all")}
              label={tr(t, "services.all", uiLanguage)}
              icon={
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-xl ${
                    selectedService === "all"
                      ? "bg-primary-foreground/20"
                      : "bg-gradient-to-br from-primary to-primary/70 text-primary-foreground"
                  }`}
                >
                  <BarChart3 className="h-5 w-5" />
                </div>
              }
            />

            {offerings.map((offering) => {
              const filterId = offering.operations[0]
                ? OPERATION_ICON_TO_FILTER[
                    offering.operations[0].operation_icon
                  ] ?? offering.id_offering.toString()
                : offering.id_offering.toString();

              const images = getOfferingImages(offering.icon);

              return (
                <ServiceCard
                  key={offering.id_offering}
                  isActive={selectedService === filterId}
                  onClick={() => setSelectedService(filterId)}
                  label={offering.title}
                  icon={
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl overflow-hidden">
                      <img
                        src={images.light}
                        alt={offering.title}
                        className="h-10 w-10 object-contain dark:hidden"
                      />

                      <img
                        src={images.dark}
                        alt={offering.title}
                        className="h-10 w-10 object-contain hidden dark:block"
                      />
                    </div>
                  }
                />
              );
            })}
          </div>
        </div>

        {/* ERROR */}
        {error && (
          <div className="flex items-center gap-3 rounded-xl border border-destructive/20 bg-destructive/5 p-4">
            <AlertCircle className="h-5 w-5 text-destructive shrink-0" />

            <div className="flex-1">
              <p className="text-sm font-semibold font-inter text-destructive">
                {tr(t, "services.loadError", uiLanguage)}
              </p>

              <p className="text-xs font-inter text-muted-foreground mt-0.5">
                {error}
              </p>
            </div>

            <Button
              variant="outline"
              size="sm"
              className="gap-2 text-xs"
              onClick={refetch}
            >
              <RefreshCw className="h-3.5 w-3.5" />
              {tr(t, "services.retry", uiLanguage)}
            </Button>
          </div>
        )}

        {/* TABLA */}
        <div
          className="animate-slide-up border-border rounded-xl"
          style={{ animationDelay: "200ms", animationFillMode: "backwards" }}
        >
          {loading && !hasLoadedOnce ? (
            <div className="p-4">
              <table className="w-full">
                <tbody>
                  {[...Array(8)].map((_, i) => (
                    <SkeletonRow key={i} />
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <GenericTable
              data={filteredTransactions}
              columns={columns}
              searchFields={[
                "id",
                "customer",
                "tracking_number",
                "order_number",
                "email",
                "operational_status_label",
              ]}
              enableDateRange={true}
              onDateChange={setDateRange}
              onRowClick={(row) =>
                navigate(`/services/transactions/${row.id_service}`)
              }
              defaultSort={{ key: "delivery_date", direction: "desc" }}
            />
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}

// ─────────────────────────────────────────────────────────────
// SUB: ServiceCard
// ─────────────────────────────────────────────────────────────

interface ServiceCardProps {
  isActive: boolean;
  onClick: () => void;
  icon: ReactNode;
  label: string;
}

function ServiceCard({ isActive, onClick, icon, label }: ServiceCardProps) {
  return (
    <button
      onClick={onClick}
      className={`group relative flex flex-col items-center gap-2.5 rounded-2xl border p-4 transition-all duration-200 ${
        isActive
          ? "border-primary bg-primary text-primary-foreground shadow-md scale-[1.02]"
          : "border-border bg-card hover:border-primary/40 hover:shadow-md hover:-translate-y-0.5"
      }`}
    >
      {icon}

      <span className="text-xs font-semibold font-inter text-center leading-tight">
        {label}
      </span>
    </button>
  );
}