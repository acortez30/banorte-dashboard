import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, X, MapPin, Building2, ChevronLeft } from "lucide-react";
import { Column } from "@/components/ui/types";
import { GenericTable } from "@/components/ui/GenericTable";
import { companyService } from "@/services/company.service";
import { format, parseISO } from "date-fns";
import { es } from "date-fns/locale";
import GoogleMapLockers from "@/components/ui/GoogleMapLocker";

/* ─── types ─── */
interface Company {
  id_company:              number;
  company_name:            string;
  address:                 string;
  map_lat_center_point:    string;
  map_length_center_point: string;
}

interface Property {
  id_propierty:       number;
  id_company:         number;
  name_propierty:     string;
  address:            string;
  description_place:  string;
  code_propierty:     string;
  registration_date:  string;
  update_date:        string;
  latitud:            string;
  longitud:           string;
}

/* ─── helpers ─── */
const formatDate = (dateStr: string) => {
  if (!dateStr) return "—";
  try { return format(parseISO(dateStr), "dd MMM yyyy, HH:mm", { locale: es }); }
  catch { return dateStr; }
};

/* ─────────────────────────────────────────────── */

export default function CompanyDetailPage() {
  const { id_company } = useParams<{ id_company: string }>();
  const { t }          = useLanguage();
  const { user }       = useAuth();
  const navigate       = useNavigate();

  const idUserType = user?.id_user_type ?? user?.data_company?.id_user_type;
  const isSuperUser = idUserType === 1;

  const [company, setCompany]                   = useState<Company | null>(null);
  const [properties, setProperties]             = useState<Property[]>([]);
  const [loading, setLoading]                   = useState(true);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);

  /* ─── fetch company ─── */
  useEffect(() => {
    if (!id_company) return;

    const fetchAll = async () => {
      try {
        setLoading(true);

        const [companyRes, propertiesRes] = await Promise.all([
          companyService.getCompanyId(Number(id_company)),
          companyService.getProperties(Number(id_company)),
        ]);

        if (companyRes?.companies?.[0]) setCompany(companyRes.companies[0]);
        if (propertiesRes?.properties)  setProperties(propertiesRes.properties);
      } catch (error) {
        console.error("Error loading company detail:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchAll();
  }, [id_company]);

  /* ─── map lockers shape ─── */
  // Properties → blue markers (usando el formato de GoogleMapLockers)
  const mapMarkers = properties.map((p) => ({
    description:    p.name_propierty,
    locker_address: p.address,
    latitud:        parseFloat(p.latitud),
    longitud:       parseFloat(p.longitud),
  }));

  // Company → también como marker para mostrar el centro
  const allMarkers = company
    ? [
        {
          description:    company.company_name,
          locker_address: company.address,
          latitud:        parseFloat(company.map_lat_center_point),
          longitud:       parseFloat(company.map_length_center_point),
        },
        ...mapMarkers,
      ]
    : mapMarkers;

  /* ─── columns ─── */
  const columns: Column<Property>[] = [
    {
      key: "name_propierty",
      header: t("companyDetailPage.tableProperty.name_propierty") || "Propiedad",
      sortable: true,
      render: (row) => (
        <span
          className="text-primary font-medium cursor-pointer hover:underline"
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/company/${row.id_company}/property/${row.id_propierty}`);
          }}
        >
          {row.name_propierty}
        </span>
      ),
    },
    {
      key: "address",
      header: t("companyDetailPage.tableProperty.address") || "Dirección",
      sortable: true,
      render: (row) => (
        <span className="text-sm text-muted-foreground max-w-[360px] truncate block">
          {row.address}
        </span>
      ),
    },
    {
      key: "description_place",
      header: t("companyDetailPage.tableProperty.description_place") || "Descripción",
      sortable: true,
      render: (row) => (
        <span className="text-sm text-muted-foreground">{row.description_place || "—"}</span>
      ),
    },
    {
      key: "code_propierty",
      header: t("companyDetailPage.tableProperty.code_propierty") || "Código",
      sortable: true,
      render: (row) => (
        <span className="text-sm font-mono">{row.code_propierty || "—"}</span>
      ),
    },
    {
      key: "registration_date",
      header: t("companyDetailPage.tableProperty.registration_date") || "Fecha registro",
      sortable: true,
      render: (row) => (
        <span className="text-sm text-muted-foreground">{formatDate(row.registration_date)}</span>
      ),
    },
    {
      key: "update_date",
      header: t("companyDetailPage.tableProperty.update_date") || "Última actualización",
      sortable: true,
      render: (row) => (
        <span className="text-sm text-muted-foreground">{formatDate(row.update_date)}</span>
      ),
    },
    {
      key: "id_propierty",
      header: "",
      sortable: false,
      render: (row) => (
        <Button
          size="sm"
          variant="ghost"
          className="h-7 text-xs text-muted-foreground hover:text-foreground"
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/residents-property/${row.id_company}`, {
              state: { unit: null, page: "CompanyDetail", companyData: row },
            });
          }}
        >
          {t("companyDetailPage.tableProperty.residents") || "Residentes"}
        </Button>
      ),
    },
  ];

  /* ─── loading skeleton ─── */
  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 w-64 bg-muted rounded-lg" />
          <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] gap-4">
            <div className="h-[420px] bg-muted rounded-2xl" />
            <div className="h-[420px] bg-muted rounded-2xl" />
          </div>
          <div className="h-64 bg-muted rounded-2xl" />
        </div>
      </DashboardLayout>
    );
  }

  /* ─── render ─── */
  return (
    <DashboardLayout>
      <div className="space-y-6">

        {/* HEADER */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {isSuperUser && (
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => navigate("/company")}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
            )}
            <div>
              {isSuperUser && (
                <div className="flex items-center gap-1 text-xs text-muted-foreground mb-0.5">
                  <span
                    className="cursor-pointer hover:text-foreground transition-colors"
                    onClick={() => navigate("/company")}
                  >
                    {t("companyDetailPage.breadcrumb.superUser.company") || "Compañía"}
                  </span>
                  <span>/</span>
                  <span className="text-foreground">{company?.company_name}</span>
                </div>
              )}
              <h1 className="text-xl font-bold font-poppins sm:text-2xl">
                {company?.company_name || "—"}
              </h1>
              {company?.address && (
                <p className="mt-0.5 text-sm text-muted-foreground flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5 shrink-0" />
                  {company.address}
                </p>
              )}
            </div>
          </div>

          {isSuperUser && (
            <Button
              onClick={() => navigate(`/add-property/${id_company}`)}
              className="gap-2"
            >
              <Plus className="h-4 w-4" />
              {t("companyDetailPage.buttons.createProperty") || "Crear propiedad"}
            </Button>
          )}
        </div>

        {/* COUNTER + MAP */}
        <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] gap-4 items-stretch">

          {/* COUNTER */}
          <div className="metric-card flex flex-col gap-4">
            <p className="text-[13px] font-semibold font-poppins text-foreground">
              {t("companyDetailPage.cards.bigCard.title") || "Propiedades"}
            </p>

            <div className="flex-1 flex flex-col justify-center">
              <p className="text-[64px] font-bold font-poppins text-secondary leading-none">
                {properties.length}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                {t("companyDetailPage.cards.bigCard.title") || "Propiedades"}
              </p>
            </div>

            <div className="flex items-center gap-2 pt-3 border-t border-border">
              <Building2 className="h-4 w-4 text-secondary shrink-0" />
              <span className="text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">{properties.length}</span>{" "}
                {t("common.registered") || "registradas"}
              </span>
            </div>
          </div>

          {/* MAP */}
          <div className="metric-card relative overflow-hidden p-0">
            <div className="px-4 py-3 border-b border-border">
              <p className="text-[13px] font-semibold font-poppins text-foreground">
                {company?.address || t("companyDetailPage.mapTitle") || "Ubicación"}
              </p>
            </div>

            <div className="h-[380px]">
              <GoogleMapLockers lockers={allMarkers} />
            </div>

            {/* SELECTED PROPERTY POPUP */}
            {selectedProperty && (
              <div className="absolute bottom-4 right-4 z-10 w-72 bg-card border border-border rounded-xl shadow-elevated p-3 animate-fade-in">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <p className="text-xs font-semibold text-foreground">
                    {t("companyDetailPage.propertyDetails") || "Detalles de la propiedad"}
                  </p>
                  <button
                    onClick={() => setSelectedProperty(null)}
                    className="text-muted-foreground hover:text-foreground transition-colors shrink-0"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>

                <p className="text-sm font-semibold text-foreground">
                  {selectedProperty.name_propierty}
                </p>

                <div className="flex items-start gap-1.5 mt-1.5">
                  <MapPin className="h-3 w-3 text-muted-foreground mt-0.5 shrink-0" />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {selectedProperty.address}
                  </p>
                </div>

                <Button
                  size="sm"
                  variant="outline"
                  className="w-full mt-3 h-7 text-xs"
                  onClick={() =>
                    navigate(`/company/${selectedProperty.id_company}/property/${selectedProperty.id_propierty}`)
                  }
                >
                  {t("common.viewDetail") || "Ver detalle"}
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* TABLE */}
        <GenericTable<Property>
          data={properties}
          columns={columns}
          loading={loading}
          enableSearch
          enableDateRange={false}
          searchFields={["name_propierty", "address", "description_place", "code_propierty"]}
          defaultSort={{ key: "registration_date", direction: "desc" }}
          onRowClick={(row) => setSelectedProperty(row)}
        />

      </div>
    </DashboardLayout>
  );
}