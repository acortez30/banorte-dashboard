// pages/Property.tsx
import { useNavigate, useParams } from "react-router-dom";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { useLanguage } from "@/contexts/LanguageContext";
import { AlertTriangle, Building2, MapPin, Hash } from "lucide-react";
import { Button } from "@/components/ui/button";

import { useProperties } from "@/hooks/useProperties";
import { PropertyKPIs } from "@/components/property/PropertyKPIs";
import { PropertyMap } from "@/components/property/PropertyMap";
import { PropertyTable } from "@/components/property/PropertyTable";
import { CreatePropertyDialog } from "@/components/property/CreatePropertyDialog";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";

export default function Property() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const { id_company: paramCompany } = useParams<{ id_company?: string }>();

  // Resolución id_company: param URL > localStorage company
  const idCompany = paramCompany
    ? parseInt(paramCompany)
    : (() => {
        try {
          return JSON.parse(localStorage.getItem("company") ?? "null")?.id_company ?? null;
        } catch {
          return null;
        }
      })();

  const { properties, company, loading, error, kpis, refetch } = useProperties(idCompany);

  // KPIs — mismo patrón que Tickets.tsx
  const kpisCards = [
    {
      label: t("property.totalProperties") || "Total propiedades",
      value: kpis.total.toString(),
      icon: Building2,
      color: "text-primary",
    },
    {
      label: t("property.activeProperties") || "Propiedades activas",
      value: kpis.active.toString(),
      icon: MapPin,
      color: "text-success",
    },
    {
      label: t("property.totalLockers") || "Total lockers",
      value: kpis.totalLockers.toString(),
      icon: Hash,
      color: "text-info",
    },
  ];

  const handleRowClick = (property: any) => {
    const propertyId =
      property?.id_propierty ??
      property?.rawData?.id_propierty ??
      property?.id;

    if (propertyId) {
      navigate(`/property/${idCompany}/detail/${propertyId}`);
    } else {
      console.error("No property ID found", property);
    }
  };

  // ── Loading ──────────────────────────────────────────────
  if (loading) {
      return (
        <DashboardLayout>
          <LoadingSpinner fullPage text={t("common.loading")} />
        </DashboardLayout>
      );
  }

  // ── Error ────────────────────────────────────────────────
  if (error) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <p className="text-destructive">{error}</p>
            <Button
              className="mt-4"
              variant="outline"
              onClick={() => refetch?.()}
            >
              {t("common.retry") || "Reintentar"}
            </Button>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">

        {/* Header + Botón crear */}
        <div className="flex items-center justify-between">
          <DashboardHeader
            title={company?.company_name ?? t("property.title") ?? "Propiedades"}
            subtitle={t("property.subtitle") ?? "Administra las propiedades de la empresa"}
          />
          {/* <CreatePropertyDialog
            idCompany={idCompany}
            onCreate={() => refetch?.()}
          /> */}
        </div>

        {/* KPIs */}
        {/* <PropertyKPIs kpis={kpisCards} /> */}

        {/* Big Card + Mapa */}
        <PropertyMap company={company} properties={properties} />

        {/* Tabla con búsqueda, paginación y export */}
        <PropertyTable
          properties={properties}
          onRowClick={handleRowClick}
        />

      </div>
    </DashboardLayout>
  );
}
