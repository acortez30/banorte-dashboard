// src/pages/PropertyDetailPage.tsx
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { ChevronLeft, Plus, Package, X } from "lucide-react";
import { companyService } from "@/services/company.service";
import { Column } from "@/components/ui/types";
import { GenericTable } from "@/components/ui/GenericTable";
import SelectableMap from "@/components/ui/Selectablemap";
import PropertyOperationsCard from "@/components/property/PropertyOperationsCard";

// Tipos
interface ServiceLine {
  id_line_service: number;
  name_propierty_unit: string;
  line_service_name: string;
  city: string;
  state_name: string;
  country_name: string;
  address: string;
  latitud: string;
  longitud: string;
  id_status: number;
  allow_signature?: boolean;
  enable_carrier_passcode?: boolean;
  enable_lsa_webcam_photo?: boolean;
}

interface PropertyData {
  name_propierty: string;
  address: string;
  latitud: string;
  longitud: string;
  company_name: string;
  description?: string;
}

interface CompanyData {
  company_name: string;
  map_lat_center_point: string;
  map_length_center_point: string;
}

// Componente para el toggle
function ToggleSwitch({ 
  enabled, 
  onChange
}: { 
  enabled: boolean; 
  onChange: (enabled: boolean) => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={enabled}
      onClick={() => onChange(!enabled)}
      className={`
        relative inline-flex h-5 w-9 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent 
        transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2
        ${enabled ? "bg-primary" : "bg-muted"}
      `}
    >
      <span
        className={`
          pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-lg ring-0 
          transition duration-200 ease-in-out
          ${enabled ? "translate-x-4" : "translate-x-0"}
        `}
      />
    </button>
  );
}

// Componente BigCard
function BigCard({ quantity, title }: { quantity: number; title: string }) {
  return (
    <Card className="p-6 flex flex-col items-center justify-center text-center h-full">
      <Package className="h-12 w-12 text-primary mb-3" />
      <p className="text-3xl font-bold text-foreground">{quantity}</p>
      <p className="text-sm text-muted-foreground mt-1">{title}</p>
    </Card>
  );
}

export default function PropertyDetailPage() {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { id_company, id_property } = useParams<{ id_company: string; id_property: string }>();

  const [services, setServices] = useState<ServiceLine[]>([]);
  const [loading, setLoading] = useState(true);
  const [property, setProperty] = useState<PropertyData | null>(null);
  const [company, setCompany] = useState<CompanyData | null>(null);
  const [selectedService, setSelectedService] = useState<ServiceLine | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  const idUserType = user?.id_user_type ?? user?.data_company?.id_user_type;

  // Cargar datos
  useEffect(() => {
    if (!id_company || !id_property) {
      toast.error("ID de compañía o propiedad no encontrado");
      navigate("/company");
      return;
    }
    
    loadPropertyData();
    loadCompanyData();
    loadServices();
  }, [id_company, id_property]);

  const loadPropertyData = async () => {
    try {
      const res: any = await companyService.getPropertiesID(Number(id_company), Number(id_property));
      if (res?.properties) {
        const prop = res.properties;
        setProperty({
          name_propierty: prop.name_propierty,
          address: prop.address,
          latitud: prop.latitud,
          longitud: prop.longitud,
          company_name: prop.company_name,
          description: prop.description,
        });
      }
    } catch (error) {
      console.error("Error loading property:", error);
      toast.error("Error al cargar datos de la propiedad");
    }
  };

  const loadCompanyData = async () => {
    try {
      const res: any = await companyService.getCompanyId(Number(id_company));
      if (res?.companies?.[0]) {
        setCompany({
          company_name: res.companies[0].company_name,
          map_lat_center_point: res.companies[0].map_lat_center_point,
          map_length_center_point: res.companies[0].map_length_center_point,
        });
      }
    } catch (error) {
      console.error("Error loading company:", error);
    }
  };

  const loadServices = async () => {
    try {
      setLoading(true);
      const res: any = await companyService.getLineService(Number(id_property));
      if (res?.properties) {
        setServices(res.properties);
      }
    } catch (error) {
      console.error("Error loading services:", error);
      toast.error("Error al cargar servicios");
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = (service: ServiceLine) => {
    setSelectedService(service);
    setShowDetails(true);
  };

  const closeDetails = () => {
    setShowDetails(false);
    setSelectedService(null);
  };

  const addServiceToProperty = () => {
    navigate(`/company/${id_company}/property/${id_property}/add-service`);
  };

  // Actualizar toggle
  const updateServiceSetting = async (serviceId: number, field: string, value: boolean) => {
    try {
      // TODO: Implementar API call
      toast.success("Configuración actualizada");
      
      // Actualizar estado local
      setServices(prev => prev.map(s => 
        s.id_line_service === serviceId 
          ? { ...s, [field]: value }
          : s
      ));
    } catch (error) {
      toast.error("Error al actualizar");
    }
  };

  // Columnas para la tabla de servicios
  const columns: Column<ServiceLine>[] = [
    {
      key: "name_propierty_unit",
      header: t("propertyDetailPage.tableServices.name_propierty_unit") || "Unidad",
      sortable: true,
      render: (row) => <span className="font-medium text-sm">{row.name_propierty_unit}</span>
    },
    {
      key: "line_service_name",
      header: t("propertyDetailPage.tableServices.line_service_name") || "Servicio",
      sortable: true,
      render: (row) => <span className="text-sm">{row.line_service_name}</span>
    },
    {
      key: "city",
      header: t("propertyDetailPage.tableServices.city") || "Ciudad",
      sortable: true,
      render: (row) => <span className="text-sm text-muted-foreground">{row.city}</span>
    },
    {
      key: "state_name",
      header: t("propertyDetailPage.tableServices.state_name") || "Estado",
      sortable: true,
      render: (row) => <span className="text-sm text-muted-foreground">{row.state_name}</span>
    },
    {
      key: "country_name",
      header: t("propertyDetailPage.tableServices.country_name") || "País",
      sortable: true,
      render: (row) => <span className="text-sm text-muted-foreground">{row.country_name}</span>
    },
    {
      key: "address",
      header: t("propertyDetailPage.tableServices.address") || "Dirección",
      sortable: false,
      render: (row) => (
        <span className="text-sm text-muted-foreground block truncate max-w-[300px]">
          {row.address?.length > 45 ? `${row.address.substring(0, 45)}...` : row.address}
        </span>
      )
    }
  ];

  // Si es admin, agregar columnas de toggles
  if (idUserType === 1) {
    columns.push(
      {
        key: "allow_signature",
        header: t("propertyDetailPage.tableServices.allow_signature") || "Permitir firma",
        sortable: false,
        render: (row) => (
          <ToggleSwitch
            enabled={row.allow_signature || false}
            onChange={(val) => updateServiceSetting(row.id_line_service, "allow_signature", val)}
          />
        )
      },
      {
        key: "enable_carrier_passcode",
        header: t("propertyDetailPage.tableServices.enable_carrier_passcode") || "Código mensajería",
        sortable: false,
        render: (row) => (
          <ToggleSwitch
            enabled={row.enable_carrier_passcode || false}
            onChange={(val) => updateServiceSetting(row.id_line_service, "enable_carrier_passcode", val)}
          />
        )
      },
      {
        key: "enable_lsa_webcam_photo",
        header: t("propertyDetailPage.tableServices.enable_lsa_webcam_photo") || "Foto webcam",
        sortable: false,
        render: (row) => (
          <ToggleSwitch
            enabled={row.enable_lsa_webcam_photo || false}
            onChange={(val) => updateServiceSetting(row.id_line_service, "enable_lsa_webcam_photo", val)}
          />
        )
      }
    );
  }

  // Coordenadas del mapa - usar las de la propiedad si existen, sino las de la compañía
  const mapLat = property?.latitud ? parseFloat(property.latitud) : 
                 company?.map_lat_center_point ? parseFloat(company.map_lat_center_point) : undefined;
  const mapLng = property?.longitud ? parseFloat(property.longitud) : 
                 company?.map_length_center_point ? parseFloat(company.map_length_center_point) : undefined;

  // Manejador de selección de ubicación (solo para visualización, no editable)
  const handleLocationSelect = ({ lat, lng }: { lat: number; lng: number }) => {
    // En modo detalle, no permitimos editar la ubicación
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => navigate(`/property`)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            
            <div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground mb-0.5">
                {idUserType === 1 && (
                  <>
                    <span 
                      className="cursor-pointer hover:text-foreground transition-colors"
                      onClick={() => navigate("/company")}
                    >
                      {t("addLineServicePage.company") || "Compañía"}
                    </span>
                    <span>/</span>
                  </>
                )}
                <span 
                  className="cursor-pointer hover:text-foreground transition-colors"
                  onClick={() => navigate(`/company/${id_company}`)}
                >
                  {company?.company_name || "..."}
                </span>
                <span>/</span>
                <span className="text-foreground">
                  {property?.name_propierty || t("propertyDetailPage.title") || "Detalle de propiedad"}
                </span>
              </div>
              <h1 className="text-xl font-bold font-poppins">
                {property?.name_propierty || t("propertyDetailPage.title") || "Detalle de propiedad"}
              </h1>
              {property?.address && (
                <p className="text-xs text-muted-foreground mt-0.5">{property.address}</p>
              )}
            </div>
          </div>

          {/* Botón agregar servicio - solo admin */}
          {idUserType === 1 && (
            <Button onClick={addServiceToProperty} className="gap-2">
              <Plus className="h-4 w-4" />
              {t("buttons.addService") || "Agregar servicio"}
            </Button>
          )}
        </div>

        {/* Cards + Mapa */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Big Card - Cantidad de servicios */}
          <div className="lg:col-span-1">
            <BigCard 
              quantity={services.length} 
              title={t("propertyDetailPage.services") || "Servicios"} 
            />
          </div>

          {/* Mapa */}
          <div className="lg:col-span-2">
            <div className="metric-card p-0 overflow-hidden relative">
              <div className="px-4 py-3 border-b border-border">
                <p className="text-[13px] font-semibold font-poppins text-foreground">
                  {t("propertyDetailPage.map.title") || "Ubicación"}
                </p>
              </div>

              <div className="h-[400px] relative">
                {mapLat && mapLng && (
                  <SelectableMap
                    lat={mapLat}
                    lng={mapLng}
                    onLocationSelect={handleLocationSelect}
                  />
                )}

                {/* Panel de detalles del servicio seleccionado (por ahora lo mostramos al hacer click en la tabla) */}
                {showDetails && selectedService && (
                  <div className="absolute top-4 right-4 w-80 bg-card rounded-lg shadow-lg border border-border p-4 z-10">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold text-sm">
                        {t("propertyDetailPage.serviceDetails.title") || "Detalles de la zona"}
                      </h3>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={closeDetails}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-foreground">
                        {selectedService.name_propierty_unit}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {selectedService.address}
                      </p>
                      <Badge variant="secondary" className="text-xs">
                        {selectedService.line_service_name}
                      </Badge>
                    </div>
                  </div>
                )}
              </div>

              <div className="px-4 py-2 border-t border-border bg-muted/30">
                <div className="flex items-center gap-4 justify-center">
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500" />
                    <span className="text-xs text-muted-foreground">
                      {t("propertyDetailPage.map.companyMarker") || "Ubicación"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {idUserType === 1 && id_company && id_property && (
          <PropertyOperationsCard
            idCompany={Number(id_company)}
            idProperty={Number(id_property)}
            language={language}
            t={t}
          />
        )}

        {/* Tabla de servicios */}

          <GenericTable
            data={services}
            columns={columns}
            loading={loading}
            enableSearch
            enableDateRange={false}
            searchFields={["name_propierty_unit", "line_service_name", "address", "city"]}
            defaultSort={{ key: "name_propierty_unit", direction: "asc" }}
            onRowClick={(row) => {
              handleServiceSelect(row);
            }}
          />

      </div>
    </DashboardLayout>
  );
}