import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { DateRange } from "react-day-picker";
import { Settings } from "lucide-react";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useLanguage } from "@/contexts/LanguageContext";
import { lockerDetailService } from "@/services/locker-detail.service";
import { lockersService } from "@/services/locker.service";
import type {
  OrdersPriorityStatus,
  OrdersSortBy,
  OrdersSortDir,
  PackageSearchBy,
} from "@/services/orders.service";
import { useLocalStorageState } from "@/hooks/useLocalStorageState";

import LockerDetailHeader from "@/components/locker-detail/LockerDetailHeader";
import LockerLocationCard from "@/components/locker-detail/LockerLocationCard";
import LockerUsageChartCard from "@/components/locker-detail/LockerUsageChartCard";
import AvgCollectionTimeCard from "@/components/locker-detail/AvgCollectionTimeCard";
import DeliveredSuccessfullyCard from "@/components/locker-detail/DeliveredSuccessfullyCard";
import CapacityBySizeCard from "@/components/locker-detail/CapacityBySizeCard";
import DoorStatusBar from "@/components/locker-detail/DoorStatusBar";
import LockersDesign from "@/components/ui/LockersDesign";
import UpdateAddresseeModal from "@/components/locker-detail/UpdateAddresseeModal";
import LockerOrdersSection from "@/components/locker-detail/LockerOrdersSection";
import LockerInstallationEvidenceCard from "@/components/locker-detail/LockerInstallationEvidenceCard";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import FailedCompartmentDialog, {
  type FailedCompartmentDoor,
  getFailedDoorDimensionId,
  isFailedCompartment,
} from "@/components/locker-detail/FailedCompartmentDialog";

interface LockerDetailFilters {
  dateRange: DateRange | undefined;
  statusFilter: string;
  offeringFilter: string;
  search: string;
  searchBy?: PackageSearchBy;
  sortBy?: OrdersSortBy | "";
  sortDir?: OrdersSortDir;
  priorityStatus?: OrdersPriorityStatus | "";
}

/* ========================= */
/* HELPERS                   */
/* ========================= */

function toValidDate(value: unknown): Date | undefined {
  if (!value) return undefined;

  if (value instanceof Date) {
    return Number.isNaN(value.getTime()) ? undefined : value;
  }

  const parsed = new Date(String(value));
  return Number.isNaN(parsed.getTime()) ? undefined : parsed;
}

function normalizeDateRange(range: any): DateRange | undefined {
  if (!range) return undefined;

  const from = toValidDate(range.from);
  const to = toValidDate(range.to);

  if (!from && !to) return undefined;

  return { from, to };
}

export default function LockerDetails() {
  const { id } = useParams();
  const { t } = useLanguage();

  /* ========================= */
  /* USER & PERMISSIONS        */
  /* ========================= */

  const user = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem("user") || "{}");
    } catch {
      return {};
    }
  }, []);

  const isHouseAccount = user?.user_type === "HOUSE ACCOUNT";
  const idUserType = Number(
    user?.id_user_type ?? user?.data_company?.id_user_type ?? 0
  );
  const userTypeName = String(
    user?.user_type ??
      user?.type_user ??
      user?.name_user_type ??
      user?.data_company?.user_type ??
      user?.data_company?.type_user ??
      user?.data_company?.name_user_type ??
      ""
  )
    .trim()
    .toUpperCase();

  // SUPER USUARIO / SUPER USER. El id_user_type=1 se mantiene como respaldo.
  const isSuperUser =
    idUserType === 1 ||
    userTypeName.includes("SUPER USUARIO") ||
    userTypeName.includes("SUPER USER") ||
    userTypeName === "SUPER";
  const isSupport =
    idUserType === 7 ||
    userTypeName.includes("SOPORTE") ||
    userTypeName.includes("SUPPORT");

  /* ========================= */
  /* STATE                     */
  /* ========================= */

  const [lockerSelected, setLockerSelected] = useState<any | null>(null);
  const [loadingLocker, setLoadingLocker] = useState(true);

  const [availableBySize, setAvailableBySize] = useState<Record<string, number>>(
    {}
  );
  const [compartmentTotals, setCompartmentTotals] = useState<
    Record<string, number>
  >({});

  const [doorStatusData, setDoorStatusData] = useState<
    { name_status: string; quantity: number }[]
  >([]);

  const [delivery, setDelivery] = useState(0);
  const [pickup, setPickup] = useState(0);
  const [refund, setRefund] = useState(0);
  const [averageTime, setAverageTime] = useState("00:00");

  const [dateRangeLabel, setDateRangeLabel] = useState("");

  const [addresseeModalOpen, setAddresseeModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const [selectedFailedDoor, setSelectedFailedDoor] =
    useState<FailedCompartmentDoor | null>(null);
  const [supportAction, setSupportAction] = useState<
    "close" | "verify" | null
  >(null);
  const [gridRefreshKey, setGridRefreshKey] = useState(0);
  const ordersSectionRef = useRef<HTMLDivElement | null>(null);

  /* ========================= */
  /* FILTROS PERSISTENTES      */
  /* ========================= */

  const storageKey = id ? `locker_filters_${id}` : "locker_filters_pending";

  const [filters, setFilters] = useLocalStorageState<LockerDetailFilters>(
    storageKey,
    {
      dateRange: {
        from: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
        to: new Date(),
      },
      statusFilter: "all",
      offeringFilter: "all",
      search: "",
      searchBy: "tracking",
      sortBy: "",
      sortDir: "desc",
      priorityStatus: "",
    }
  );

  const dateRange = useMemo(
    () => normalizeDateRange(filters.dateRange),
    [filters.dateRange]
  );

  const { statusFilter, offeringFilter, search } = filters;
  const searchBy: PackageSearchBy =
    filters.searchBy === "email" ? "email" : "tracking";

  // Compatibilidad con filtros persistidos antes de incorporar orden/prioridad.
  const sortBy: OrdersSortBy | "" = filters.sortBy ?? "";
  const sortDir: OrdersSortDir = filters.sortDir === "asc" ? "asc" : "desc";
  const priorityStatus: OrdersPriorityStatus | "" =
    filters.priorityStatus ?? "";

  const setDateRange = useCallback(
    (range: DateRange | undefined) => {
      const normalizedRange = normalizeDateRange(range);

      setFilters((prev) => {
        const prevRange = normalizeDateRange(prev.dateRange);

        const sameFrom =
          prevRange?.from?.getTime() === normalizedRange?.from?.getTime();
        const sameTo =
          prevRange?.to?.getTime() === normalizedRange?.to?.getTime();

        if (sameFrom && sameTo) return prev;

        return {
          ...prev,
          dateRange: normalizedRange,
        };
      });
    },
    [setFilters]
  );

  const setStatusFilter = useCallback(
    (value: string) => {
      setFilters((prev) => ({ ...prev, statusFilter: value }));
    },
    [setFilters]
  );

  const setOfferingFilter = useCallback(
    (value: string) => {
      setFilters((prev) => ({ ...prev, offeringFilter: value }));
    },
    [setFilters]
  );

  const setSearch = useCallback(
    (value: string) => {
      setFilters((prev) => ({ ...prev, search: value }));
    },
    [setFilters]
  );

  const setSearchBy = useCallback(
    (value: PackageSearchBy) => {
      setFilters((prev) => ({ ...prev, searchBy: value }));
    },
    [setFilters]
  );

  const setSortBy = useCallback(
    (value: OrdersSortBy | "") => {
      setFilters((prev) => ({
        ...prev,
        sortBy: value,
        sortDir: prev.sortDir ?? "desc",
      }));
    },
    [setFilters]
  );

  const setSortDir = useCallback(
    (value: OrdersSortDir) => {
      setFilters((prev) => ({ ...prev, sortDir: value }));
    },
    [setFilters]
  );

  const setPriorityStatus = useCallback(
    (value: OrdersPriorityStatus | "") => {
      setFilters((prev) => ({ ...prev, priorityStatus: value }));
    },
    [setFilters]
  );

  const resetOrderQuery = useCallback(() => {
    setFilters((prev) => ({
      ...prev,
      sortBy: "",
      sortDir: "desc",
      priorityStatus: "",
    }));
  }, [setFilters]);

  /* ========================= */
  /* DERIVED DATA              */
  /* ========================= */

  const capacity = useMemo(() => {
    const order = ["S", "M", "L", "XL", "XXL", "XXXL"];

    return Object.entries(availableBySize)
      .map(([size, available]) => ({
        label: size,
        available,
        total: compartmentTotals[size] ?? 0,
      }))
      .sort((a, b) => order.indexOf(a.label) - order.indexOf(b.label));
  }, [availableBySize, compartmentTotals]);

  const successRate =
    delivery + refund > 0
      ? Math.round((delivery / (delivery + refund)) * 100)
      : 0;

  /* ========================= */
  /* FETCH LOCKER              */
  /* ========================= */

  const fetchLocker = useCallback(async () => {
    if (!id) return;

    try {
      setLoadingLocker(true);

      const month = new Date().getMonth();
      const year = new Date().getFullYear();

      const payload = {
        language: "es",
        month_actuality: month + 1,
        last_month: month,
        year,
      };

      const res: any = await lockersService.getLockers(payload);
      const lockers = res?.return_result?.[0]?.[1] || [];

      const selected = lockers.find(
        (locker: any) => locker.id_locker === Number(id)
      );

      setLockerSelected(selected || null);
    } catch (error) {
      console.error("Error loading locker:", error);
    } finally {
      setLoadingLocker(false);
    }
  }, [id]);

  /* ========================= */
  /* FETCH METRICS             */
  /* ========================= */

  const fetchMetrics = useCallback(async () => {
    if (!id) return;

    try {
      const payload = {
        language: localStorage.getItem("lang") || "es",
        id_locker: Number(id),
      };

      const res: any = await lockerDetailService.getMetricsLocker(payload);
      const metrics = res?.return_metric;

      if (!metrics) return;

      const status = metrics.metric_status || {};

      setDelivery(Number(status.total_delivery ?? 0));
      setPickup(Number(status.total_pickup ?? 0));
      setRefund(Number(status.total_refund ?? 0));

      setAverageTime(
        metrics.average_time_collection
          ? metrics.average_time_collection.split(".")[0]
          : "00:00"
      );

      const compartments = metrics.available_compartment || [];
      const mapped: Record<string, number> = {};

      compartments.forEach((item: any) => {
        mapped[item.compartment_name] = Number(item.total_available ?? 0);
      });

      setAvailableBySize(mapped);
    } catch (error) {
      console.error("Error fetching locker metrics:", error);
    }
  }, [id]);

  /* ========================= */
  /* FETCH DOOR GRID           */
  /* ========================= */

  const fetchDoorGrid = useCallback(async () => {
    if (!id) return;

    try {
      const payload = {
        language: localStorage.getItem("lang") || "es",
        id_locker: Number(id),
      };

      const res: any = await lockerDetailService.getLockersGrid(payload);

      const compartmentList = res?.quantity_compartment?.compartment || [];
      const totals: Record<string, number> = {};

      compartmentList.forEach((c: any) => {
        totals[c.compartment_name] = Number(c.quantity ?? 0);
      });

      setCompartmentTotals(totals);

      const modules = res?.modulo_status || [];
      const statusCounter: Record<string, number> = {};

      modules.forEach((mod: any) => {
        mod.DOOR.forEach((door: any) => {
          let status = door.name_status?.toUpperCase();

          if (status === "OCUPADO" && door.PACKAGE?.length) {
            const pkg = door.PACKAGE[0];

            if (
              pkg.status_name === "VENCIDO" ||
              pkg.id_status_code_package === 32
            ) {
              status = "VENCIDO";
            }
          }

          statusCounter[status] = (statusCounter[status] || 0) + 1;
        });
      });

      const formatted = Object.entries(statusCounter).map(([name, qty]) => ({
        name_status: name,
        quantity: qty,
      }));

      setDoorStatusData(formatted);
    } catch (error) {
      console.error("Error loading door grid:", error);
    }
  }, [id]);


  /* ========================= */
  /* PACKAGE QUICK SEARCH      */
  /* ========================= */

  const handleSearchPackageInTable = useCallback(
    (packageInfo: any) => {
      const searchValue = String(
        packageInfo?.tracking_number ?? packageInfo?.order_number ?? ""
      ).trim();

      if (!searchValue) {
        toast.error(t("lockerDetail.packageContext.searchUnavailable"));
        return;
      }

      setFilters((prev) => ({
        ...prev,
        statusFilter: "all",
        offeringFilter: "all",
        search: searchValue,
      }));

      window.setTimeout(() => {
        ordersSectionRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }, 80);

      toast.success(t("lockerDetail.packageContext.searchApplied"));
    },
    [setFilters, t]
  );

  /* ========================= */
  /* SUPPORT DOOR ACTIONS      */
  /* ========================= */

  const canSelectFailedDoor = useCallback(
    (door: FailedCompartmentDoor) => isSupport && isFailedCompartment(door),
    [isSupport]
  );

  const handleFailedDoorSelected = useCallback(
    (door: FailedCompartmentDoor) => {
      if (!canSelectFailedDoor(door)) return;
      setSelectedFailedDoor(door);
    },
    [canSelectFailedDoor]
  );

  const refreshDoorGrid = useCallback(async () => {
    await fetchDoorGrid();
    setGridRefreshKey((current) => current + 1);
  }, [fetchDoorGrid]);

  const handleCloseFailedDoor = useCallback(async () => {
    if (!id || !selectedFailedDoor) return;

    const idLockerDimension = getFailedDoorDimensionId(selectedFailedDoor);
    if (!idLockerDimension) {
      toast.error(t("lockerDetail.invalidCompartment"));
      return;
    }

    try {
      setSupportAction("close");

      await lockersService.closeFailedCompartment(
        Number(id),
        idLockerDimension,
        localStorage.getItem("lang")?.toLowerCase() || "es"
      );

      toast.success(t("lockerDetail.closeDoorSuccess"));
      setSelectedFailedDoor(null);
      await refreshDoorGrid();
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : t("lockerDetail.supportActionError")
      );
    } finally {
      setSupportAction(null);
    }
  }, [id, refreshDoorGrid, selectedFailedDoor, t]);

  const handleVerifyFailedDoorPackage = useCallback(async () => {
    if (!id || !selectedFailedDoor) return;

    const idLockerDimension = getFailedDoorDimensionId(selectedFailedDoor);
    if (!idLockerDimension) {
      toast.error(t("lockerDetail.invalidCompartment"));
      return;
    }

    try {
      setSupportAction("verify");

      const response: any =
        await lockersService.verifyPackageInFailedCompartment(
          Number(id),
          idLockerDimension,
          localStorage.getItem("lang")?.toLowerCase() || "es"
        );

      const verifiedPackages = response?.result?.verified_packages;
      const verifiedSuffix = Array.isArray(verifiedPackages)
        ? `: ${verifiedPackages.join(", ")}`
        : "";

      toast.success(
        `${t("lockerDetail.verifyPackageSuccess")}${verifiedSuffix}`
      );
      setSelectedFailedDoor(null);
      await refreshDoorGrid();
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : t("lockerDetail.supportActionError")
      );
    } finally {
      setSupportAction(null);
    }
  }, [id, refreshDoorGrid, selectedFailedDoor, t]);

  /* ========================= */
  /* SUPER SETTINGS            */
  /* ========================= */

  const handleOpenSettings = useCallback(() => {
    if (!isSuperUser) {
      toast.error(
        "Solo el usuario SUPER puede modificar la configuración del locker."
      );
      return;
    }

    setSettingsOpen(true);
  }, [isSuperUser]);

  /* ========================= */
  /* EFFECTS                   */
  /* ========================= */

  useEffect(() => {
    fetchLocker();
    fetchMetrics();
    fetchDoorGrid();
  }, [fetchLocker, fetchMetrics, fetchDoorGrid]);

  useEffect(() => {
    if (!isSuperUser && settingsOpen) {
      setSettingsOpen(false);
    }
  }, [isSuperUser, settingsOpen]);

  /* ========================= */
  /* RENDER                    */
  /* ========================= */

  if (loadingLocker) {
    return (
      <DashboardLayout>
        <LoadingSpinner fullPage text={t("common.loading")} />
      </DashboardLayout>
    );
  }

  if (!lockerSelected) {
    return (
      <DashboardLayout>
        <div className="p-10 text-center text-destructive">
          Locker no encontrado
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
          <div className="min-w-0 flex-1">
            <LockerDetailHeader
              lockerName={lockerSelected.description}
              lockerLocation={lockerSelected.locker_address}
              dateRange={dateRange}
              onDateChange={setDateRange}
              isActive={lockerSelected.status_locker === 1}
            />
          </div>

          {isSuperUser && (
            <Button
              type="button"
              variant="outline"
              className="shrink-0 gap-2 xl:mt-1"
              onClick={handleOpenSettings}
            >
              <Settings className="h-4 w-4" />
              Configuración
            </Button>
          )}
        </div>

        <LockerLocationCard
          address={lockerSelected.locker_address}
          lat={lockerSelected.latitud}
          lng={lockerSelected.longitud}
          theme="light"
        />

        {isSuperUser && (
          <LockerInstallationEvidenceCard
            idLocker={Number(id)}
            canUpload={isSuperUser}
          /> 
          )
        }

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <LockerUsageChartCard
            data={[
              {
                month: "Actual",
                recolectados: pickup,
                entregados: delivery,
                refund,
              },
            ]}
            dateRangeLabel={dateRangeLabel}
          />

          <div className="flex flex-col gap-4">
            <AvgCollectionTimeCard
              averageTime={averageTime}
              trendPercentage={0}
            />
            <DeliveredSuccessfullyCard
              total={delivery}
              successRate={successRate}
            />
          </div>
        </div>

        <CapacityBySizeCard data={capacity} />
        <DoorStatusBar data={doorStatusData} />

        <div className="metric-card overflow-x-auto">
          <p className="font-poppins text-[13px] font-semibold text-foreground mb-3">
            {t("lockerDetail.doorMap")}
          </p>

          <LockersDesign
            id_locker={Number(id)}
            onLockerSelected={isSupport ? handleFailedDoorSelected : undefined}
            canSelectDoor={isSupport ? canSelectFailedDoor : undefined}
            refreshKey={gridRefreshKey}
            isSuperUser={isSuperUser}
            onSearchPackageInTable={handleSearchPackageInTable}
          />

          <p className="mt-3 text-xs text-muted-foreground">
            {t("lockerDetail.packageContext.help")}
          </p>

          {isSupport && (
            <p className="mt-3 text-xs text-muted-foreground">
              {t("lockerDetail.failedDoorHelp")}
            </p>
          )}
        </div>

        <div ref={ordersSectionRef} className="scroll-mt-6">
          <LockerOrdersSection
            id_locker={Number(id)}
            dateRange={dateRange}
            onDateChange={setDateRange}
            statusFilter={statusFilter}
            onStatusFilterChange={setStatusFilter}
            offeringFilter={offeringFilter}
            onOfferingFilterChange={setOfferingFilter}
            search={search}
            onSearchChange={setSearch}
            searchBy={searchBy}
            onSearchByChange={setSearchBy}
            sortBy={sortBy}
            onSortByChange={setSortBy}
            sortDir={sortDir}
            onSortDirChange={setSortDir}
            priorityStatus={priorityStatus}
            onPriorityStatusChange={setPriorityStatus}
            onResetOrderQuery={resetOrderQuery}
            onEmailClick={(order) => {
              setSelectedOrder(order);
              setAddresseeModalOpen(true);
            }}
          />
        </div>
      </div>

      <UpdateAddresseeModal
        open={addresseeModalOpen}
        onOpenChange={setAddresseeModalOpen}
        selectedOrder={selectedOrder}
      />

      <FailedCompartmentDialog
        door={selectedFailedDoor}
        open={Boolean(selectedFailedDoor)}
        loadingAction={supportAction}
        onOpenChange={(open) => {
          if (!open) setSelectedFailedDoor(null);
        }}
        onCloseDoor={handleCloseFailedDoor}
        onVerifyPackage={handleVerifyFailedDoorPackage}
      />

      {isSuperUser && (
        <Dialog
          open={settingsOpen}
          onOpenChange={(open) => {
            if (open && !isSuperUser) return;
            setSettingsOpen(open);
          }}
        >
          <DialogContent className="sm:max-w-[560px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Configuración del locker
              </DialogTitle>
              <DialogDescription>
                Modifica la configuración de {lockerSelected.description}.
              </DialogDescription>
            </DialogHeader>

            <div className="py-4">
              <div className="rounded-xl border border-dashed bg-muted/20 p-6 text-center">
                <Settings className="mx-auto mb-3 h-8 w-8 text-muted-foreground" />
                <p className="text-sm font-medium text-foreground">
                  Configuración del locker
                </p>
                <p className="mt-2 text-sm text-muted-foreground">
                  El endpoint está disponible, pero el backend aún no documenta
                  los campos aceptados por el body.
                </p>
              </div>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setSettingsOpen(false)}
              >
                Cerrar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </DashboardLayout>
  );
}