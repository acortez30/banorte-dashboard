// pages/Tickets.tsx
import { useNavigate } from "react-router-dom";
import { useState } from "react";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { TabFilter } from "@/components/dashboard/TabFilter";

import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";

import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Wrench,
} from "lucide-react";

import { useTickets } from "@/hooks/useTickets";

import { TicketsKPIs } from "@/components/tickets/TicketsKPIs";
import { TicketsFilters } from "@/components/tickets/TicketsFilters";
import { TicketsTable } from "@/components/tickets/TicketsTable";

import { CreateTicketDialog } from "@/components/tickets/CreateTicketDialog";
import { TicketConfirmDialog } from "@/components/tickets/TicketConfirmDialog";
import { Button } from "@/components/ui/button";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";

export default function Tickets() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const { user } = useAuth(); // Obtener usuario autenticado

  // 🔥 dialogs state
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [createdTicketId, setCreatedTicketId] = useState<string | number | null>(null);

  const {
    searchQuery,
    setSearchQuery,
    statusFilter,
    setStatusFilter,
    categoryFilter,
    setCategoryFilter,
    priorityFilter,
    setPriorityFilter,
    filteredTickets,
    loading,
    error,
    getStatusCount,
    kpis: kpisData,
    refetch, 
  } = useTickets();

  // Obtener consumerId del usuario autenticado
  const consumerId = user?.id_consumer || user?.consumerId || 0;

  // Tabs con conteos reales
const statusTabs = [
  { id: "all", label: t("tickets.all"), count: getStatusCount("all") },
  { id: "open", label: t("tickets.open"), count: getStatusCount("open") },
  { id: "review", label: t("tickets.underReview"), count: getStatusCount("review") },
  { id: "closed", label: t("tickets.closed"), count: getStatusCount("closed") },
  { id: "archived", label: t("tickets.archived"), count: getStatusCount("archived") },
];

  // Configs de estado
const statusConfig = {
  open: {
    label: t("tickets.status.open"),
    className: "bg-accent/10 text-accent border-accent/20",
  },
  review: {
    label: t("tickets.status.review"),
    className: "bg-secondary text-secondary-foreground border-border",
  },
  closed: {
    label: t("tickets.status.closed"),
    className: "bg-success text-success-foreground border-border",
  },
  archived: {
    label: t("tickets.status.archived"),
    className: "bg-muted text-muted-foreground",
  },
};

  const priorityConfig = {
    low: {
      label: t("tickets.priority.low"),
      className: "bg-muted text-muted-foreground",
    },
    medium: {
      label: t("tickets.priority.medium"),
      className: "bg-warning/10 text-warning",
    },
    high: {
      label: t("tickets.priority.high"),
      className: "bg-destructive/10 text-destructive",
    },
    critical: {
      label: t("tickets.priority.critical"),
      className: "bg-destructive text-destructive-foreground",
    },
  };

  const categoryLabels = {
    maintenance: t("tickets.category.maintenance"),
    technical: t("tickets.category.technical"),
    access: t("tickets.category.access"),
    billing: t("tickets.category.billing"),
    other: t("tickets.category.other"),
  };

  // KPIs con datos reales
const kpis = [
  {
    label: t("tickets.openTickets"),
    value: kpisData.openTickets.toString(),
    icon: AlertTriangle,
    tooltip: t("tickets.metrics.openTicketsTooltip"),
    variant: "warning" as const,
  },
  {
    label: t("tickets.inProgress"),
    value: kpisData.inProgressTickets.toString(),
    icon: Clock,
    tooltip: t("tickets.metrics.inProgressTooltip"),
    variant: "info" as const,
  },
  {
    label: t("tickets.resolvedThisMonth"),
    value: kpisData.resolvedThisMonth.toString(),
    icon: CheckCircle2,
    tooltip: t("tickets.metrics.resolvedThisMonthTooltip"),
    variant: "success" as const,
  },
  {
    label: t("tickets.avgTime"),
    value: kpisData.avgTime,
    icon: Wrench,
    tooltip: t("tickets.metrics.avgTimeTooltip"),
    variant: "default" as const,
  },
];

  // Manejador para cuando se crea un ticket
  const handleTicketCreated = (ticket: any) => {
    
    // Extraer el ID del ticket de diferentes posibles estructuras de respuesta
    const ticketId = ticket?.data?.id_consumer_ticket || 
                     ticket?.id_consumer_ticket || 
                     ticket?.id ||
                     ticket?.ticketId;
    
    setCreatedTicketId(ticketId);
  
    
    // Recargar la lista de tickets después de crear uno nuevo
    setTimeout(() => {
      refetch?.(); // Recargar tickets si la función existe
        setConfirmOpen(true);
    }, 1000);
  };

  // Mostrar loading state
// Después ✅
if (loading) {
  return (
    <DashboardLayout>
      <LoadingSpinner fullPage text={t("common.loading")} />
    </DashboardLayout>
  );
}

  // Mostrar error state
  if (error) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <p className="text-destructive">{error}</p>
            {user?.id_user_type !== 7 && (
              <Button 
                className="mt-4" 
                variant="outline" 
                onClick={() => window.location.reload()}
              >
                {t("common.retry") || "Retry"}
              </Button>
            )}
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header + CREATE BUTTON */}
        <div className="flex items-center justify-between">
          <DashboardHeader
            title={t("tickets.title")}
            subtitle={t("tickets.subtitle")}
          />

          {user?.id_user_type !== 7 && (
            <CreateTicketDialog
              categoryLabels={categoryLabels}
              priorityConfig={priorityConfig}
              consumerId={consumerId}
              onCreate={handleTicketCreated}
            />
          )}
        </div>

        {/* KPIs */}
        <TicketsKPIs kpis={kpis} />

        {/* Tabs */}
        <div className="mt-6">
          <TabFilter
            tabs={statusTabs}
            activeTab={statusFilter}
            onTabChange={setStatusFilter}
          />
        </div>

        {/* Filters - Comentados hasta que estén implementados */}
        {/* <TicketsFilters
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          categoryFilter={categoryFilter}
          setCategoryFilter={setCategoryFilter}
          priorityFilter={priorityFilter}
          setPriorityFilter={setPriorityFilter}
          categoryLabels={categoryLabels}
          priorityConfig={priorityConfig}
        /> */}

        {/* Table */}
        <TicketsTable
          tickets={filteredTickets}
          onRowClick={(ticket: any) => {
            // Extraer el ID correctamente según la estructura del ticket
            const ticketId = ticket?.id_consumer_ticket || 
                            ticket?.rawData?.id_consumer_ticket || 
                            ticket?.id;
            
            if (ticketId) {
              navigate(`/tickets/${ticketId}`);
            } else {
              console.error("No ticket ID found", ticket);
            }
          }}
          statusConfig={statusConfig}
          priorityConfig={priorityConfig}
          categoryLabels={categoryLabels}
        />

        {/* ✅ Confirm Dialog */}
        {/* <TicketConfirmDialog
          open={confirmOpen}
          onClose={() => {
            setConfirmOpen(false);
            setCreatedTicketId(null);
          }}
          ticketId={createdTicketId?.toString() || undefined}
        /> */}
      </div>
    </DashboardLayout>
  );
}