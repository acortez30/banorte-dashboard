import { useMemo, useState } from "react";
import { Boxes, DoorOpen, Pencil, Plus, Search, UsersRound } from "lucide-react";
import { toast } from "sonner";
import DashboardLayout from "@/components/layout/DashboardLayout";
import PageHeader from "@/components/common/PageHeader";
import MetricCard from "@/components/common/MetricCard";
import StatusBadge from "@/components/common/StatusBadge";
import TablePagination from "@/components/common/TablePagination";
import LockerFormDialog from "@/components/lockers/LockerFormDialog";
import { useData } from "@/contexts/DataContext";
import { getLockerLoads } from "@/utils/lockerAssignment";
import type { LockerIsland } from "@/types/dashboard";

export default function Lockers() {
  const { lockers, employees, addLocker, updateLocker } = useData();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<LockerIsland | null>(null);

  const loads = useMemo(() => getLockerLoads(lockers, employees), [employees, lockers]);
  const active = lockers.filter((locker) => locker.active);
  const totalCompartments = active.reduce((sum, locker) => sum + locker.compartments, 0);
  const assigned = employees.filter((employee) => active.some((locker) => locker.id === employee.lockerId)).length;
  const filtered = loads.filter(({ locker }) => `${locker.alias} ${locker.location}`.toLowerCase().includes(search.toLowerCase()));
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize);

  const openCreate = () => { setEditing(null); setDialogOpen(true); };
  const openEdit = (locker: LockerIsland) => { setEditing(locker); setDialogOpen(true); };

  return (
    <DashboardLayout>
      <div className="space-y-5 animate-fade-in">
        <PageHeader
          title="Lockers"
          description="Alta y administración de islas Banorte. No hay mapa ni conexiones externas; los datos son mockup."
          actions={<button className="btn-primary" onClick={openCreate}><Plus size={17} /> Nuevo locker</button>}
        />

        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <MetricCard label="Islas activas" value={active.length} helper={`${lockers.length} registradas`} icon={Boxes} />
          <MetricCard label="Compartimentos" value={totalCompartments.toLocaleString("es-MX")} helper="133 por cada isla" icon={DoorOpen} />
          <MetricCard label="Empleados asignados" value={assigned.toLocaleString("es-MX")} helper="Referencia de capacidad" icon={UsersRound} />
          <MetricCard label="Capacidad disponible" value={Math.max(totalCompartments - assigned, 0).toLocaleString("es-MX")} helper="Asignaciones restantes" icon={DoorOpen} alert={assigned > totalCompartments} />
        </div>

        <section className="table-shell">
          <div className="table-toolbar">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={16} />
              <input className="form-input h-10 pl-9" value={search} onChange={(event) => { setSearch(event.target.value); setPage(1); }} placeholder="Buscar locker o ubicación" />
            </div>
            <p className="text-xs font-medium text-muted-foreground">Cada locker nuevo se crea con <strong className="text-foreground">133 compartimentos</strong>.</p>
          </div>

          <div className="overflow-x-auto">
            <table className="data-table min-w-[900px]">
              <thead><tr><th>Locker / Isla</th><th>Ubicación</th><th>Compartimentos</th><th>Empleados asignados</th><th>Disponibles</th><th>Estado</th><th className="text-right">Acción</th></tr></thead>
              <tbody>
                {paginated.map(({ locker, assigned: lockerAssigned, available, percent }) => (
                  <tr key={locker.id}>
                    <td><div className="font-semibold text-foreground">{locker.alias}</div><div className="mt-0.5 text-xs text-muted-foreground">{percent}% asignado</div></td>
                    <td>{locker.location}</td>
                    <td className="font-medium">{locker.compartments}</td>
                    <td>{lockerAssigned}</td>
                    <td><span className={available < 15 ? "font-semibold text-primary" : "font-semibold text-emerald-700"}>{available}</span></td>
                    <td><StatusBadge active={locker.active} /></td>
                    <td className="text-right"><button className="icon-action" onClick={() => openEdit(locker)} aria-label={`Editar ${locker.alias}`}><Pencil size={16} /></button></td>
                  </tr>
                ))}
                {!paginated.length ? <tr><td colSpan={7} className="py-12 text-center text-muted-foreground">No se encontraron lockers.</td></tr> : null}
              </tbody>
            </table>
          </div>
          <TablePagination page={page} pageSize={pageSize} total={filtered.length} onPageChange={setPage} onPageSizeChange={(size) => { setPageSize(size); setPage(1); }} />
        </section>
      </div>

      <LockerFormDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        locker={editing}
        onSubmit={(value) => {
          if (editing) {
            updateLocker(editing.id, value);
            toast.success("Locker actualizado");
          } else {
            addLocker(value);
            toast.success("Locker creado con 133 compartimentos");
          }
          setDialogOpen(false);
        }}
      />
    </DashboardLayout>
  );
}
