import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, Download, ArrowLeft } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

const notificationsTableData = [
  { id: 1, orderNumber: "244427", trackingNumber: "IM08030051096415", description: "Se realizó el retiro del paquete: 00007_IM08030051096415 a la fecha 2026-02-20", locker: "Nuevo Sur-0", status: "Recogida de paquete", date: "20 feb 2026" },
  { id: 2, orderNumber: "244427", trackingNumber: "IM08030051096415", description: "Cliente retira su paquete", locker: "Nuevo Sur-0", status: "Recogida de paquete", date: "20 feb 2026" },
  { id: 3, orderNumber: "244427", trackingNumber: "IM08030051096415", description: "Se realizó el retiro del paquete: 00007_IM08030051096415 a la fecha 2026-02-20", locker: "Nuevo Sur-0", status: "Recogida de paquete", date: "20 feb 2026" },
  { id: 4, orderNumber: "374146", trackingNumber: "id46486005519tlm", description: "Se realizó el retiro del paquete: 00007_id46486005519tlm a la fecha 2026-02-19", locker: "Nuevo Sur-0", status: "Recogida de paquete", date: "19 feb 2026" },
  { id: 5, orderNumber: "374146", trackingNumber: "id46486005519tlm", description: "Cliente retira su paquete", locker: "Nuevo Sur-0", status: "Recogida de paquete", date: "19 feb 2026" },
  { id: 6, orderNumber: "374146", trackingNumber: "id46486005519tlm", description: "Se realizó el retiro del paquete: 00007_id46486005519tlm a la fecha 2026-02-19", locker: "Nuevo Sur-0", status: "Recogida de paquete", date: "19 feb 2026" },
  { id: 7, orderNumber: "141975", trackingNumber: "9558082531", description: "Se realizó el retiro del paquete: 00007_9558082531 a la fecha 2026-02-18", locker: "Nuevo Sur-0", status: "Recogida de paquete", date: "18 feb 2026" },
  { id: 8, orderNumber: "141975", trackingNumber: "9558082531", description: "Cliente retira su paquete", locker: "Nuevo Sur-0", status: "Recogida de paquete", date: "18 feb 2026" },
  { id: 9, orderNumber: "141975", trackingNumber: "9558082531", description: "Se realizó el retiro del paquete: 00007_9558082531 a la fecha 2026-02-18", locker: "Nuevo Sur-0", status: "Recogida de paquete", date: "18 feb 2026" },
  { id: 10, orderNumber: "579665", trackingNumber: "TBM646870798009", description: "Cliente registra paquete en locker origen.", locker: "Nuevo Sur-0", status: "En el locker", date: "17 feb 2026" },
];

const statusBadgeClass: Record<string, string> = {
  "Recogida de paquete": "bg-success/10 text-success border-success/20",
  "En el locker": "bg-info/10 text-info border-info/20",
};

export default function Notifications() {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  const filtered = notificationsTableData.filter((n) =>
    n.orderNumber.includes(searchQuery) ||
    n.trackingNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    n.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-[1400px] px-4 py-6 sm:px-6 lg:px-8 lg:py-8 space-y-6">
        <div className="flex items-center gap-3 animate-fade-in">
          <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-xl font-bold font-poppins text-foreground">{t("notifications.title")}</h1>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-fade-in">
          <div className="relative w-full sm:max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder={t("notifications.searchPlaceholder")} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-9 font-inter text-sm h-10" />
          </div>
          <Button variant="outline" className="gap-2 font-inter text-xs h-10">
            {t("notifications.export")}
            <Download className="h-4 w-4" />
          </Button>
        </div>

        <div className="rounded-xl border border-border bg-card overflow-hidden animate-slide-up opacity-0" style={{ boxShadow: "var(--shadow-card)", animationDelay: "100ms", animationFillMode: "forwards" }}>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("notifications.orderNumber")}</TableHead>
                <TableHead>{t("notifications.trackingNumber")}</TableHead>
                <TableHead>{t("notifications.description")}</TableHead>
                <TableHead>{t("notifications.locker")}</TableHead>
                <TableHead>{t("notifications.status")}</TableHead>
                <TableHead>{t("notifications.date")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((notif) => (
                <TableRow key={notif.id}>
                  <TableCell className="font-poppins text-xs font-semibold text-foreground">{notif.orderNumber}</TableCell>
                  <TableCell className="font-poppins text-xs text-foreground">{notif.trackingNumber}</TableCell>
                  <TableCell className="font-inter text-xs text-muted-foreground max-w-[300px] truncate">{notif.description}</TableCell>
                  <TableCell className="font-inter text-xs text-foreground">{notif.locker}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={`text-[11px] font-inter whitespace-nowrap ${statusBadgeClass[notif.status] || "bg-muted text-muted-foreground border-border"}`}>{notif.status}</Badge>
                  </TableCell>
                  <TableCell className="font-inter text-xs text-muted-foreground whitespace-nowrap">{notif.date}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </DashboardLayout>
  );
}
