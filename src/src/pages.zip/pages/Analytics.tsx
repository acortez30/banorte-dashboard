// src/pages/Analytics.tsx

import { useMemo, useState } from "react";
import { startOfYear } from "date-fns";
import type { DateRange } from "react-day-picker";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { DateRangePicker } from "@/components/dashboard/DateRangePicker";
import { DonutChart } from "@/components/dashboard/DonutChart";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { KpiGrid } from "@/components/dashboard/KpiGrid";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import { useAnalytics } from "@/hooks/useAnalytics";
import { useLanguage } from "@/contexts/LanguageContext";

/* =========================================================
   BANORTE BRANDING
   ========================================================= */

const BANORTE_RED = "#EB0029";
const BANORTE_WINE = "#9B001B";
const BANORTE_DARK_WINE = "#690014";
const BANORTE_CORAL = "#F34A61";
const BANORTE_ROSE = "#FF8B9C";
const BANORTE_GRAPHITE = "#53565A";

const BANORTE_CHART_COLORS = [
  BANORTE_RED,
  BANORTE_WINE,
  BANORTE_CORAL,
  BANORTE_GRAPHITE,
  BANORTE_ROSE,
  BANORTE_DARK_WINE,
];

/* =========================================================
   SKELETONS
   ========================================================= */

function ChartSkeleton({
  className = "",
}: {
  className?: string;
}) {
  return (
    <div className={`metric-card animate-pulse ${className}`}>
      <div className="mb-4 h-3 w-36 rounded-full bg-muted" />
      <div className="h-[220px] rounded-xl bg-muted/40" />
    </div>
  );
}

function LockerSkeleton() {
  return (
    <div className="metric-card animate-pulse">
      <div className="mb-5 h-3 w-32 rounded-full bg-muted" />

      <div className="space-y-4">
        {[...Array(3)].map((_, index) => (
          <div
            key={index}
            className="flex items-center gap-4"
          >
            <div className="h-3 w-4 rounded-full bg-muted" />

            <div className="flex-1 space-y-1.5">
              <div className="flex justify-between">
                <div className="h-3 w-32 rounded-full bg-muted" />
                <div className="h-3 w-10 rounded-full bg-muted" />
              </div>

              <div className="h-2 rounded-full bg-muted" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* =========================================================
   EMPTY STATE
   ========================================================= */

function EmptyChart({
  message,
}: {
  message: string;
}) {
  return (
    <div className="flex h-full min-h-[180px] items-center justify-center">
      <p className="font-inter text-xs text-muted-foreground">
        {message}
      </p>
    </div>
  );
}

/* =========================================================
   COMPONENT
   ========================================================= */

export default function Analytics() {
  const { t } = useLanguage();

  const [range, setRange] = useState<DateRange | undefined>({
    from: startOfYear(new Date()),
    to: new Date(),
  });

  const { data, loading } = useAnalytics(range);

  /* ---------------------------------------------------------
     KPIs
     --------------------------------------------------------- */

  const stats = useMemo(() => {
    if (!data?.kpis?.length) {
      return [];
    }

    return data.kpis.map((kpi) => ({
      key: kpi.key,
      title: t(kpi.title),
      tooltip: t(kpi.tooltip),
      value: kpi.value,
    }));
  }, [data?.kpis, t]);

  /* ---------------------------------------------------------
     DELIVERY TREND
     --------------------------------------------------------- */

  const trendData = data?.trend ?? [];

  /* ---------------------------------------------------------
     CARRIER DISTRIBUTION
     Fuerza paleta Banorte cuando backend no envía color.
     --------------------------------------------------------- */

const donutData = useMemo(() => {
  const source = data?.carrierDistribution ?? [];

  return source.map((item, index) => ({
    ...item,

    // Branding Banorte:
    // ignoramos completamente el color que mande backend.
    color:
      BANORTE_CHART_COLORS[
        index % BANORTE_CHART_COLORS.length
      ],
  }));
}, [data?.carrierDistribution]);

  /* ---------------------------------------------------------
     TOP LOCKERS
     --------------------------------------------------------- */

  const topLockers = data?.topLockers ?? [];

  if (loading) {
    return (
      <DashboardLayout>
        <LoadingSpinner
          fullPage
          text={t("common.loading")}
        />
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* HEADER */}
        <div className="flex items-center justify-between animate-fade-in">
          <div>
            <h1 className="font-poppins text-xl font-semibold text-foreground sm:text-2xl">
              {t("analytics.title")}
            </h1>

            <p className="mt-0.5 font-inter text-sm text-muted-foreground">
              {t("analytics.subtitle")}
            </p>
          </div>

          <DateRangePicker
            value={range}
            onChange={setRange}
          />
        </div>

        {/* KPIs */}
        <KpiGrid columns={4}>
          {stats.map((stat) => (
            <KpiCard
              key={stat.key}
              title={stat.title}
              value={stat.value}
              tooltip={stat.tooltip}
            />
          ))}
        </KpiGrid>

        {/* CHARTS */}
        {loading ? (
          <div className="grid gap-4 lg:grid-cols-3 lg:gap-5">
            <ChartSkeleton className="lg:col-span-2" />
            <ChartSkeleton />
          </div>
        ) : (
          <div className="grid gap-4 lg:grid-cols-3 lg:gap-5">
            {/* DELIVERY TREND */}
            <div
              className="metric-card lg:col-span-2 animate-slide-up opacity-0"
              style={{
                animationDelay: "350ms",
                animationFillMode: "forwards",
              }}
            >
              <div className="mb-4 flex items-center justify-between gap-3">
                <h3 className="font-poppins text-sm font-semibold text-foreground">
                  {t("analytics.deliveryTrend")}
                </h3>

                <span
                  className="h-2.5 w-2.5 rounded-full"
                  style={{ backgroundColor: BANORTE_RED }}
                  aria-hidden="true"
                />
              </div>

              <div className="h-[250px]">
                {trendData.length > 0 ? (
                  <ResponsiveContainer
                    width="100%"
                    height="100%"
                  >
                    <AreaChart data={trendData}>
                      <XAxis
                        dataKey="name"
                        tick={{
                          fontSize: 11,
                          fill: "hsl(var(--muted-foreground))",
                        }}
                        tickLine={false}
                        axisLine={false}
                      />

                      <YAxis
                        tick={{
                          fontSize: 11,
                          fill: "hsl(var(--muted-foreground))",
                        }}
                        tickLine={false}
                        axisLine={false}
                        width={35}
                        allowDecimals={false}
                      />

                      <Tooltip
                        formatter={(value: number) => [
                          value,
                          t("analytics.deliveries") ||
                            "Entregas",
                        ]}
                        labelFormatter={(label) => label}
                        contentStyle={{
                          borderRadius: 12,
                          border:
                            "1px solid hsl(var(--border))",
                          background:
                            "hsl(var(--popover))",
                          color:
                            "hsl(var(--popover-foreground))",
                          boxShadow:
                            "0 10px 25px rgba(0,0,0,.08)",
                        }}
                        itemStyle={{
                          color: BANORTE_RED,
                          fontWeight: 600,
                        }}
                        cursor={{
                          stroke: BANORTE_RED,
                          strokeOpacity: 0.16,
                        }}
                      />

                      <defs>
                        <linearGradient
                          id="banorteAreaGradient"
                          x1="0"
                          y1="0"
                          x2="0"
                          y2="1"
                        >
                          <stop
                            offset="0%"
                            stopColor={BANORTE_RED}
                            stopOpacity={0.30}
                          />
                          <stop
                            offset="55%"
                            stopColor={BANORTE_RED}
                            stopOpacity={0.10}
                          />
                          <stop
                            offset="100%"
                            stopColor={BANORTE_RED}
                            stopOpacity={0}
                          />
                        </linearGradient>
                      </defs>

                      <Area
                        type="monotone"
                        dataKey="value"
                        stroke={BANORTE_RED}
                        strokeWidth={2.5}
                        fill="url(#banorteAreaGradient)"
                        dot={{
                          r: 4,
                          fill: BANORTE_RED,
                          stroke: "#FFFFFF",
                          strokeWidth: 2,
                        }}
                        activeDot={{
                          r: 6,
                          fill: BANORTE_RED,
                          stroke: "#FFFFFF",
                          strokeWidth: 2,
                        }}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : (
                  <EmptyChart message="Sin datos para el período seleccionado" />
                )}
              </div>
            </div>

            {/* CARRIER DISTRIBUTION */}
            <div
              className="metric-card animate-slide-up opacity-0"
              style={{
                animationDelay: "450ms",
                animationFillMode: "forwards",
              }}
            >
              <h3 className="mb-4 font-poppins text-sm font-semibold text-foreground">
                {t("analytics.carrierDistribution")}
              </h3>

              {donutData.length > 0 ? (
                <div className="space-y-4">
                  <DonutChart data={donutData} />

                  <div className="flex flex-wrap justify-center gap-3 border-t border-border/40 pt-3">
                    {donutData.map((item) => (
                      <div
                        key={item.name}
                        className="flex items-center gap-1.5 text-xs"
                      >
                        <div
                          className="h-2.5 w-2.5 rounded-full ring-1 ring-black/5"
                          style={{
                            backgroundColor: item.color,
                          }}
                        />

                        <span className="font-inter text-muted-foreground">
                          {item.name}
                        </span>

                        <span className="font-semibold text-foreground">
                          {item.value}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <EmptyChart message="Sin datos para el período seleccionado" />
              )}
            </div>
          </div>
        )}

        {/* TOP LOCKERS */}
        {loading ? (
          <LockerSkeleton />
        ) : (
          <div
            className="metric-card animate-slide-up opacity-0"
            style={{
              animationDelay: "550ms",
              animationFillMode: "forwards",
            }}
          >
            <h3 className="mb-5 font-poppins text-sm font-semibold text-foreground">
              {t("analytics.topLockers")}
            </h3>

            {topLockers.length > 0 ? (
              <div className="space-y-4">
                {topLockers.map((locker, index) => (
                  <div
                    key={locker.id_locker}
                    className="flex items-center gap-4"
                  >
                    <span className="w-5 text-right font-poppins text-xs font-semibold text-muted-foreground">
                      {index + 1}
                    </span>

                    <div className="flex-1">
                      <div className="mb-1.5 flex items-center justify-between">
                        <p className="font-inter text-sm font-semibold text-foreground">
                          {locker.name}
                        </p>

                        <p className="font-poppins text-sm font-semibold text-foreground">
                          {locker.count.toLocaleString()}
                        </p>
                      </div>

                      <div className="h-2 overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-primary transition-all duration-500"
                          style={{
                            width: `${locker.percentage}%`,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyChart message="Sin datos para el período seleccionado" />
            )}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
