import { useCallback, useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { format, parseISO, subMonths, startOfMonth, endOfMonth } from "date-fns";
import { es } from "date-fns/locale";
import { ChevronLeft, MapPin } from "lucide-react";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { GenericTable } from "@/components/ui/GenericTable";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import type { Column } from "@/components/ui/types";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  ordersService,
  type PackageStatusFilter,
} from "@/services/orders.service";
import { cn } from "@/lib/utils";
import type { OrderCompartment } from "@/types/orders.types";

/* ─── types ─── */
interface Order {
  tracking_number: string;
  locker_name: string;
  name_service: string;
  email: string;
  door_number: string | number;
  status_name: string;
  package_delivery_date: string;
  package_pickup_date: string;
  code_service: string;
  otp: string;
  compartment_name: string;
  registration_date: string;
  update_date: string;
  id_status_code_package: number;
  status_package: number;
  name_status_package: string;
  compartments?: OrderCompartment[];
}

interface CompanyData {
  id_company: number;
  id_propierty: number;
  name_propierty: string;
  address?: string;
  company_name?: string;
}

type TabKey =
  | "all"
  | "process"
  | "expired"
  | "scheduled"
  | "completed"
  | "canceled";

interface PaginationMeta {
  total: number;
  totalPages: number;
}

const STATUS_FILTER_BY_TAB: Partial<Record<TabKey, PackageStatusFilter>> = {
  process: "in_progress",
  expired: "expired",
  completed: "completed",
};

const SERVER_FILTERED_TABS = new Set<TabKey>([
  "all",
  "process",
  "expired",
  "completed",
]);

const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];

const formatDate = (dateStr: string) => {
  if (!dateStr) return "—";

  try {
    return format(parseISO(dateStr), "dd MMM yyyy, HH:mm", { locale: es });
  } catch {
    return dateStr;
  }
};

const STATUS_STYLES: Record<string, string> = {
  ENTREGADO: "bg-success/10 text-success border-success/20",
  RECOLECTADO: "bg-success/10 text-success border-success/20",
  ASIGNADO: "bg-info/10 text-info border-info/20",
  VENCIDO: "bg-destructive/10 text-destructive border-destructive/20",
  CANCELADO: "bg-muted text-muted-foreground border-border",
  AGENDADO: "bg-warning/10 text-warning border-warning/20",
};

function normalizeArray(value: unknown): Order[] {
  return Array.isArray(value) ? (value as Order[]) : [];
}

function readPaginationMeta(
  response: any,
  fallbackLength: number,
  pageSize: number,
): PaginationMeta {
  const rawTotal =
    response?.total ??
    response?.pagination?.total ??
    response?.result?.total ??
    response?.meta?.total;

  const parsedTotal = Number(rawTotal);
  const total = Number.isFinite(parsedTotal)
    ? Math.max(0, parsedTotal)
    : fallbackLength;

  const rawTotalPages =
    response?.total_pages ??
    response?.pagination?.total_pages ??
    response?.pagination?.totalPages ??
    response?.result?.total_pages ??
    response?.meta?.total_pages;

  const parsedTotalPages = Number(rawTotalPages);
  const totalPages = Number.isFinite(parsedTotalPages) && parsedTotalPages > 0
    ? parsedTotalPages
    : Math.max(1, Math.ceil(total / Math.max(1, pageSize)));

  return { total, totalPages };
}

const getCompartments = (order: Order): OrderCompartment[] => {
  if (Array.isArray(order.compartments) && order.compartments.length > 0) {
    return order.compartments;
  }

  if (
    order.door_number === null ||
    order.door_number === undefined ||
    order.door_number === ""
  ) {
    return [];
  }

  return [
    {
      id_locker_dimension: null,
      id_compartment_dimension: null,
      door_number: String(order.door_number),
      position: "---",
      compartment_name: order.compartment_name || "---",
      compartment_size: "---",
    },
  ];
};

function CompartmentsCell({ order }: { order: Order }) {
  const compartments = getCompartments(order);

  if (compartments.length === 0) {
    return <span className="text-sm">—</span>;
  }

  return (
    <div className="flex min-w-[150px] flex-wrap gap-1.5">
      {compartments.map((compartment, index) => (
        <span
          key={
            compartment.id_locker_dimension ??
            `${compartment.door_number}-${index}`
          }
          className="rounded-md border border-border bg-muted/40 px-2 py-1 text-[11px]"
          title={[
            compartment.position,
            compartment.compartment_name,
            compartment.compartment_size,
          ]
            .filter((value) => value && value !== "---")
            .join(" · ")}
        >
          #{compartment.door_number}
          {compartment.position && compartment.position !== "---"
            ? ` · ${compartment.position}`
            : ""}
        </span>
      ))}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const key = status?.toUpperCase();

  return (
    <Badge
      className={cn(
        "text-[10px]",
        STATUS_STYLES[key] || "bg-muted text-muted-foreground",
      )}
    >
      {status || "—"}
    </Badge>
  );
}

export default function PackagePropertyPage() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();

  const companyData: CompanyData | undefined = location.state?.companyData;

  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<TabKey>("all");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [tabTotals, setTabTotals] = useState<Partial<Record<TabKey, number>>>({});

  const { defaultStart, defaultEnd } = useMemo(() => {
    const now = new Date();

    return {
      defaultStart: startOfMonth(subMonths(now, 3)).getTime(),
      defaultEnd: endOfMonth(now).getTime(),
    };
  }, []);

  const language = (localStorage.getItem("lang") || "es").toLowerCase();

  const getBaseParams = useCallback(
    () => ({
      language,
      id_company: companyData?.id_company,
      date_start: defaultStart,
      date_end: defaultEnd,
    }),
    [companyData?.id_company, defaultEnd, defaultStart, language],
  );

  const requestTab = useCallback(
    async (tab: TabKey, requestedPage: number, requestedLimit: number) => {
      const baseParams = getBaseParams();

      if (SERVER_FILTERED_TABS.has(tab)) {
        return ordersService.getOrders({
          ...baseParams,
          page: requestedPage,
          limit: requestedLimit,
          status_filter: STATUS_FILTER_BY_TAB[tab],
        });
      }

      if (tab === "scheduled") {
        return ordersService.getScheduled(baseParams);
      }

      return ordersService.getCancelPackage(baseParams);
    },
    [getBaseParams],
  );

  useEffect(() => {
    setPage(1);
  }, [activeTab]);

  useEffect(() => {
    if (!companyData?.id_company) return;

    let cancelled = false;

    const fetchOrders = async () => {
      try {
        setLoading(true);

        const response: any = await requestTab(activeTab, page, pageSize);

        if (cancelled) return;

        const code = Number(response?.mensaje_return?.CODE);
        const isEmptyResponse = code === 1103;
        const result = isEmptyResponse
          ? []
          : normalizeArray(response?.return_result);

        const pagination = readPaginationMeta(response, result.length, pageSize);

        setOrders(result);
        setTotal(pagination.total);
        setTotalPages(pagination.totalPages);
        setTabTotals((current) => ({
          ...current,
          [activeTab]: pagination.total,
        }));

        if (page > pagination.totalPages) {
          setPage(pagination.totalPages);
        }
      } catch (error) {
        if (cancelled) return;

        console.error(`Error loading ${activeTab} orders:`, error);
        setOrders([]);
        setTotal(0);
        setTotalPages(1);
        setTabTotals((current) => ({
          ...current,
          [activeTab]: 0,
        }));
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    void fetchOrders();

    return () => {
      cancelled = true;
    };
  }, [
    activeTab,
    companyData?.id_company,
    page,
    pageSize,
    requestTab,
  ]);

  /*
   * Precarga únicamente los totales de los cuatro tabs cubiertos por el nuevo
   * status_filter. Agendadas y Canceladas conservan sus endpoints dedicados
   * y actualizan su total cuando se consultan.
   */
  useEffect(() => {
    if (!companyData?.id_company) return;

    let cancelled = false;

    const loadServerTabTotals = async () => {
      const tabsToLoad: TabKey[] = ["all", "process", "expired", "completed"];

      const results = await Promise.allSettled(
        tabsToLoad.map(async (tab) => {
          const response: any = await requestTab(tab, 1, 1);
          const rows = normalizeArray(response?.return_result);
          const pagination = readPaginationMeta(response, rows.length, 1);

          return [tab, pagination.total] as const;
        }),
      );

      if (cancelled) return;

      setTabTotals((current) => {
        const next = { ...current };

        results.forEach((result) => {
          if (result.status === "fulfilled") {
            const [tab, tabTotal] = result.value;
            next[tab] = tabTotal;
          }
        });

        return next;
      });
    };

    void loadServerTabTotals();

    return () => {
      cancelled = true;
    };
  }, [companyData?.id_company, requestTab]);

  const tabs: { key: TabKey; label: string }[] = [
    { key: "all", label: t("packagePropertyPage.tabs.all") || "Todas" },
    {
      key: "process",
      label: t("packagePropertyPage.tabs.process") || "En Proceso",
    },
    {
      key: "expired",
      label: t("packagePropertyPage.tabs.expired") || "Expiradas",
    },
    {
      key: "scheduled",
      label: t("packagePropertyPage.tabs.scheduled") || "Agendadas",
    },
    {
      key: "completed",
      label: t("packagePropertyPage.tabs.completed") || "Completadas",
    },
    {
      key: "canceled",
      label: t("packagePropertyPage.tabs.canceled") || "Canceladas",
    },
  ];

  const generalColumns: Column<Order>[] = [
    {
      key: "tracking_number",
      header: t("packagePropertyPage.table.tracking_number") || "Tracking",
      sortable: true,
      render: (row) => (
        <span className="text-sm font-mono text-secondary">
          {row.tracking_number || "—"}
        </span>
      ),
    },
    {
      key: "locker_name",
      header: t("packagePropertyPage.table.locker_name") || "Locker",
      sortable: true,
      render: (row) => <span className="text-sm">{row.locker_name || "—"}</span>,
    },
    {
      key: "name_service",
      header: t("packagePropertyPage.table.name_service") || "Servicio",
      sortable: true,
      render: (row) => <span className="text-sm">{row.name_service || "—"}</span>,
    },
    {
      key: "email",
      header: t("packagePropertyPage.table.email") || "Email",
      sortable: true,
      render: (row) => (
        <span className="block max-w-[220px] truncate text-sm text-muted-foreground">
          {row.email || "—"}
        </span>
      ),
    },
    {
      key: "door_number",
      header: t("packagePropertyPage.table.door_number") || "Puerta",
      sortable: true,
      render: (row) => <CompartmentsCell order={row} />,
    },
    {
      key: "status_name",
      header: t("packagePropertyPage.table.status_name") || "Estatus",
      sortable: true,
      render: (row) => <StatusBadge status={row.status_name} />,
    },
    {
      key: "package_delivery_date",
      header:
        t("packagePropertyPage.table.package_delivery_date") || "Entrega",
      sortable: true,
      render: (row) => (
        <span className="text-sm text-muted-foreground">
          {formatDate(row.package_delivery_date)}
        </span>
      ),
    },
    {
      key: "package_pickup_date",
      header:
        t("packagePropertyPage.table.package_pickup_date") || "Recolección",
      sortable: true,
      render: (row) => (
        <span className="text-sm text-muted-foreground">
          {formatDate(row.package_pickup_date)}
        </span>
      ),
    },
  ];

  const scheduledColumns: Column<Order>[] = [
    {
      key: "code_service",
      header: t("packagePropertyPage.table.code_service") || "Código",
      sortable: true,
      render: (row) => (
        <span className="text-sm font-mono">{row.code_service || "—"}</span>
      ),
    },
    {
      key: "otp",
      header: t("packagePropertyPage.table.otp") || "OTP",
      sortable: false,
      render: (row) => <span className="text-sm font-mono">{row.otp || "—"}</span>,
    },
    {
      key: "name_service",
      header: t("packagePropertyPage.table.name_service") || "Servicio",
      sortable: true,
      render: (row) => <span className="text-sm">{row.name_service || "—"}</span>,
    },
    {
      key: "email",
      header: t("packagePropertyPage.table.email") || "Email",
      sortable: true,
      render: (row) => (
        <span className="text-sm text-muted-foreground">{row.email || "—"}</span>
      ),
    },
    {
      key: "door_number",
      header: t("packagePropertyPage.table.door_number") || "Puertas",
      sortable: true,
      render: (row) => <CompartmentsCell order={row} />,
    },
    {
      key: "compartment_name",
      header:
        t("packagePropertyPage.table.compartment_name") || "Compartimento",
      sortable: true,
      render: (row) => (
        <span className="text-sm">{row.compartment_name || "—"}</span>
      ),
    },
    {
      key: "status_name",
      header: t("packagePropertyPage.table.status_name") || "Estatus",
      sortable: true,
      render: (row) => <StatusBadge status={row.status_name} />,
    },
    {
      key: "registration_date",
      header: t("packagePropertyPage.table.registration_date") || "Registro",
      sortable: true,
      render: (row) => (
        <span className="text-sm text-muted-foreground">
          {formatDate(row.registration_date)}
        </span>
      ),
    },
  ];

  const canceledColumns: Column<Order>[] = [
    {
      key: "code_service",
      header: t("packagePropertyPage.table.code_service") || "Código",
      sortable: true,
      render: (row) => (
        <span className="text-sm font-mono">{row.code_service || "—"}</span>
      ),
    },
    {
      key: "name_service",
      header: t("packagePropertyPage.table.name_service") || "Servicio",
      sortable: true,
      render: (row) => <span className="text-sm">{row.name_service || "—"}</span>,
    },
    {
      key: "door_number",
      header: t("packagePropertyPage.table.door_number") || "Puertas",
      sortable: true,
      render: (row) => <CompartmentsCell order={row} />,
    },
    {
      key: "status_name",
      header: t("packagePropertyPage.table.status_name") || "Estatus",
      sortable: true,
      render: (row) => <StatusBadge status={row.status_name} />,
    },
    {
      key: "update_date",
      header:
        t("packagePropertyPage.table.update_date") || "Actualización",
      sortable: true,
      render: (row) => (
        <span className="text-sm text-muted-foreground">
          {formatDate(row.update_date)}
        </span>
      ),
    },
  ];

  const activeColumns =
    activeTab === "scheduled"
      ? scheduledColumns
      : activeTab === "canceled"
        ? canceledColumns
        : generalColumns;

  const getTabTotalLabel = (tab: TabKey) => {
    const value = tabTotals[tab];
    return value === undefined ? "—" : String(value);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => navigate(`/company/${companyData?.id_company}`)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>

          <div>
            <div className="mb-0.5 flex items-center gap-1 text-xs text-muted-foreground">
              <span
                className="cursor-pointer transition-colors hover:text-foreground"
                onClick={() => navigate("/company")}
              >
                {t("unitsPage.breadcrumb.company") || "Compañía"}
              </span>
              <span>/</span>
              <span
                className="cursor-pointer transition-colors hover:text-foreground"
                onClick={() => navigate(`/company/${companyData?.id_company}`)}
              >
                {companyData?.name_propierty}
              </span>
              <span>/</span>
              <span className="text-foreground">
                {t("packagePropertyPage.title") || "Órdenes de la propiedad"}
              </span>
            </div>
            <h1 className="font-poppins text-xl font-bold">
              {t("packagePropertyPage.title") || "Órdenes de la propiedad"}
            </h1>
          </div>
        </div>

        <div className="flex flex-col items-start gap-4 lg:flex-row">
          <div className="w-full min-w-0 space-y-4 lg:flex-1">
            <Tabs
              value={activeTab}
              onValueChange={(value) => setActiveTab(value as TabKey)}
              className="w-full"
            >
              <div className="w-full overflow-x-auto pb-1">
                <TabsList className="h-auto min-w-max justify-start rounded-xl bg-muted p-1">
                  {tabs.map((tab) => (
                    <TabsTrigger
                      key={tab.key}
                      value={tab.key}
                      className="gap-1.5 rounded-lg px-3 py-1.5 text-xs data-[state=active]:bg-card"
                    >
                      <span>{tab.label}</span>

                      <span
                        className={cn(
                          "rounded-full px-1.5 py-0.5 text-[10px] font-semibold transition-colors",
                          activeTab === tab.key
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted-foreground/20 text-muted-foreground",
                        )}
                      >
                        {getTabTotalLabel(tab.key)}
                      </span>
                    </TabsTrigger>
                  ))}
                </TabsList>
              </div>

              {tabs.map((tab) => (
                <TabsContent
                  key={tab.key}
                  value={tab.key}
                  className="mt-4"
                >
                  {activeTab === tab.key && (
                    <GenericTable<Order>
                      key={tab.key}
                      data={orders}
                      columns={activeColumns}
                      loading={loading}
                      enableSearch
                      enableDateRange={false}
                      searchFields={[
                        "tracking_number",
                        "email",
                        "locker_name",
                        "status_name",
                        "code_service",
                      ]}
                      defaultSort={{
                        key: "package_delivery_date",
                        direction: "desc",
                      }}
                      pageSizeOptions={PAGE_SIZE_OPTIONS}
                      serverPagination={
                        SERVER_FILTERED_TABS.has(activeTab)
                          ? {
                              page,
                              pageSize,
                              total,
                              totalPages,
                              onPageChange: setPage,
                              onPageSizeChange: (nextPageSize) => {
                                setPageSize(nextPageSize);
                                setPage(1);
                              },
                            }
                          : undefined
                      }
                    />
                  )}
                </TabsContent>
              ))}
            </Tabs>
          </div>

          {companyData && (
            <div className="w-full shrink-0 lg:w-[280px]">
              <div className="metric-card space-y-4">
                <p className="font-poppins text-[13px] font-semibold text-foreground">
                  {t("residentsPage.companyInfo") || "Información de propiedad"}
                </p>

                <div className="space-y-3 text-sm">
                  <div>
                    <p className="mb-0.5 text-xs text-muted-foreground">
                      {t("companyDetailPage.tableProperty.name_propierty") ||
                        "Propiedad"}
                    </p>
                    <p className="font-medium text-foreground">
                      {companyData.name_propierty}
                    </p>
                  </div>

                  {companyData.address && (
                    <div>
                      <p className="mb-0.5 text-xs text-muted-foreground">
                        {t("companyPage.table.address") || "Dirección"}
                      </p>
                      <div className="flex items-start gap-1.5">
                        <MapPin className="mt-0.5 h-3 w-3 shrink-0 text-muted-foreground" />
                        <p className="text-xs leading-relaxed text-muted-foreground">
                          {companyData.address}
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="space-y-2 border-t border-border pt-3">
                    {tabs
                      .filter((tab) => tab.key !== "all")
                      .map((tab) => (
                        <div
                          key={tab.key}
                          className="flex items-center justify-between"
                        >
                          <span className="text-xs text-muted-foreground">
                            {tab.label}
                          </span>
                          <span
                            className={cn(
                              "text-xs font-semibold",
                              activeTab === tab.key
                                ? "text-secondary"
                                : "text-foreground",
                            )}
                          >
                            {getTabTotalLabel(tab.key)}
                          </span>
                        </div>
                      ))}

                    <div className="flex items-center justify-between border-t border-border pt-1">
                      <span className="text-xs font-medium text-foreground">
                        {t("packagePropertyPage.tabs.all") || "Total"}
                      </span>
                      <span className="text-sm font-bold text-secondary">
                        {getTabTotalLabel("all")}
                      </span>
                    </div>
                  </div>
                </div>

                <Button
                  size="sm"
                  variant="outline"
                  className="w-full text-xs"
                  onClick={() => navigate(`/company/${companyData.id_company}`)}
                >
                  {t("common.viewDetail") || "Ver propiedad"}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}