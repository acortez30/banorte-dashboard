// src/pages/AddServicePage.tsx
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ChevronLeft, Plus, Save, MapPin, Building2, Trash2, Edit2 } from "lucide-react";
import { companyService } from "@/services/company.service";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Column } from "@/components/ui/types";
import { GenericTable } from "@/components/ui/GenericTable";
import SelectableMap from "@/components/ui/Selectablemap";

// Tipos
interface ServiceForm {
  name_propierty_unit: string;
  id_line_service: string;
  line_service: string;
  address: string;
  latitude: string;
  longitude: string;
  id_state: string;
  state: string;
  id_city: string;
  city: string;
  id_status: number;
  lockers?: LockerAssignment[];
  app?: boolean;
}

interface LockerAssignment {
  id_locker: number;
  id_status: number;
}

interface StateOption {
  id: number;
  name: string;
}

interface CityOption {
  id: number;
  name: string;
}

interface ServiceOption {
  id: number;
  name: string;
}

interface LockerOption {
  id: number;
  name: string;
}

interface StagingService extends ServiceForm {
  _index: number;
  locker_names?: string;
}

const INITIAL_FORM: ServiceForm = {
  name_propierty_unit: "",
  id_line_service: "",
  line_service: "",
  address: "",
  latitude: "",
  longitude: "",
  id_state: "",
  state: "",
  id_city: "",
  city: "",
  id_status: 1,
  lockers: [],
  app: false,
};

// Componente Field reutilizable
function Field({ label, value, onChange, placeholder, required, type = "text", maxLength, error, disabled, icon }: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  required?: boolean;
  type?: string;
  maxLength?: number;
  error?: string;
  disabled?: boolean;
  icon?: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5 w-full">
      <Label className="text-xs font-medium text-foreground">
        {label}{required && <span className="text-destructive ml-0.5">*</span>}
      </Label>
      <div className="relative">
        {icon && (
          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none text-muted-foreground">
            {icon}
          </span>
        )}
        <Input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          maxLength={maxLength}
          disabled={disabled}
          className={`${icon ? "pl-8" : ""} ${error ? "border-destructive" : ""}`}
        />
      </div>
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}

// Componente MultiSelect
function MultiSelectDropdown({ 
  items, 
  title, 
  placeholder, 
  selectedItems, 
  onItemsSelected,
  required,
  disabled 
}: { 
  items: LockerOption[];
  title: string;
  placeholder: string;
  selectedItems: LockerOption[];
  onItemsSelected: (items: LockerOption[]) => void;
  required?: boolean;
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);

  const toggleItem = (item: LockerOption) => {
    const exists = selectedItems.some(i => i.id === item.id);
    if (exists) {
      onItemsSelected(selectedItems.filter(i => i.id !== item.id));
    } else {
      onItemsSelected([...selectedItems, item]);
    }
  };

  return (
    <div className="space-y-1.5 w-full">
      <Label className="text-xs font-medium text-foreground">
        {title}{required && <span className="text-destructive ml-0.5">*</span>}
      </Label>
      <div className="relative">
        <button
          type="button"
          onClick={() => setOpen(!open)}
          disabled={disabled}
          className="w-full flex items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <span className="truncate">
            {selectedItems.length > 0 
              ? `${selectedItems.length} seleccionados` 
              : placeholder}
          </span>
          <span className="ml-2">▼</span>
        </button>
        
        {open && (
          <div className="absolute z-50 mt-1 w-full rounded-md border border-border bg-popover shadow-md">
            <div className="max-h-60 overflow-auto p-1">
              {items.map((item) => (
                <label
                  key={item.id}
                  className="flex items-center gap-2 px-3 py-2 hover:bg-muted cursor-pointer rounded-sm"
                >
                  <input
                    type="checkbox"
                    checked={selectedItems.some(i => i.id === item.id)}
                    onChange={() => toggleItem(item)}
                    className="h-4 w-4 rounded border-gray-300"
                  />
                  <span className="text-sm">{item.name}</span>
                </label>
              ))}
            </div>
            <div className="border-t border-border p-2 flex justify-end">
              <Button size="sm" variant="ghost" onClick={() => setOpen(false)}>
                Cerrar
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function AddServicePage() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { id_company, id_property } = useParams<{ id_company: string; id_property: string }>();

  const [form, setForm] = useState<ServiceForm>(INITIAL_FORM);
  const [errors, setErrors] = useState<Partial<Record<keyof ServiceForm, string>>>({});
  const [staging, setStaging] = useState<ServiceForm[]>([]);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // Opciones para selects
  const [states, setStates] = useState<StateOption[]>([]);
  const [cities, setCities] = useState<CityOption[]>([]);
  const [services, setServices] = useState<ServiceOption[]>([]);
  const [lockers, setLockers] = useState<LockerOption[]>([]);
  const [selectedLockers, setSelectedLockers] = useState<LockerOption[]>([]);
  
  // Estados de carga
  const [loadingCities, setLoadingCities] = useState(false);
  const [companyName, setCompanyName] = useState("");
  const [propertyName, setPropertyName] = useState("");
  const [propertyLat, setPropertyLat] = useState<number | undefined>(undefined);
  const [propertyLng, setPropertyLng] = useState<number | undefined>(undefined);
  const [isLockerService, setIsLockerService] = useState(false);

  const idUserType = user?.id_user_type ?? user?.data_company?.id_user_type;

  // Cargar datos iniciales
  useEffect(() => {
    if (!id_company || !id_property) {
      toast.error("ID de compañía o propiedad no encontrado");
      navigate("/company");
      return;
    }
    
    loadInitialData();
    loadPropertyData();
    loadCompanyData();
  }, [id_company, id_property]);

  const loadInitialData = async () => {
    try {
      setLoading(true);
      
      // Cargar estados
      const statesRes: any = await companyService.getStates();
      if (statesRes?.cities) {
        setStates(statesRes.cities.map((s: any) => ({ id: s.id_state, name: s.state_name })));
      }
      
      // Cargar servicios
      const servicesRes: any = await companyService.getLineServices();
      if (servicesRes?.service_lines) {
        setServices(servicesRes.service_lines.map((s: any) => ({ 
          id: s.id_line_service, 
          name: s.nombre 
        })));
      }
      
      // Cargar lockers
      const lockersRes: any = await companyService.getLockersAvailables();
      if (lockersRes?.lockers) {
        setLockers(lockersRes.lockers.map((l: any) => ({ 
          id: l.id_locker, 
          name: l.locker_name 
        })));
      }
    } catch (error) {
      console.error("Error loading initial data:", error);
      toast.error("Error al cargar datos iniciales");
    } finally {
      setLoading(false);
    }
  };

  const loadPropertyData = async () => {
    try {
      const res: any = await companyService.getPropertiesID(Number(id_company), Number(id_property));
      if (res?.properties) {
        const prop = res.properties;
        setPropertyName(prop.name_propierty);
        setPropertyLat(parseFloat(prop.latitud));
        setPropertyLng(parseFloat(prop.longitud));
      }
    } catch (error) {
      console.error("Error loading property:", error);
    }
  };

  const loadCompanyData = async () => {
    try {
      const res: any = await companyService.getCompanyId(Number(id_company));
      if (res?.companies?.[0]) {
        setCompanyName(res.companies[0].company_name);
      }
    } catch (error) {
      console.error("Error loading company:", error);
    }
  };

  const loadCities = async (id_state: number) => {
    try {
      setLoadingCities(true);
      const res: any = await companyService.getCity(id_state);
      if (res?.cities) {
        setCities(res.cities.map((c: any) => ({ id: c.id_city, name: c.city })));
      }
    } catch (error) {
      console.error("Error loading cities:", error);
    } finally {
      setLoadingCities(false);
    }
  };

  const setField = (field: keyof ServiceForm, value: any) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const handleLocationSelect = ({ lat, lng, address }: { lat: number; lng: number; address?: string }) => {
    setField("latitude", lat.toFixed(8));
    setField("longitude", lng.toFixed(8));
    if (address) {
      setField("address", address);
    }
  };

  const handleServiceTypeChange = (serviceId: string, serviceName: string) => {
    setField("id_line_service", serviceId);
    setField("line_service", serviceName);
    
    const isLocker = Number(serviceId) === 1;
    setIsLockerService(isLocker);
    
    if (!isLocker) {
      setSelectedLockers([]);
      setField("lockers", []);
      setField("app", true);
    } else {
      setField("app", false);
    }
  };

  const handleLockersSelected = (lockers: LockerOption[]) => {
    setSelectedLockers(lockers);
    setField("lockers", lockers.map(l => ({ id_locker: l.id, id_status: 1 })));
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof ServiceForm, string>> = {};
    const requiredMsg = t("validation.required") || "Campo obligatorio";
    
    if (!form.name_propierty_unit.trim()) newErrors.name_propierty_unit = requiredMsg;
    if (!form.id_line_service) newErrors.id_line_service = requiredMsg;
    if (!form.address.trim()) newErrors.address = requiredMsg;
    if (!form.latitude.trim()) newErrors.latitude = requiredMsg;
    if (!form.longitude.trim()) newErrors.longitude = requiredMsg;
    if (!form.id_state) newErrors.id_state = requiredMsg;
    if (!form.id_city) newErrors.id_city = requiredMsg;
    
    if (isLockerService && selectedLockers.length === 0) {
      newErrors.lockers = requiredMsg;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAddToList = () => {
    if (!validateForm()) {
      toast.error(t("addServicePage.messages.fillRequired") || "Completa todos los campos requeridos");
      return;
    }
    
    setStaging((prev) => [...prev, { ...form }]);
    setForm(INITIAL_FORM);
    setSelectedLockers([]);
    setIsLockerService(false);
    setCities([]);
    toast.success(t("addServicePage.messages.addedToList") || "Servicio agregado a la lista");
  };

  const handleRemove = (index: number) => {
    setStaging((prev) => prev.filter((_, i) => i !== index));
  };

  const handleEdit = (service: ServiceForm, index: number) => {
    setForm(service);
    setStaging((prev) => prev.filter((_, i) => i !== index));
    if (service.id_state) {
      loadCities(Number(service.id_state));
    }
    const isLocker = Number(service.id_line_service) === 1;
    setIsLockerService(isLocker);
    if (isLocker && service.lockers) {
      const selected = lockers.filter(l => 
        service.lockers?.some(sl => sl.id_locker === l.id)
      );
      setSelectedLockers(selected);
    } else {
      setSelectedLockers([]);
    }
    setErrors({});
  };

  const handleSaveAll = async () => {
    if (staging.length === 0) {
      toast.error(t("addServicePage.messages.emptyList") || "Agrega al menos un servicio");
      return;
    }
    
    try {
      setSaving(true);
      
      const zones = staging.map((row) => {
        const zone: any = {
          id_line_service: Number(row.id_line_service),
          address: row.address,
          latitude: row.latitude.toString(),
          longitude: row.longitude.toString(),
          name_propierty_unit: row.name_propierty_unit,
          id_status: row.id_status,
          id_city: Number(row.id_city),
        };

        if (row.lockers && row.lockers.length > 0) {
          zone.locker = row.lockers.map((locker) => ({
            id_locker: locker.id_locker,
            id_status: locker.id_status,
          }));
        }

        if (row.app) {
          zone.app = true;
        }

        return zone;
      });
      
      const response: any = await companyService.postLineService(
        { zones },
        Number(id_property)
      );
      
      if (response?.result?.mensaje_return?.CODE === 200) {
        toast.success(t("addServicePage.messages.savedSuccess") || "Servicios guardados correctamente");
        navigate(`/company/${id_company}/property/${id_property}`);
      } else {
        toast.error(t("common.unexpectedError") || "Error inesperado al guardar");
      }
    } catch (error) {
      console.error("Error saving services:", error);
      toast.error(t("common.errorSaving") || "Error al guardar los servicios");
    } finally {
      setSaving(false);
    }
  };

  // Columnas para la tabla de staging
  const stagingColumns: Column<StagingService>[] = [
    {
      key: "name_propierty_unit",
      header: t("companyPage.branchTable.name_propierty") || "Nombre",
      sortable: true,
      render: (row) => <span className="font-medium text-sm">{row.name_propierty_unit}</span>
    },
    {
      key: "line_service",
      header: t("companyPage.branchTable.line_service") || "Servicio",
      sortable: true,
      render: (row) => <span className="text-sm">{row.line_service}</span>
    },
    {
      key: "address",
      header: t("companyPage.branchTable.address") || "Dirección",
      sortable: false,
      render: (row) => <span className="text-sm text-muted-foreground truncate max-w-[300px] block">{row.address}</span>
    },
    {
      key: "city",
      header: t("companyPage.branchTable.city") || "Ciudad",
      sortable: true,
      render: (row) => <span className="text-sm">{row.city}</span>
    },
    {
      key: "state",
      header: t("companyPage.branchTable.state") || "Estado",
      sortable: true,
      render: (row) => <span className="text-sm">{row.state}</span>
    },
    {
      key: "locker_names",
      header: t("addServicePage.table.lockers") || "Lockers",
      sortable: false,
      render: (row) => {
        if (row.lockers && row.lockers.length > 0) {
          const lockerNames = row.lockers
            .map(l => lockers.find(lk => lk.id === l.id_locker)?.name)
            .filter(Boolean)
            .join(", ");
          return <span className="text-xs text-muted-foreground">{lockerNames}</span>;
        }
        return <span className="text-xs text-muted-foreground">—</span>;
      }
    },
    {
      key: "actions",
      header: t("companyPage.table.accion") || "Acciones",
      sortable: false,
      render: (row) => (
        <div className="flex items-center gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8 text-blue-500 hover:bg-blue-50"
            onClick={(e) => { e.stopPropagation(); handleEdit(row, row._index); }}
          >
            <Edit2 className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8 text-destructive hover:bg-destructive/10"
            onClick={(e) => { e.stopPropagation(); handleRemove(row._index); }}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ];

  const mapLat = form.latitude ? parseFloat(form.latitude) : propertyLat;
  const mapLng = form.longitude ? parseFloat(form.longitude) : propertyLng;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => navigate(`/company/${id_company}/property/${id_property}`)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          
          <div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground mb-0.5">
              {idUserType === 1 && (
                <>
                  <span 
                    className="cursor-pointer hover:text-foreground transition-colors"
                    onClick={() => navigate("/company")}
                  >
                    {t("addLineServicePage.company") || "Compañía"}
                  </span>
                  <span>/</span>
                </>
              )}
              <span 
                className="cursor-pointer hover:text-foreground transition-colors"
                onClick={() => navigate(`/company/${id_company}`)}
              >
                {companyName || "..."}
              </span>
              <span>/</span>
              <span 
                className="cursor-pointer hover:text-foreground transition-colors"
                onClick={() => navigate(`/company/${id_company}/property/${id_property}`)}
              >
                {propertyName || "..."}
              </span>
              <span>/</span>
              <span className="text-foreground">
                {t("addLineServicePage.addService") || "Agregar servicio"}
              </span>
            </div>
            <h1 className="text-xl font-bold font-poppins">
              {t("addLineServicePage.addService") || "Agregar servicio"}
            </h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {propertyName && `${t("addLineServicePage.forProperty") || "Para"}: ${propertyName}`}
            </p>
          </div>
        </div>

        {/* Formulario + Mapa */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          {/* Formulario */}
          <div className="metric-card space-y-4">
            <p className="text-[13px] font-semibold font-poppins text-foreground">
              {t("addLineServicePage.subtitle") || "Datos del servicio"}
            </p>

            {/* Fila 1: Nombre y Servicio */}
            <div className="grid grid-cols-2 gap-4">
              <Field
                label={t("addLineServicePage.forms.name_propierty_unit") || "Nombre de la unidad"}
                value={form.name_propierty_unit}
                onChange={(v) => setField("name_propierty_unit", v)}
                placeholder={t("addLineServicePage.forms.placeholder_name_propierty_unit") || "Ej: Torre A - Piso 1"}
                required
                maxLength={100}
                error={errors.name_propierty_unit}
                icon={<Building2 className="h-3.5 w-3.5" />}
              />
              
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-foreground">
                  {t("addLineServicePage.forms.id_line_service") || "Servicio"}
                  <span className="text-destructive ml-0.5">*</span>
                </Label>
                <Select
                  value={form.id_line_service}
                  onValueChange={(v) => {
                    const service = services.find(s => String(s.id) === v);
                    handleServiceTypeChange(v, service?.name || "");
                  }}
                >
                  <SelectTrigger className={errors.id_line_service ? "border-destructive" : ""}>
                    <SelectValue placeholder={t("addLineServicePage.forms.placeholder_id_line_service") || "Seleccionar servicio"} />
                  </SelectTrigger>
                  <SelectContent>
                    {services.map(s => (
                      <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.id_line_service && <p className="text-xs text-destructive">{errors.id_line_service}</p>}
              </div>
            </div>

            {/* Lockers MultiSelect - solo si es servicio tipo locker */}
            {isLockerService && (
              <MultiSelectDropdown
                items={lockers}
                title={t("addLineServicePage.forms.locker") || "Lockers"}
                placeholder={t("addLineServicePage.forms.placeholder_locker") || "Seleccionar lockers"}
                selectedItems={selectedLockers}
                onItemsSelected={handleLockersSelected}
                required
              />
            )}

            {/* Estado y Ciudad */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-foreground">
                  {t("addLineServicePage.forms.state") || "Estado"}
                  <span className="text-destructive ml-0.5">*</span>
                </Label>
                <Select
                  value={form.id_state}
                  onValueChange={(v) => {
                    const state = states.find(s => String(s.id) === v);
                    setField("id_state", v);
                    setField("state", state?.name || "");
                    loadCities(Number(v));
                    setField("id_city", "");
                    setField("city", "");
                  }}
                >
                  <SelectTrigger className={errors.id_state ? "border-destructive" : ""}>
                    <SelectValue placeholder={t("addLineServicePage.forms.placeholder_state") || "Seleccionar estado"} />
                  </SelectTrigger>
                  <SelectContent>
                    {states.map(s => (
                      <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.id_state && <p className="text-xs text-destructive">{errors.id_state}</p>}
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-foreground">
                  {t("addLineServicePage.forms.city") || "Ciudad"}
                  <span className="text-destructive ml-0.5">*</span>
                </Label>
                <Select
                  value={form.id_city}
                  disabled={!form.id_state || loadingCities}
                  onValueChange={(v) => {
                    const city = cities.find(c => String(c.id) === v);
                    setField("id_city", v);
                    setField("city", city?.name || "");
                  }}
                >
                  <SelectTrigger className={errors.id_city ? "border-destructive" : ""}>
                    <SelectValue placeholder={
                      loadingCities 
                        ? (t("common.loading") || "Cargando...")
                        : (t("addLineServicePage.forms.placeholder_city") || "Seleccionar ciudad")
                    } />
                  </SelectTrigger>
                  <SelectContent>
                    {cities.map(c => (
                      <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.id_city && <p className="text-xs text-destructive">{errors.id_city}</p>}
              </div>
            </div>

            {/* Latitud y Longitud */}
            <div className="grid grid-cols-2 gap-4">
              <Field
                label={t("companyPage.forms.branchs.latitude") || "Latitud"}
                value={form.latitude}
                onChange={(v) => setField("latitude", v)}
                placeholder="25.74682811"
                required
                error={errors.latitude}
                icon={<MapPin className="h-3.5 w-3.5" />}
              />
              <Field
                label={t("companyPage.forms.branchs.longitude") || "Longitud"}
                value={form.longitude}
                onChange={(v) => setField("longitude", v)}
                placeholder="-100.351334"
                required
                error={errors.longitude}
                icon={<MapPin className="h-3.5 w-3.5" />}
              />
            </div>

            {/* Dirección */}
            <Field
              label={t("companyPage.forms.branchs.address") || "Dirección"}
              value={form.address}
              onChange={(v) => setField("address", v)}
              placeholder={t("companyPage.forms.branchs.placeholder_address") || "Calle, número, colonia, ciudad"}
              required
              maxLength={255}
              error={errors.address}
            />

            {/* Botón agregar */}
            <div className="flex justify-end pt-2">
              <Button onClick={handleAddToList} className="gap-2">
                <Plus className="h-4 w-4" />
                {t("companyPage.buttons.save") || "Agregar a lista"}
              </Button>
            </div>
          </div>

          {/* Mapa */}
          <div className="metric-card p-0 overflow-hidden lg:sticky lg:top-6">
            <div className="px-4 py-3 border-b border-border">
              <p className="text-[13px] font-semibold font-poppins text-foreground">
                {t("companyPage.forms.branchs.selectLocationService") || "Seleccionar ubicación del servicio"}
              </p>
            </div>

            <div className="h-[520px]">
              <SelectableMap 
                lat={mapLat} 
                lng={mapLng} 
                onLocationSelect={handleLocationSelect}
              />
            </div>

            <div className="px-4 py-2 border-t border-border bg-muted/30">
              <p className="text-xs text-muted-foreground text-center">
                {t("addServicePage.map.clickMapHint") || "Haz clic en el mapa para seleccionar la ubicación del servicio"}
              </p>
            </div>
          </div>
        </div>

        {/* Tabla de servicios en staging */}
        {staging.length > 0 && (
          <div className="space-y-4">
            <p className="text-[13px] font-semibold font-poppins text-foreground">
              {t("addServicePage.table.stagingTitle") || "Servicios por guardar"}
              <span className="text-secondary ml-2">{staging.length}</span>
            </p>

            <GenericTable
              data={staging.map((service, i) => ({ ...service, _index: i }))}
              columns={stagingColumns as any}
              enableSearch={false}
              enableDateRange={false}
            />

            <div className="flex justify-end gap-3">
              <Button 
                variant="outline" 
                onClick={() => navigate(`/company/${id_company}/property/${id_property}`)} 
                disabled={saving}
              >
                {t("common.cancel") || "Cancelar"}
              </Button>
              <Button onClick={handleSaveAll} disabled={saving} className="gap-2">
                {saving ? (
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                {saving 
                  ? (t("common.saving") || "Guardando...")
                  : `${t("addServicePage.buttons.saveAll") || "Guardar"} ${staging.length} ${staging.length > 1 ? (t("addServicePage.buttons.services") || "servicios") : (t("addServicePage.buttons.service") || "servicio")}`
                }
              </Button>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}