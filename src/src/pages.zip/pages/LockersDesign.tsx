import { useEffect, useState, useCallback } from "react";
import { lockerDetailService } from "@/services/locker-detail.service";
import LockerModule from "./LockerModule";

/* =====================================================
   TYPES
===================================================== */

interface Props {
  id_locker: number;
  onLockerSelected?: (item: any) => void;
  canSelectDoor?: (item: any) => boolean;
  refreshKey?: number;
  isSuperUser?: boolean;
  onSearchPackageInTable?: (packageInfo: any) => void;
}

interface RawModuleItem {
  module: number;
  data_module: number;
  name_module: string;
  column_name: string[];
  DOOR: any[];
}

interface ModuleInstance {
  id: string;
  name: string;
  columns: string[];
  elements: RawModuleItem[];
  order: number;
  data_module: number;
}

/* =====================================================
   COMPONENT
===================================================== */

export default function LockersDesign({
  id_locker,
  onLockerSelected,
  canSelectDoor,
  refreshKey = 0,
  isSuperUser = false,
  onSearchPackageInTable,
}: Props) {
  const [modules, setModules] = useState<ModuleInstance[]>([]);
  const [legend, setLegend] = useState({
    disponible: 0,
    agendado: 0,
    expirado: 0,
    abierto: 0,
    ocupado: 0,
    defectuoso: 0
  });

  /* =====================================================
     LOAD GRID
  ====================================================== */

  const loadGrid = useCallback(async () => {
    try {
      const res: any = await lockerDetailService.getLockersGrid({
        language: localStorage.getItem("lang")?.toLowerCase() || "es",
        id_locker,
      });

      if (!res?.modulo_status) return;

      const processed = processModules(res.modulo_status);

      setModules(processed);
      updateLegend(processed);
    } catch (err) {
      console.error("Error loading grid:", err);
    }
  }, [id_locker]);

  useEffect(() => {
    loadGrid();
    const interval = setInterval(loadGrid, 30000);
    return () => clearInterval(interval);
  }, [loadGrid, refreshKey]);

  /* =====================================================
     PROCESS MODULES
  ====================================================== */

  const processModules = (moduleStatus: RawModuleItem[]) => {
    const map = new Map<string, ModuleInstance>();

    moduleStatus.forEach((el) => {
      const key = `${el.module}-${el.data_module}-${el.column_name.join("-")}`;

      if (!map.has(key)) {
        map.set(key, {
          id: key,
          name: el.name_module,
          columns: el.column_name,
          elements: [],
          order: Infinity,
          data_module: el.data_module,
        });
      }

      const module = map.get(key)!;
      module.elements.push(el);

      const firstDoorNumber = el.DOOR?.[0]?.door_number ?? Infinity;
      module.order = Math.min(module.order, firstDoorNumber);
    });

    return Array.from(map.values()).sort(
      (a, b) => a.order - b.order
    );
  };

  /* =====================================================
     LEGEND
  ====================================================== */

  const updateLegend = (mods: ModuleInstance[]) => {
    const counters = {
      disponible: 0,
      agendado: 0,
      expirado: 0,
      abierto: 0,
      ocupado: 0,
      defectuoso: 0
    };

    mods.forEach((m) =>
      m.elements.forEach((el) => {
        const status =
          el.DOOR?.[0]?.name_status?.toLowerCase() || "unassigned";

        switch (status) {
          case "cerrado":
          case "disponible":
            counters.disponible++;
            break;
          case "schedule":
          case "agendado":
            counters.agendado++;
            break;
          case "expirado":
            counters.expirado++;
            break;
          case "abierto":
            counters.abierto++;
            break;
          case "ocupado":
            counters.ocupado++;
            break;
          case "fallo":
          case "defectuoso":
            counters.defectuoso++;
            break;
        }
      })
    );

    setLegend(counters);
  };

  /* =====================================================
     RENDER
  ====================================================== */

  return (
    <>
      {/* GRID */}
      <div className="flex justify-center overflow-x-auto rounded-md border p-4 gap-1 min-w-max">
        {modules.map((module) => (
          <LockerModule
            key={module.id}
            module={module.elements}
            onLockerSelected={onLockerSelected}
            canSelectDoor={canSelectDoor}
            isSuperUser={isSuperUser}
            onSearchPackageInTable={onSearchPackageInTable}
          />
        ))}
      </div>

      {/* LEGEND */}
      {/* <div className="flex justify-center gap-6 bg-gray-100 py-4 text-sm flex-wrap">
        {Object.entries(legend).map(([key, value]) => (
          <div key={key} className="flex items-center gap-2">
            <div
              className={`w-3 h-3 rounded-full ${getLegendColor(key)}`}
            />
            <span className="capitalize">
              {key} ({value})
            </span>
          </div>
        ))}
      </div> */}
    </>
  );
}

/* =====================================================
   LEGEND COLOR
===================================================== */

function getLegendColor(status: string) {
  switch (status) {
    case "disponible": return "bg-gray-300";
    case "ocupado": return "bg-red-500";
    case "agendado": return "bg-purple-500";
    case "expirado": return "bg-orange-500";
    case "abierto": return "bg-blue-400";
    case "defectuoso": return "bg-yellow-500";
  }
}


