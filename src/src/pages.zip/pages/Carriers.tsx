import { useState, useMemo, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Plus } from "lucide-react";

import { CarrierFormDialog } from "@/components/carriers/CarrierFormDialog";
import { CarriersStats } from "@/components/carriers/CarriersStats";
import { CarriersTable } from "@/components/carriers/CarriersTable";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { DeleteCarrierDialog } from "@/components/carriers/DeleteCarrierDialog";

import { useLanguage } from "@/contexts/LanguageContext";
import { Carrier, useCarriers } from "@/hooks/useCarriers";
import { courierService } from "@/services/courier.service";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";

/* ============================= */
/* ===== HELPERS =============== */
/* ============================= */

function safeParse(key: string) {
  try {
    return JSON.parse(localStorage.getItem(key) || "{}");
  } catch {
    return {};
  }
}

/* ============================= */
/* ===== COMPONENT ============= */
/* ============================= */

export default function CarriersPage() {
  const { t } = useLanguage();

  const {
    carriers,
    loading,
    requestCarrierCode,
    loadRequestCarrierCode,
    updateRequestCarrierCode,
    createCarrier,
    updateCarrier,
    deleteCarrier,
  } = useCarriers();

  const [openForm, setOpenForm]           = useState(false);
  const [selected, setSelected]           = useState<Carrier | null>(null);
  const [carrierToDelete, setCarrierToDelete] = useState<Carrier | null>(null);
  const [metrics, setMetrics]             = useState<any>(null);

  const isEditing = !!selected;

  // ✅ Una sola fuente de verdad para user y company
  const company = useMemo(() => safeParse("company"), []);
  const user    = useMemo(() => safeParse("user"), []);

  /* ============================= */
  /* ===== INIT SETTINGS ========= */
  /* ============================= */

  useEffect(() => {
    // ✅ usa el user del useMemo — sin shadow variable
    const propiertyId = user?.id_propierty;
    if (!propiertyId) return;
    loadRequestCarrierCode(propiertyId);
  }, [user?.id_propierty]);

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const response = await courierService.getCourierMetrics();
        setMetrics(response);
      } catch (error) {
        console.error("Error loading courier metrics:", error);
      }
    };

    fetchMetrics();
  }, []);

  /* ============================= */
  /* ===== ACTIONS =============== */
  /* ============================= */

  const handleOpenCreate = () => {
    setSelected(null);
    setOpenForm(true);
  };

  const handleEdit = (carrier: Carrier) => {
    setSelected(carrier);
    setOpenForm(true);
  };

  const handleClose = () => {
    setOpenForm(false);
    setSelected(null);
  };

  const handleSubmit = async (data: any) => {
    try {
      let response;

      if (isEditing && selected) {
        response = await updateCarrier({
          id_propierty_courier: selected.id_propierty_courier,
          data: {
            id_status:           data.id_status,
            id_courier_type:     data.id_courier_type,
            code:                data.code,
            courier_name:        data.courier_name,
            alias_courier:       data.alias_courier || null,
            logo_courier_small:  data.logo_courier_small || null,
          },
        });
      } else {
        response = await createCarrier({
          to_company:  company?.id_company,
          to_property: user?.id_propierty, // ✅ corregido — era id_property (sin i)
          data: {
            id_courier_type:    data.id_courier_type,
            courier_name:       data.courier_name,
            alias_courier:      data.alias_courier,
            code:               data.code,
            logo_courier_small: data.logo_courier_small,
          },
        });
      }

      if (response?.mensaje_return?.ERROR) {
        throw new Error(
          response?.mensaje_return?.ERROR_MENSAGGE || "Unknown error"
        );
      }

      handleClose();
    } catch (error: any) {
      console.error("Error saving carrier:", error);
      throw error;
    }
  };

  /* ============================= */
  /* ===== SETTINGS HANDLER ====== */
  /* ============================= */
const handleToggleLogin = async (checked: boolean) => {
  if (!user?.id_propierty) return;

  try {
    await updateRequestCarrierCode(
      user.id_propierty,
      checked
    );
  } catch (error) {
    console.error("Error updating setting:", error);
  }
};

  /* ============================= */
  /* ===== RENDER ================ */
  /* ============================= */
if (loading) {
  return (
    <DashboardLayout>
      <LoadingSpinner fullPage text={t("common.loading")} />
    </DashboardLayout>
  );
}
  return (
    <DashboardLayout>
      <div className="space-y-6">

        {/* HEADER */}
        <div className="flex justify-between items-start">
          <DashboardHeader
            title={t("carriers.title")}
            subtitle={t("carriers.subtitle")}
          />

          <Button onClick={handleOpenCreate} className="flex items-center gap-2">
            <Plus size={16} />
            {t("carriers.register")}
          </Button>
        </div>

        {/* SETTINGS */}
        {/* ✅ bg-brand no existe en el tema — reemplazado por bg-card */}
        <div className="p-4 rounded-xl border border-border bg-card flex items-center justify-between">
          <div>
            <p className="font-medium text-sm text-foreground">
              {t("carriers.requireLogin")}
            </p>
            <p className="text-xs text-muted-foreground">
              {t("carriers.requireLoginDesc")}
            </p>
          </div>

<Switch
  checked={requestCarrierCode ?? false}
  onCheckedChange={handleToggleLogin}
/>
        </div>

        {/* STATS */}
        <CarriersStats carriers={carriers} metrics={metrics} t={t} />

        {/* TABLE */}
        <CarriersTable
          carriers={carriers}
          t={t}
          loading={loading}
          onEdit={handleEdit}
          onDelete={(carrierId) => {
            const carrier = carriers.find((c) => c.id_courier === carrierId);
            setCarrierToDelete(carrier || null);
          }}
        />

      </div>

      {/* FORM */}
      <CarrierFormDialog
        open={openForm}
        initialData={selected}
        onClose={handleClose}
        onSubmit={handleSubmit}
      />

      {/* DELETE */}
      <DeleteCarrierDialog
        open={!!carrierToDelete}
        carrierName={carrierToDelete?.courier_name}
        t={t}
        onClose={() => setCarrierToDelete(null)}
        onConfirm={async () => {
          if (!carrierToDelete) return;
          await deleteCarrier(carrierToDelete.id_propierty_courier);
          setCarrierToDelete(null);
        }}
      />
    </DashboardLayout>
  );
}