import { useMemo, useState, type FormEvent } from "react";
import {
  ChevronDown,
  ChevronUp,
  Clock,
  Loader2,
  Mail,
  MessageCircle,
  Phone,
  Send,
} from "lucide-react";
import { toast } from "sonner";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useLanguage } from "@/contexts/LanguageContext";
import { typography } from "@/lib/typography";
import { cn } from "@/lib/utils";
import {
  contactService,
  type ContactData,
} from "@/services/contact.service";

interface ContactFormState {
  name: string;
  surname: string;
  email: string;
  company_name: string;
  how_hear_about_us: string;
  message: string;
}

const EMPTY_CONTACT_FORM: ContactFormState = {
  name: "",
  surname: "",
  email: "",
  company_name: "",
  how_hear_about_us: "",
  message: "",
};

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Help() {
  const { t, language } = useLanguage();

  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [contactForm, setContactForm] =
    useState<ContactFormState>(EMPTY_CONTACT_FORM);

  const faqItems = useMemo(
    () =>
      language === "es"
        ? [
            {
              question: "¿Cómo puedo agregar un nuevo residente?",
              answer:
                "Dirígete a la sección de Residentes en el menú lateral, haz clic en 'Nuevo Residente' y completa el formulario con los datos requeridos como nombre, correo electrónico y unidad asignada.",
            },
            {
              question: "¿Cómo genero un reporte de paquetes?",
              answer:
                "En la sección de Órdenes puedes filtrar por rango de fechas, estado y otros criterios. Utiliza el botón de exportar para descargar el reporte en formato CSV o PDF.",
            },
            {
              question:
                "¿Qué hago si un residente no recibe las notificaciones?",
              answer:
                "Verifica que el correo electrónico del residente esté correcto en su perfil. También revisa que las notificaciones estén habilitadas en la configuración del sistema.",
            },
            {
              question: "¿Cómo puedo cambiar mi contraseña?",
              answer:
                "Ve a Ajustes en el menú lateral, selecciona la pestaña 'Contraseña', ingresa tu contraseña actual y la nueva contraseña. Asegúrate de que cumpla con los requisitos de seguridad.",
            },
          ]
        : [
            {
              question: "How do I add a new resident?",
              answer:
                "Go to the Residents section in the sidebar, click 'New Resident' and fill in the form with the required information like name, email, and assigned unit.",
            },
            {
              question: "How do I generate a package report?",
              answer:
                "In the Orders section you can filter by date range, status and other criteria. Use the export button to download the report in CSV or PDF format.",
            },
            {
              question:
                "What do I do if a resident doesn't receive notifications?",
              answer:
                "Verify that the resident's email address is correct in their profile. Also check that notifications are enabled in the system settings.",
            },
            {
              question: "How can I change my password?",
              answer:
                "Go to Settings in the sidebar, select the 'Password' tab, enter your current password and new password. Make sure it meets the security requirements.",
            },
          ],
    [language],
  );

  const contactItems = [
    {
      icon: Mail,
      label: t("help.email"),
      value: "soporte@droppi.com",
      href: "mailto:soporte@droppi.com",
    },
    {
      icon: Phone,
      label: t("help.phone"),
      value: "+52 (55) 1234-5678",
      href: "tel:+525512345678",
    },
    {
      icon: MessageCircle,
      label: t("help.liveChat"),
      value: t("help.liveChatDesc"),
      href: "#",
    },
    {
      icon: Clock,
      label: t("help.hours"),
      value: t("help.hoursValue"),
      href: null,
    },
  ];

  const updateContactField = (
    field: keyof ContactFormState,
    value: string,
  ) => {
    setContactForm((current) => ({
      ...current,
      [field]: value,
    }));
  };

  const validateContactForm = (): boolean => {
    const name = contactForm.name.trim();
    const surname = contactForm.surname.trim();
    const email = contactForm.email.trim();
    const howHear = contactForm.how_hear_about_us.trim();

    if (!name || !surname || !email || !howHear) {
      toast.error(t("help.contact.required"));
      return false;
    }

    if (!EMAIL_REGEX.test(email)) {
      toast.error(t("help.contact.invalidEmail"));
      return false;
    }

    if (howHear.length < 2) {
      toast.error(t("help.contact.howHearMin"));
      return false;
    }

    return true;
  };

  const handleContactSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (isSubmitting || !validateContactForm()) {
      return;
    }

    const payload: ContactData = {
      name: contactForm.name,
      surname: contactForm.surname,
      email: contactForm.email,
      company_name: contactForm.company_name || undefined,
      how_hear_about_us: contactForm.how_hear_about_us,
      message: contactForm.message || undefined,
    };

    try {
      setIsSubmitting(true);

      await contactService.sendContactRequest(payload, language);

      toast.success(t("help.contact.success"), {
        description: t("help.contact.successDescription"),
      });

      setContactForm(EMPTY_CONTACT_FORM);
    } catch (error) {
      const message =
        error instanceof Error && error.message
          ? error.message
          : t("help.contact.error");

      toast.error(t("help.contact.error"), {
        description: message,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-4xl space-y-6">
        <div>
          <h1 className={cn(typography.pageTitle, "text-foreground")}>
            {t("help.title")}
          </h1>
          <p
            className={cn(
              typography.body,
              "mt-1 text-muted-foreground",
            )}
          >
            {t("help.subtitle")}
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {contactItems.map((item, index) => (
            <div
              key={`${item.label}-${index}`}
              className="card-elevated flex flex-col gap-2 p-4"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                <item.icon className="h-4 w-4 text-primary" />
              </div>

              <p className={cn(typography.cardTitle, "text-foreground")}>
                {item.label}
              </p>

              {item.href ? (
                <a
                  href={item.href}
                  className={cn(
                    typography.bodySmall,
                    "break-all text-primary hover:underline",
                  )}
                >
                  {item.value}
                </a>
              ) : (
                <p
                  className={cn(
                    typography.bodySmall,
                    "text-muted-foreground",
                  )}
                >
                  {item.value}
                </p>
              )}
            </div>
          ))}
        </div>

        {/* ============================= */}
        {/* CONTACTO                     */}
        {/* ============================= */}

        <div className="card-elevated overflow-hidden">
          <div className="border-b border-border px-5 py-4">
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                <Mail className="h-5 w-5 text-primary" />
              </div>

              <div>
                <h2
                  className={cn(
                    typography.sectionTitle,
                    "text-foreground",
                  )}
                >
                  {t("help.contact.title")}
                </h2>

                <p
                  className={cn(
                    typography.bodySmall,
                    "mt-1 text-muted-foreground",
                  )}
                >
                  {t("help.contact.subtitle")}
                </p>
              </div>
            </div>
          </div>

          <form onSubmit={handleContactSubmit} className="space-y-5 p-5">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <label
                  htmlFor="contact-name"
                  className={cn(typography.label, "text-foreground")}
                >
                  {t("help.contact.name")} *
                </label>
                <Input
                  id="contact-name"
                  value={contactForm.name}
                  onChange={(event) =>
                    updateContactField("name", event.target.value)
                  }
                  placeholder={t("help.contact.namePlaceholder")}
                  maxLength={35}
                  autoComplete="given-name"
                  disabled={isSubmitting}
                  required
                />
              </div>

              <div className="space-y-2">
                <label
                  htmlFor="contact-surname"
                  className={cn(typography.label, "text-foreground")}
                >
                  {t("help.contact.surname")} *
                </label>
                <Input
                  id="contact-surname"
                  value={contactForm.surname}
                  onChange={(event) =>
                    updateContactField("surname", event.target.value)
                  }
                  placeholder={t("help.contact.surnamePlaceholder")}
                  maxLength={35}
                  autoComplete="family-name"
                  disabled={isSubmitting}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <label
                  htmlFor="contact-email"
                  className={cn(typography.label, "text-foreground")}
                >
                  {t("help.contact.email")} *
                </label>
                <Input
                  id="contact-email"
                  type="email"
                  value={contactForm.email}
                  onChange={(event) =>
                    updateContactField("email", event.target.value)
                  }
                  placeholder={t("help.contact.emailPlaceholder")}
                  maxLength={150}
                  autoComplete="email"
                  disabled={isSubmitting}
                  required
                />
              </div>

              <div className="space-y-2">
                <label
                  htmlFor="contact-company"
                  className={cn(typography.label, "text-foreground")}
                >
                  {t("help.contact.companyOptional")}
                </label>
                <Input
                  id="contact-company"
                  value={contactForm.company_name}
                  onChange={(event) =>
                    updateContactField("company_name", event.target.value)
                  }
                  placeholder={t("help.contact.companyPlaceholder")}
                  maxLength={150}
                  autoComplete="organization"
                  disabled={isSubmitting}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label
                htmlFor="contact-how-hear"
                className={cn(typography.label, "text-foreground")}
              >
                {t("help.contact.howHear")} *
              </label>
              <Input
                id="contact-how-hear"
                value={contactForm.how_hear_about_us}
                onChange={(event) =>
                  updateContactField(
                    "how_hear_about_us",
                    event.target.value,
                  )
                }
                placeholder={t("help.contact.howHearPlaceholder")}
                minLength={2}
                maxLength={150}
                disabled={isSubmitting}
                required
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between gap-3">
                <label
                  htmlFor="contact-message"
                  className={cn(typography.label, "text-foreground")}
                >
                  {t("help.contact.messageOptional")}
                </label>

                <span className="text-xs text-muted-foreground">
                  {contactForm.message.length}/1000
                </span>
              </div>

              <Textarea
                id="contact-message"
                value={contactForm.message}
                onChange={(event) =>
                  updateContactField("message", event.target.value)
                }
                placeholder={t("help.contact.messagePlaceholder")}
                maxLength={1000}
                rows={5}
                disabled={isSubmitting}
                className="min-h-[120px] resize-y"
              />
            </div>

            <div className="flex flex-col gap-3 border-t border-border pt-4 sm:flex-row sm:items-center sm:justify-between">
              <p className="max-w-xl text-xs leading-5 text-muted-foreground">
                {t("help.contact.rateLimit")}
              </p>

              <Button
                type="submit"
                className="shrink-0"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    {t("help.contact.sending")}
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" />
                    {t("help.contact.send")}
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>

        {/* ============================= */}
        {/* FAQ                           */}
        {/* ============================= */}

        <div className="card-elevated">
          <div className="border-b border-border px-5 py-4">
            <h2 className={cn(typography.sectionTitle, "text-foreground")}>
              {t("help.faq")}
            </h2>
          </div>

          <div className="divide-y divide-border">
            {faqItems.map((item, index) => (
              <div key={item.question}>
                <button
                  type="button"
                  onClick={() =>
                    setOpenIndex(openIndex === index ? null : index)
                  }
                  className="flex w-full items-center justify-between px-5 py-4 text-left transition-colors hover:bg-muted/50"
                  aria-expanded={openIndex === index}
                >
                  <span className={cn(typography.label, "text-foreground")}>
                    {item.question}
                  </span>

                  {openIndex === index ? (
                    <ChevronUp className="ml-3 h-4 w-4 shrink-0 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="ml-3 h-4 w-4 shrink-0 text-muted-foreground" />
                  )}
                </button>

                {openIndex === index && (
                  <div className="px-5 pb-4">
                    <p
                      className={cn(
                        typography.body,
                        "text-muted-foreground",
                      )}
                    >
                      {item.answer}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
