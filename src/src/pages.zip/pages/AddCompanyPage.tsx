import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ChevronLeft, Trash2, Plus, Save, MapPin } from "lucide-react";
import { companyService } from "@/services/company.service";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Column } from "@/components/ui/types";
import SelectableMap from "@/components/ui/Selectablemap";
import { GenericTable } from "@/components/ui/GenericTable";

interface CompanyForm {
  email: string; password: string; company_name: string; trfc: string;
  phone_number: string; acronym: string; copyright: string; address: string;
  id_state: string; state: string; id_city: string; city: string;
  latitude: string; longitude: string; id_status: number;
}
interface StateOption { id: number; name: string; }
interface CityOption  { id: number; name: string; }

const INITIAL: CompanyForm = {
  email: "", password: "", company_name: "", trfc: "", phone_number: "",
  acronym: "", copyright: "", address: "", id_state: "", state: "",
  id_city: "", city: "", latitude: "", longitude: "", id_status: 1,
};

function Field({ label, value, onChange, placeholder, required, type = "text", maxLength, error, disabled, icon }: {
  label: string; value: string; onChange: (v: string) => void;
  placeholder?: string; required?: boolean; type?: string;
  maxLength?: number; error?: string; disabled?: boolean;
  icon?: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5 w-full">
      <Label className="text-xs font-medium text-foreground">
        {label}{required && <span className="text-destructive ml-0.5">*</span>}
      </Label>
      <div className="relative">
        {icon && (
          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none text-muted-foreground">
            {icon}
          </span>
        )}
        <Input
          type={type} value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder} maxLength={maxLength} disabled={disabled}
          className={`${icon ? "pl-8" : ""} ${error ? "border-destructive" : ""}`}
        />
      </div>
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}

export default function AddCompanyPage() {
  const { t }    = useLanguage();
  const navigate = useNavigate();

  const [form, setForm]       = useState<CompanyForm>(INITIAL);
  const [errors, setErrors]   = useState<Partial<Record<keyof CompanyForm, string>>>({});
  const [staging, setStaging] = useState<CompanyForm[]>([]);
  const [saving, setSaving]   = useState(false);
  const [states, setStates]   = useState<StateOption[]>([]);
  const [cities, setCities]   = useState<CityOption[]>([]);
  const [loadingCities, setLoadingCities] = useState(false);

  useEffect(() => {
    companyService.getStates().then((res: any) => {
      if (res?.cities)
        setStates(res.cities.map((s: any) => ({ id: s.id_state, name: s.state_name })));
    });
  }, []);

  const loadCities = async (id_state: number) => {
    try {
      setLoadingCities(true);
      const res: any = await companyService.getCity(id_state);
      if (res?.cities)
        setCities(res.cities.map((c: any) => ({ id: c.id_city, name: c.city })));
    } finally { setLoadingCities(false); }
  };

  const set = (field: keyof CompanyForm, value: string) => {
    setForm((p) => ({ ...p, [field]: value }));
    setErrors((p) => ({ ...p, [field]: undefined }));
  };

  // Agrega este helper antes del return
const getAddressFromCoords = (lat: number, lng: number): Promise<string> => {
  return new Promise((resolve) => {
    if (!window.google?.maps) return resolve("");
    
    const geocoder = new window.google.maps.Geocoder();
    geocoder.geocode(
      { location: { lat, lng }, language: "es" },
      (results: any, status: any) => {
        if (status === "OK" && results?.[0]) {
          resolve(results[0].formatted_address);
        } else {
          resolve("");
        }
      }
    );
  });
};

// Reemplaza handleLocationSelect
const handleLocationSelect = async ({ lat, lng }: { lat: number; lng: number }) => {
  set("latitude",  lat.toFixed(8));
  set("longitude", lng.toFixed(8));

  const address = await getAddressFromCoords(lat, lng);
  if (address) set("address", address);
};

  const validate = () => {
    const e: Partial<Record<keyof CompanyForm, string>> = {};
    const req = t("validation.required") || "Campo obligatorio";
    if (!form.email.trim())        e.email        = req;
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = t("validation.invalidEmail") || "Email inválido";
    if (!form.password.trim())     e.password     = req;
    if (!form.company_name.trim()) e.company_name = req;
    if (!form.trfc.trim())         e.trfc         = req;
    if (!form.phone_number.trim()) e.phone_number = req;
    else if (!/^\+\d{1,3}(?:[\s-]?\d){7,15}$/.test(form.phone_number.trim())) {
      e.phone_number = "Usa el formato internacional, por ejemplo +52 5512345678";
    }
    if (!form.acronym.trim())      e.acronym      = req;
    if (!form.copyright.trim())    e.copyright    = req;
    if (!form.address.trim())      e.address      = req;
    if (!form.id_state)            e.id_state     = req;
    if (!form.id_city)             e.id_city      = req;
    if (!form.latitude.trim())     e.latitude     = req;
    if (!form.longitude.trim())    e.longitude    = req;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleAddToTable = () => {
    if (!validate()) { toast.error(t("companyPage.forms.validation.fillRequired") || "Completa todos los campos requeridos"); return; }
    setStaging((p) => [...p, { ...form }]);
    setForm(INITIAL);
    setCities([]);
    toast.success(t("companyPage.forms.addedToList") || "Compañía agregada a la lista");
  };

  const handleRemove = (i: number) => setStaging((p) => p.filter((_, idx) => idx !== i));

  const handleSaveAll = async () => {
    if (!staging.length) { toast.error(t("companyPage.forms.emptyList") || "Agrega al menos una compañía"); return; }
    try {
      setSaving(true);
      const res: any = await companyService.postCompany({
        company: staging.map(({ id_state, state, city, ...c }) => ({
          ...c, latitude: c.latitude.toString(), longitude: c.longitude.toString(),
        })),
      });
      if (res?.error_data?.length > 0) {
        res.error_data.forEach((err: any) => toast.error(`${err.data?.company_name}: ${err.err}`));
        return;
      }
      if (res?.result?.mensaje_return?.CODE === 200) {
        toast.success(t("companyPage.forms.savedSuccess") || "Guardado correctamente");
        navigate("/company");
      } else { toast.error(t("common.unexpectedError") || "Error inesperado"); }
    } catch (error) {
      console.error(error);
      toast.error(t("common.errorSaving") || "Error al guardar");
    } finally { setSaving(false); }
  };

  const stagingColumns: Column<CompanyForm & { _index: number }>[] = [
    { key: "company_name", header: t("companyPage.table.company_name") || "Nombre",   sortable: true,  render: (r) => <span className="font-medium text-sm">{r.company_name}</span> },
    { key: "email",        header: t("companyPage.table.email")        || "Email",    sortable: false, render: (r) => <span className="text-sm text-muted-foreground">{r.email}</span> },
    { key: "address",      header: t("companyPage.table.address")      || "Dirección",sortable: false, render: (r) => <span className="text-sm text-muted-foreground max-w-[260px] truncate block">{r.address}</span> },
    { key: "phone_number", header: t("companyPage.table.phone_number") || "Teléfono", sortable: false, render: (r) => <span className="text-sm">{r.phone_number}</span> },
    { key: "acronym",      header: t("companyPage.table.acronym")      || "Acrónimo", sortable: false, render: (r) => <span className="text-sm">{r.acronym}</span> },
    { key: "copyright",    header: t("companyPage.table.copyright")    || "Copyright",sortable: false, render: (r) => <span className="text-sm">{r.copyright}</span> },
    {
      key: "_index" as any, header: "", sortable: false,
      render: (r) => (
        <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:bg-destructive/10"
          onClick={(e) => { e.stopPropagation(); handleRemove(r._index); }}>
          <Trash2 className="h-4 w-4" />
        </Button>
      ),
    },
  ];

  const mapLat = form.latitude  ? parseFloat(form.latitude)  : undefined;
  const mapLng = form.longitude ? parseFloat(form.longitude) : undefined;

  

  return (
    <DashboardLayout>
      <div className="space-y-6">

        {/* HEADER */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => navigate("/company")}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground mb-0.5">
              <span className="cursor-pointer hover:text-foreground transition-colors" onClick={() => navigate("/company")}>
                {t("companyPage.title") || "Compañía"}
              </span>
              <span>/</span>
              <span className="text-foreground">{t("companyPage.add_company") || "Agregar compañía"}</span>
            </div>
            <h1 className="text-xl font-bold font-poppins">
              {t("companyPage.add_company") || "Agregar compañía"}
            </h1>
          </div>
        </div>

        {/* FORM + MAP */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">

          {/* FORM */}
          <div className="metric-card space-y-4">
            <p className="text-[13px] font-semibold font-poppins text-foreground">
              {t("companyPage.forms.company.sectionTitle") || "Datos de la compañía"}
            </p>

            <div className="grid grid-cols-2 gap-4">
              <Field label={t("companyPage.forms.company.email")    || "Email"}      value={form.email}    onChange={(v) => set("email", v)}    placeholder="empresa@correo.com" required type="email"    maxLength={50}  error={errors.email} />
              <Field label={t("companyPage.forms.company.password") || "Contraseña"} value={form.password} onChange={(v) => set("password", v)} placeholder="••••••••"           required type="password"          error={errors.password} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Field label={t("companyPage.forms.company.company_name") || "Nombre"} value={form.company_name} onChange={(v) => set("company_name", v)} placeholder={t("companyPage.forms.company.placeholder_company_name") || "Nombre"} required maxLength={100} error={errors.company_name} />
              <Field label={t("companyPage.forms.company.trfc") || "RFC"}            value={form.trfc}         onChange={(v) => set("trfc", v)}          placeholder="RFC123456789" required maxLength={20} error={errors.trfc} />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <Field label={t("companyPage.forms.company.phone_number") || "Teléfono"} value={form.phone_number} onChange={(v) => set("phone_number", v)} placeholder="+52 81 1234 5678" required maxLength={13} error={errors.phone_number} />
              <Field label={t("companyPage.forms.company.acronym")     || "Acrónimo"}  value={form.acronym}      onChange={(v) => set("acronym", v)}      placeholder="EMP"    required maxLength={20} error={errors.acronym} />
              <Field label={t("companyPage.forms.company.copyright")   || "Copyright"} value={form.copyright}    onChange={(v) => set("copyright", v)}    placeholder="© 2025" required maxLength={30} error={errors.copyright} />
            </div>

            <Field label={t("companyPage.forms.company.address") || "Dirección"} value={form.address} onChange={(v) => set("address", v)} placeholder={t("companyPage.forms.company.placeholder_address") || "Calle, número, colonia, ciudad"} required maxLength={300} error={errors.address} />

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-foreground">
                  {t("companyPage.forms.company.state") || "Estado"}<span className="text-destructive ml-0.5">*</span>
                </Label>
                <Select value={form.id_state} onValueChange={(v) => {
                  const f = states.find((s) => String(s.id) === v);
                  set("id_state", v); set("state", f?.name || "");
                  loadCities(Number(v)); set("id_city", ""); set("city", "");
                }}>
                  <SelectTrigger className={errors.id_state ? "border-destructive" : ""}>
                    <SelectValue placeholder={t("companyPage.forms.company.placeholder_state") || "Seleccionar estado"} />
                  </SelectTrigger>
                  <SelectContent>
                    {states.map((s) => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
                {errors.id_state && <p className="text-xs text-destructive">{errors.id_state}</p>}
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-foreground">
                  {t("companyPage.forms.company.city") || "Ciudad"}<span className="text-destructive ml-0.5">*</span>
                </Label>
                <Select value={form.id_city} disabled={!form.id_state || loadingCities}
                  onValueChange={(v) => {
                    const f = cities.find((c) => String(c.id) === v);
                    set("id_city", v); set("city", f?.name || "");
                  }}>
                  <SelectTrigger className={errors.id_city ? "border-destructive" : ""}>
                    <SelectValue placeholder={loadingCities ? (t("common.loading") || "Cargando...") : (t("companyPage.forms.company.placeholder_city") || "Seleccionar ciudad")} />
                  </SelectTrigger>
                  <SelectContent>
                    {cities.map((c) => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
                {errors.id_city && <p className="text-xs text-destructive">{errors.id_city}</p>}
              </div>
            </div>

            {/* LAT + LNG */}
            <div className="grid grid-cols-2 gap-4">
              <Field
                label={t("companyPage.forms.company.latitud") || "Latitud"}
                value={form.latitude} onChange={(v) => set("latitude", v)}
                placeholder="25.74682811" required error={errors.latitude}
                icon={<MapPin className="h-3.5 w-3.5" />}
              />
              <Field
                label={t("companyPage.forms.company.longitud") || "Longitud"}
                value={form.longitude} onChange={(v) => set("longitude", v)}
                placeholder="-100.351334" required error={errors.longitude}
                icon={<MapPin className="h-3.5 w-3.5" />}
              />
            </div>

            <div className="flex justify-end pt-1">
              <Button onClick={handleAddToTable} className="gap-2">
                <Plus className="h-4 w-4" />
                {t("companyPage.forms.addToList") || "Agregar a lista"}
              </Button>
            </div>
          </div>

          {/* MAP */}
          <div className="metric-card p-0 overflow-hidden lg:sticky lg:top-6">
            <div className="px-4 py-3 border-b border-border flex items-center justify-between">
              <p className="text-[13px] font-semibold font-poppins text-foreground">
                {t("companyPage.forms.company.selectLocation") || "Seleccionar ubicación"}
              </p>
              {form.latitude && form.longitude && (
                <span className="text-xs text-muted-foreground font-mono">
                  {parseFloat(form.latitude).toFixed(5)}, {parseFloat(form.longitude).toFixed(5)}
                </span>
              )}
            </div>

            <div className="h-[520px]">
              <SelectableMap lat={mapLat} lng={mapLng} onLocationSelect={handleLocationSelect} />
            </div>

            {!form.latitude && (
              <div className="px-4 py-2 border-t border-border bg-muted/30">
                <p className="text-xs text-muted-foreground text-center">
                  {t("companyPage.forms.company.clickMapHint") || "Haz clic en el mapa para seleccionar la ubicación"}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* STAGING TABLE */}
        {staging.length > 0 && (
          <>
            <p className="text-[13px] font-semibold font-poppins text-foreground">
              {t("companyPage.forms.stagingTitle") || "Compañías por guardar"}
              <span className="text-secondary ml-2">{staging.length}</span>
            </p>

            <GenericTable
              data={staging.map((s, i) => ({ ...s, _index: i }))}
              columns={stagingColumns as any}
              enableSearch={false}
              enableDateRange={false}
            />

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => navigate("/company")} disabled={saving}>
                {t("common.cancel") || "Cancelar"}
              </Button>
              <Button onClick={handleSaveAll} disabled={saving} className="gap-2">
                {saving
                  ? <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                  : <Save className="h-4 w-4" />}
                {saving
                  ? (t("common.saving") || "Guardando...")
                  : `${t("companyPage.forms.saveAll") || "Guardar"} ${staging.length} ${staging.length > 1 ? (t("companyPage.forms.companies") || "compañías") : (t("companyPage.forms.company_singular") || "compañía")}`}
              </Button>
            </div>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}