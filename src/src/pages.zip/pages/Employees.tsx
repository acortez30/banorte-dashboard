import { useMemo, useState } from "react";
import { AlertTriangle, Boxes, FileUp, Pencil, Plus, Search, UsersRound } from "lucide-react";
import { toast } from "sonner";
import DashboardLayout from "@/components/layout/DashboardLayout";
import PageHeader from "@/components/common/PageHeader";
import MetricCard from "@/components/common/MetricCard";
import ToggleSwitch from "@/components/common/ToggleSwitch";
import TablePagination from "@/components/common/TablePagination";
import EmployeeFormDialog from "@/components/employees/EmployeeFormDialog";
import BulkImportDialog from "@/components/employees/BulkImportDialog";
import { useData } from "@/contexts/DataContext";
import { capacitySummary, getLockerLoads } from "@/utils/lockerAssignment";
import type { Employee } from "@/types/dashboard";

export default function Employees() {
  const { lockers, employees, addEmployee, updateEmployee, toggleEmployee, importEmployees } = useData();
  const [search, setSearch] = useState("");
  const [lockerFilter, setLockerFilter] = useState("ALL");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [formOpen, setFormOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [editing, setEditing] = useState<Employee | null>(null);

  const summary = useMemo(() => capacitySummary(lockers, employees), [employees, lockers]);
  const loads = useMemo(() => getLockerLoads(lockers, employees), [employees, lockers]);
  const lockerById = useMemo(() => new Map(lockers.map((locker) => [locker.id, locker])), [lockers]);

  const filtered = employees.filter((employee) => {
    const matchesSearch = `${employee.name} ${employee.phone} ${employee.employeeNumber} ${employee.badgeNumber}`.toLowerCase().includes(search.toLowerCase());
    const matchesLocker = lockerFilter === "ALL" || employee.lockerId === lockerFilter;
    return matchesSearch && matchesLocker;
  });
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize);
  const loadValues = loads.map((load) => load.assigned);
  const maxLoad = loadValues.length ? Math.max(...loadValues) : 0;
  const minLoad = loadValues.length ? Math.min(...loadValues) : 0;
  const balanced = maxLoad - minLoad <= 1;

  return (
    <DashboardLayout>
      <div className="space-y-5 animate-fade-in">
        <PageHeader
          title="Empleados"
          description="Administra empleados Banorte y su asignación a islas de lockers."
          actions={(
            <>
              <button className="btn-secondary" onClick={() => setBulkOpen(true)}><FileUp size={17} /> Alta masiva</button>
              <button className="btn-primary" onClick={() => { setEditing(null); setFormOpen(true); }}><Plus size={17} /> Nuevo empleado</button>
            </>
          )}
        />

        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <MetricCard label="Empleados" value={employees.length.toLocaleString("es-MX")} helper={`${employees.filter((employee) => employee.active).length} activos`} icon={UsersRound} />
          <MetricCard label="Islas activas" value={summary.activeLockerCount} helper={`${summary.totalCapacity.toLocaleString("es-MX")} espacios totales`} icon={Boxes} />
          <MetricCard label="Capacidad disponible" value={summary.available.toLocaleString("es-MX")} helper={`${summary.assigned.toLocaleString("es-MX")} asignados`} icon={Boxes} alert={!summary.hasCapacity} />
          <MetricCard label="Balance actual" value={balanced ? "Balanceado" : `${minLoad}–${maxLoad}`} helper={balanced ? "Diferencia máxima: 1 empleado" : "Revisar asignaciones manuales"} icon={balanced ? UsersRound : AlertTriangle} alert={!balanced} />
        </div>

        <section className="rounded-2xl border border-border bg-card p-4 shadow-card">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="font-semibold text-foreground">Distribución por isla</h2>
              <p className="mt-1 text-xs text-muted-foreground">Las altas automáticas siempre seleccionan la isla activa con menor número de empleados.</p>
            </div>
            {summary.additionalRequired > 0 ? (
              <div className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-sm font-medium text-red-700">Se requieren {summary.additionalRequired} isla(s) adicional(es).</div>
            ) : null}
          </div>
          <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-6">
            {loads.map(({ locker, assigned, available }) => (
              <div key={locker.id} className="rounded-xl border border-border bg-background px-3 py-3">
                <div className="flex items-center justify-between gap-2"><span className="text-sm font-semibold">{locker.alias}</span><span className="text-xs text-muted-foreground">{assigned}/133</span></div>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary" style={{ width: `${Math.min(100, (assigned / 133) * 100)}%` }} /></div>
                <p className="mt-2 text-xs text-muted-foreground">{available} disponibles</p>
              </div>
            ))}
          </div>
        </section>

        <section className="table-shell">
          <div className="table-toolbar gap-3">
            <div className="relative w-full max-w-sm"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={16} /><input className="form-input h-10 pl-9" value={search} onChange={(event) => { setSearch(event.target.value); setPage(1); }} placeholder="Buscar empleado, número o gafete" /></div>
            <select className="form-input h-10 w-full sm:w-[220px]" value={lockerFilter} onChange={(event) => { setLockerFilter(event.target.value); setPage(1); }}><option value="ALL">Todas las islas</option>{lockers.map((locker) => <option key={locker.id} value={locker.id}>{locker.alias}</option>)}</select>
          </div>
          <div className="overflow-x-auto">
            <table className="data-table min-w-[1100px]">
              <thead><tr><th>Nombre</th><th>Teléfono</th><th>Número de empleado</th><th>Número de gafete</th><th>Isla</th><th>Acceso</th><th className="text-right">Acción</th></tr></thead>
              <tbody>
                {paginated.map((employee) => (
                  <tr key={employee.id}>
                    <td className="font-semibold text-foreground">{employee.name}</td>
                    <td>{employee.phone}</td>
                    <td>{employee.employeeNumber}</td>
                    <td>{employee.badgeNumber}</td>
                    <td><span className="rounded-lg bg-muted px-2.5 py-1 text-xs font-semibold text-foreground">{lockerById.get(employee.lockerId)?.alias ?? "Sin isla"}</span></td>
                    <td><ToggleSwitch checked={employee.active} onChange={(active) => { toggleEmployee(employee.id, active); toast.success(active ? "Empleado activado" : "Empleado desactivado"); }} label={`Cambiar acceso de ${employee.name}`} /></td>
                    <td className="text-right"><button className="icon-action" onClick={() => { setEditing(employee); setFormOpen(true); }} aria-label={`Editar ${employee.name}`}><Pencil size={16} /></button></td>
                  </tr>
                ))}
                {!paginated.length ? <tr><td colSpan={7} className="py-12 text-center text-muted-foreground">No se encontraron empleados.</td></tr> : null}
              </tbody>
            </table>
          </div>
          <TablePagination page={page} pageSize={pageSize} total={filtered.length} onPageChange={setPage} onPageSizeChange={(size) => { setPageSize(size); setPage(1); }} />
        </section>
      </div>

      <EmployeeFormDialog
        open={formOpen}
        onClose={() => setFormOpen(false)}
        employee={editing}
        lockers={lockers}
        employees={employees}
        onSubmit={(value) => {
          const result = editing ? updateEmployee(editing.id, value) : addEmployee(value);
          if (result.ok) toast.success(editing ? "Empleado actualizado" : "Empleado creado y asignado automáticamente");
          return result;
        }}
      />
      <BulkImportDialog
        open={bulkOpen}
        onClose={() => setBulkOpen(false)}
        lockers={lockers}
        employees={employees}
        onImport={(rows) => {
          const result = importEmployees(rows);
          if (result.ok) toast.success(`${result.created} empleados importados y balanceados`);
          return result;
        }}
      />
    </DashboardLayout>
  );
}
