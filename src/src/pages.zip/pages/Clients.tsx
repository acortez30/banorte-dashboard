import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useLanguage } from "@/contexts/LanguageContext";
import { toast } from "sonner";

import ClientsStats from "@/components/clients/ClientsStats";
import ClientsChart from "@/components/clients/ClientsChart";
import ClientsTable, { Client as TableClient } from "@/components/clients/ClientsTable";

import UploadClientsModal, {
  type ClientImportCandidate,
} from "@/components/clients/modals/UploadClientsModal";
import type { ClientImportResultItem } from "@/components/clients/modals/ImportClientsResultDialog";
import DeleteClientModal from "@/components/clients/modals/DeleteClientModal";
import ToggleConfirmModal from "@/components/clients/modals/ToggleConfirmModal";
import ClientsHeader from "@/components/clients/ClientsHeaders";
import EditClientModal from "@/components/clients/modals/EditClientModal";
import AddClientModal from "@/components/clients/modals/AddClientModal";

import { clientsService } from "@/services/client.service";
import { unitsService } from "@/services/units.service";
import { format, parseISO } from "date-fns";
import { es } from "date-fns/locale";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";

/* ================= HELPERS ================= */

const normalizeUnit = (val: string) =>
  val?.replace(/\s+/g, "").replace(/-/g, "").toUpperCase();

function safeParse(key: string) {
  try {
    return JSON.parse(localStorage.getItem(key) || "{}");
  } catch {
    return {};
  }
}

/* ================= COMPONENT ================= */

export default function Clients() {
  const navigate = useNavigate();
  const { t } = useLanguage();

  const companyData = safeParse("company");
  const propertyId  = companyData?.id_propierty;

  const [clients, setClients]   = useState<TableClient[]>([]);
  const [loading, setLoading]   = useState(false);
  const [metrics, setMetrics]   = useState<any>(null);

  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editClient, setEditClient]       = useState<any>(null);

  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget]       = useState<TableClient | null>(null);
  const [addModalOpen, setAddModalOpen]       = useState(false);

  const [unitsMap, setUnitsMap] = useState<Map<string, number>>(new Map());

  const [toggleData, setToggleData] = useState<any>({
    open: false,
    clientId: "",
    clientName: "",
    field: "clientStatus",
    currentValue: false,
    id_line_service: undefined,
  });

  /* ================= LOAD CLIENTS ================= */

  const loadClients = useCallback(async () => {
    if (!propertyId) return;

    try {
      setLoading(true);

      const response = await clientsService.queryClients({
        page: 1,
        limit: 500, // GenericTable maneja la paginación client-side
      });

      const backendClients = response?.result_return || [];

      const adapted: TableClient[] = backendClients.map((item: any) => ({
        id:               String(item.id_user),
        id_user:          item.id_user,
        id_consumer:      item.id_consumer,
        id_line_service:  item.lines_service?.[0]?.id_line_service || null,
        userName:         `${item.first_name || ""} ${item.surname || ""}`.trim(),
        unitNumber:       item.unit || "",
        id_unit:          String(item.id_unit),
        email:            item.email || "",
        telephone:        item.main_tlf ?? "",
        monthlyUsage:     item.packages?.current_month_package ?? 0,
        registrationDate: item.registration_date
          ? format(parseISO(item.registration_date), "dd MMM yyyy HH:mm", { locale: es })
          : "",
        clientStatus:  item.id_status_propierty === 1,
        serviceStatus: item.lines_service?.[0]?.id_status_service_locker === 1,
      }));

      setClients(adapted);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  }, [propertyId]);

  /* ================= LOAD METRICS ================= */

  const loadMetrics = useCallback(async () => {
    if (!propertyId) return;

    try {
      const res = await clientsService.getMetricClient({ id_property: propertyId });
      setMetrics(res);
    } catch (error: any) {
      toast.error(error.message);
    }
  }, [propertyId]);

  /* ================= LOAD UNITS ================= */

  const loadUnits = useCallback(async () => {
    if (!propertyId) return;

    try {
      const res = await unitsService.getAllUnits(propertyId, "en");
      const units = Array.isArray(res) ? res : res?.units || res?.data?.units || res?.result_return || [];

      const map = new Map<string, number>();
      units.forEach((u: any) => {
        map.set(normalizeUnit(String(u.number)), u.id);
      });

      setUnitsMap(map);
    } catch {
      toast.error(t("common.errorLoadingUnits") || "Error cargando unidades");
    }
  }, [propertyId, t]);

  /* ================= EFFECTS ================= */

  useEffect(() => {
    loadClients();
    loadUnits();
    loadMetrics();
  }, [loadClients, loadUnits, loadMetrics]);

  /* ================= KPI DATA ================= */

  const general = metrics?.return_metric?.monthly_consumer?.general?.[0];

const stats = general
  ? [
      {
        title: t("clients.totalClients"),
        value: general.total_users_registered,
        sub: `+${general.new_users_this_month} ${t("clients.thisMonth")}`,
        description: t("clients.metrics.totalClientsTooltip"),
        subtitleVariant: "success" as const,
      },
      {
        title: t("clients.newThisMonth"),
        value: general.new_users_this_month,
        sub: `+${general.active_users_this_month} ${t("clients.vsPrevMonth")}`,
        description: t("clients.metrics.newThisMonthTooltip"),
        subtitleVariant: "success" as const,
      },
      {
        title: t("clients.activeThisMonth"),
        value: general.active_users_this_month,
        sub: `+${general.active_users} ${t("clients.vsPrevMonth")}`,
        description: t("clients.metrics.activeThisMonthTooltip"),
        subtitleVariant: "success" as const,
      },
      {
        title: t("clients.inactiveThisMonth"),
        value: general.inactive_users_this_month,
        sub: `-${general.inactive_users} ${t("clients.vsPrevMonth")}`,
        description: t("clients.metrics.inactiveThisMonthTooltip"),
        variant: "destructive" as const,
        subtitleVariant: "destructive" as const,
      },
    ]
  : [];

  const chartData = metrics?.return_metric?.monthly_consumer?.single?.map(
    (item: any) => ({ name: item.MONTH, unique: item.total_unique_user, recurring: item.total_recurring_user })
  ) || [];

  /* ================= TOGGLE ================= */

  const handleToggleRequest = ({ client, type }: { client: TableClient; type: "user" | "service" }) => {
    setToggleData({
      open: true,
      clientId: client.id_user,
      clientName: client.userName,
      field: type === "user" ? "clientStatus" : "serviceStatus",
      currentValue: type === "user" ? client.clientStatus : client.serviceStatus,
      id_line_service: client.id_line_service,
    });
  };

  const handleConfirmToggle = async () => {
    try {
      if (toggleData.field === "clientStatus") {
        await clientsService.updateConsumer({
          data_user: {
            id_user: toggleData.clientId,
            toggle_user: { id_status: toggleData.currentValue ? 2 : 1 },
          },
        });
      }

      if (toggleData.field === "serviceStatus") {
        await clientsService.updateConsumer({
          data_user: {
            id_user: toggleData.clientId,
            to_propierty: propertyId,
            toggle_line_service: {
              id_line_service: toggleData.id_line_service,
              id_status: toggleData.currentValue ? 2 : 1,
            },
          },
        });
      }

      toast.success(t("clients.statusUpdated"));
      setToggleData((prev: any) => ({ ...prev, open: false }));
      loadClients();
      loadMetrics();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  /* ================= DELETE ================= */

  const handleDeleteClient = async () => {
    if (!deleteTarget) return;

    try {
      await clientsService.updateConsumer({
        data_user: {
          id_user: deleteTarget.id_user,
          to_propierty: propertyId,
          delete_user: true,
        },
      });

      toast.success(t("clients.clientDeleted"));
      setDeleteModalOpen(false);
      loadClients();
      loadMetrics();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  /* ================= EDIT ================= */

  const handleEditClient = async (data: any) => {
    const cleanPhone = (value: string) => value?.replace(/\D/g, "") || "";

    try {
      const cleanedPhone = cleanPhone(data.phone);

      await clientsService.updateConsumer({
        data_user: {
          id_user: data.id_user,
          data: {
            first_name: data.firstName,
            surname:    data.lastName,
            telephone:  cleanedPhone.length >= 10
              ? `${data.countryCode}${cleanedPhone}`
              : undefined,
          },
        },
      });

      toast.success(t("clients.clientUpdated"));
      setEditModalOpen(false);
      loadClients();
      loadMetrics();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  /* ================= CREATE ================= */

  const handleCreateClient = async (data: any) => {
    try {
      await clientsService.registerConsumer(
        {
          consumers: [{
            first_name: data.firstName,
            surname:    data.lastName,
            email:      data.email,
            telephone:  `${data.countryCode}${data.phone}`,
            id_unit:    data.unit,
            language:   data.language,
          }],
        },
        propertyId
      );

      toast.success(t("clients.clientCreated"));
      setAddModalOpen(false);
      loadClients();
      loadMetrics();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  /* ================= UPLOAD ================= */

  const handleUploadArchive = async (
    data: ClientImportCandidate[],
  ): Promise<ClientImportResultItem[]> => {
    if (!data.length) {
      return [];
    }

    if (!propertyId) {
      return data.map((row) => ({
        row: row.row,
        name: `${row.first_name} ${row.surname}`.trim(),
        email: row.email,
        unit: row.unit,
        status: "error" as const,
        message: t("clients.import.error.invalidProperty"),
      }));
    }

    const results: ClientImportResultItem[] = [];
    const IMPORT_CONCURRENCY = 5;

    // Cada residente se envía por separado. Así, si el backend rechaza uno
    // (correo existente, unidad inválida, etc.), los demás sí se registran.
    for (let start = 0; start < data.length; start += IMPORT_CONCURRENCY) {
      const batch = data.slice(start, start + IMPORT_CONCURRENCY);

      const batchResults = await Promise.all(
        batch.map(async (row): Promise<ClientImportResultItem> => {
          try {
            await clientsService.registerConsumer(
              {
                consumers: [
                  {
                    first_name: row.first_name,
                    surname: row.surname,
                    email: row.email,
                    telephone: row.telephone,
                    id_unit: row.id_unit,
                    language: "en",
                  },
                ],
              },
              propertyId,
            );

            return {
              row: row.row,
              name: `${row.first_name} ${row.surname}`.trim(),
              email: row.email,
              unit: row.unit,
              status: "success",
              message: t("clients.import.result.created"),
            };
          } catch (error) {
            console.error(`Error importing resident ${row.email}:`, error);

            return {
              row: row.row,
              name: `${row.first_name} ${row.surname}`.trim(),
              email: row.email,
              unit: row.unit,
              status: "error",
              message:
                error instanceof Error && error.message
                  ? error.message
                  : t("clients.import.error.server"),
            };
          }
        }),
      );

      results.push(...batchResults);
    }

    const importedCount = results.filter(
      (result) => result.status === "success",
    ).length;

    if (importedCount > 0) {
      await Promise.allSettled([loadClients(), loadMetrics()]);
    }

    return results;
  };

  /* ================= RENDER ================= */
if (loading) {
  return (
    <DashboardLayout>
      <LoadingSpinner fullPage text={t("common.loading")} />
    </DashboardLayout>
  );
}
  return (
    <DashboardLayout>
      <div className="space-y-6">

        <ClientsHeader
          onUpload={() => setUploadModalOpen(true)}
          onAdd={() => setAddModalOpen(true)}
        />

        <ClientsStats stats={stats} />

        {chartData.length > 0 ? (
          <ClientsChart data={chartData} />
        ) : (
          <div className="h-[200px] flex items-center justify-center border rounded-md text-sm text-muted-foreground">
            {t("common.noDataAvailable")}
          </div>
        )}

        <ClientsTable
          clients={clients}
          loading={loading}
          onNavigate={(client) =>
            navigate(`/clients/${client.id_consumer}`, { state: { client } })
          }
          onEdit={(client) => {
            const tel = client.telephone || "";
            const codeMatch = tel.match(/^\+\d{1,3}/);
            const code  = codeMatch ? codeMatch[0] : "+52";
            const phone = tel.replace(code, "");

            setEditClient({
              id_user:     client.id_user,
              firstName:   client.userName.split(" ")[0] || "",
              lastName:    client.userName.split(" ").slice(1).join(" ") || "",
              id_unit:     client.id_unit,
              email:       client.email,
              countryCode: code,
              phone,
            });

            setEditModalOpen(true);
          }}
          onDelete={(id) => {
            const c = clients.find((x) => x.id === id);
            if (!c) return;
            setDeleteTarget(c);
            setDeleteModalOpen(true);
          }}
          onToggle={handleToggleRequest}
        />

      </div>

      {/* MODALS */}
      <UploadClientsModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
        unitsMap={unitsMap}
        onUpload={handleUploadArchive}
      />

      <DeleteClientModal
        open={deleteModalOpen}
        onOpenChange={setDeleteModalOpen}
        targetName={deleteTarget?.userName || ""}
        onConfirm={handleDeleteClient}
        t={t}
      />

      <ToggleConfirmModal
        data={toggleData}
        onClose={() => setToggleData((prev: any) => ({ ...prev, open: false }))}
        onConfirm={handleConfirmToggle}
        t={t}
      />

      <EditClientModal
        open={editModalOpen}
        onOpenChange={setEditModalOpen}
        client={editClient}
        onSave={handleEditClient}
        propertyId={propertyId}
        t={t}
      />

      <AddClientModal
        open={addModalOpen}
        onOpenChange={setAddModalOpen}
        propertyId={propertyId}
        t={t}
        onSave={handleCreateClient}
      />
    </DashboardLayout>
  );
}