import { useEffect, useState } from "react";
import { useNavigate, useLocation, useParams } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, Mail, Trash2, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { Column } from "@/components/ui/types";
import { GenericTable } from "@/components/ui/GenericTable";
import { clientsService } from "@/services/client.service";

/* ─── types ─── */
interface Resident {
  id_user:               number;
  id_consumer:           number;
  first_name:            string;
  surname:               string;
  main_tlf:              string;
  id_status:             number;
  first_login:           boolean | null;
  id_status_service_locker: number;
}

interface CompanyData {
  id_company:    number;
  id_propierty:  number;
  name_propierty: string;
  address?:      string;
  company_name?: string;
}

interface UnitData {
  id_unit:     number;
  number:      string;
  code?:       string;
}

/* ─────────────────────────────────────────────── */

export default function ResidentsPropertyPage() {
  const { t }    = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { id_company } = useParams<{ id_company: string }>();

  // State passed from CompanyDetail or Units
  const unit:        UnitData    = location.state?.unit;
  const isFrom:      string      = location.state?.page       || "CompanyDetail";
  const companyData: CompanyData = location.state?.companyData;

  const idUserType = user?.id_user_type ?? user?.data_company?.id_user_type;

  const [residents, setResidents] = useState<Resident[]>([]);
  const [loading, setLoading]     = useState(true);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  /* ─── fetch residents ─── */
  const fetchResidents = async () => {
    if (!companyData?.id_propierty) return;

    try {
      setLoading(true);

      const payload: any = {
        language:        localStorage.getItem("lang") || "es",
        filter_propierty: companyData.id_propierty,
        filter_company:  companyData.id_company,
      };

      if (unit?.id_unit) payload.by_id_unit = unit.id_unit;

      const res: any = await clientsService.queryClientsByProperty(payload);
      setResidents(res?.result_return || []);
    } catch (error) {
      console.error("Error loading residents:", error);
      toast.error(t("common.errorLoading") || "Error al cargar residentes");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResidents();
  }, [companyData?.id_propierty]);

  /* ─── delete resident ─── */
  const handleDelete = async (resident: Resident) => {
    try {
      setDeletingId(resident.id_user);
      await clientsService.updateConsumer({
        data_user: {
          id_user:      resident.id_user,
          to_propierty: companyData?.id_propierty,
          delete_user:  true,
        },
      });
      toast.success(t("residentsPage.deleted") || "Residente eliminado");
      fetchResidents();
    } catch (error) {
      toast.error(t("common.errorDeleting") || "Error al eliminar");
    } finally {
      setDeletingId(null);
    }
  };

  /* ─── resend email ─── */
  const handleResendEmail = async (resident: Resident) => {
    if (resident.first_login) return; // ya inició sesión, no reenviar

    try {
      const res: any = await (clientsService as any).resendEmailToUserNotLogged?.(resident.id_user);
      if (res?.mensaje_return?.CODE === 200) {
        toast.success(t("residentsPage.emailResent") || "Correo reenviado correctamente");
      }
    } catch (error) {
      toast.error(t("common.error") || "Error al reenviar correo");
    }
  };

  /* ─── breadcrumb back navigation ─── */
  const handleBack = () => {
    if (isFrom === "CompanyDetail") {
      navigate(`/company/${companyData?.id_company}`);
    } else if (isFrom === "units") {
      navigate("/units");
    } else {
      navigate(-1);
    }
  };

  /* ─── columns ─── */
  const columns: Column<Resident>[] = [
    {
      key: "first_name",
      header: t("residentsPage.table.first_name") || "Nombre",
      sortable: true,
      render: (row) => (
        <span className="font-medium text-sm">
          {row.first_name} {row.surname}
        </span>
      ),
    },
    {
      key: "main_tlf",
      header: t("residentsPage.table.main_tlf") || "Teléfono",
      sortable: false,
      render: (row) => (
        <span className="text-sm text-muted-foreground">{row.main_tlf || "—"}</span>
      ),
    },
    {
      key: "id_status",
      header: t("residentsPage.table.id_status") || "Estatus",
      sortable: true,
      render: (row) => {
        const isActive = row.id_status === 1;
        return (
          <Badge
            className={
              isActive
                ? "bg-success/10 text-success border-success/20"
                : "bg-muted text-muted-foreground border-border"
            }
          >
            {isActive
              ? t("common.active")   || "Activo"
              : t("common.inactive") || "Inactivo"}
          </Badge>
        );
      },
    },
    {
      key: "first_login",
      header: t("residentsPage.table.initial_access") || "Primer acceso",
      sortable: true,
      render: (row) => (
        <div className="flex items-center gap-1.5">
          {row.first_login ? (
            <>
              <CheckCircle2 className="h-4 w-4 text-success" />
              <span className="text-xs text-success">
                {t("residentsPage.hasLoggedIn") || "Sí"}
              </span>
            </>
          ) : (
            <>
              <XCircle className="h-4 w-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">
                {t("residentsPage.notLoggedIn") || "No"}
              </span>
            </>
          )}
        </div>
      ),
    },
    {
      key: "id_consumer",
      header: t("residentsPage.table.actions") || "Acciones",
      sortable: false,
      render: (row) => (
        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
          {/* RESEND EMAIL — solo si no ha iniciado sesión */}
          {!row.first_login && (
            <Button
              size="icon"
              variant="ghost"
              className="h-8 w-8 text-muted-foreground hover:text-primary"
              title={t("residentsPage.resendEmail") || "Reenviar correo"}
              onClick={() => handleResendEmail(row)}
            >
              <Mail className="h-4 w-4" />
            </Button>
          )}

          {/* DELETE */}
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8 text-destructive hover:bg-destructive/10"
            title={t("common.delete") || "Eliminar"}
            disabled={deletingId === row.id_user}
            onClick={() => handleDelete(row)}
          >
            {deletingId === row.id_user
              ? <div className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-destructive/30 border-t-destructive" />
              : <Trash2 className="h-4 w-4" />
            }
          </Button>
        </div>
      ),
    },
  ];

  /* ─── render ─── */
  return (
    <DashboardLayout>
      <div className="space-y-6">

        {/* HEADER */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleBack}>
              <ChevronLeft className="h-4 w-4" />
            </Button>

            <div>
              {/* BREADCRUMB */}
              <div className="flex items-center gap-1 text-xs text-muted-foreground mb-0.5 flex-wrap">
                {isFrom === "CompanyDetail" && idUserType === 1 && (
                  <>
                    <span className="cursor-pointer hover:text-foreground transition-colors" onClick={() => navigate("/company")}>
                      {t("unitsPage.breadcrumb.company") || "Compañía"}
                    </span>
                    <span>/</span>
                    <span className="cursor-pointer hover:text-foreground transition-colors" onClick={() => navigate(`/company/${companyData?.id_company}`)}>
                      {companyData?.name_propierty}
                    </span>
                    <span>/</span>
                  </>
                )}
                {isFrom === "units" && idUserType === 1 && (
                  <>
                    <span className="cursor-pointer hover:text-foreground transition-colors" onClick={() => navigate("/company")}>
                      {t("unitsPage.breadcrumb.company") || "Compañía"}
                    </span>
                    <span>/</span>
                    <span className="cursor-pointer hover:text-foreground transition-colors" onClick={() => navigate(`/company/${companyData?.id_company}`)}>
                      {companyData?.name_propierty}
                    </span>
                    <span>/</span>
                  </>
                )}
                {idUserType === 2 && (
                  <>
                    <span className="cursor-pointer hover:text-foreground transition-colors" onClick={() => navigate("/")}>
                      {t("unitsPage.breadcrumb.property") || "Propiedad"}
                    </span>
                    <span>/</span>
                  </>
                )}
                <span className="text-foreground">
                  {t("residentsPage.title") || "Residentes"}
                </span>
              </div>

              <h1 className="text-xl font-bold font-poppins">
                {t("residentsPage.title") || "Residentes"}
              </h1>

              {/* CONTEXT INFO */}
              <p className="text-xs text-muted-foreground mt-0.5">
                {companyData?.name_propierty}
                {unit?.number && ` · ${t("residentsPage.unit") || "Unidad"} ${unit.number}`}
              </p>
            </div>
          </div>
        </div>

        {/* LAYOUT: TABLE + INFO PANEL */}
        <div className="flex flex-col lg:flex-row gap-4 items-start">

          {/* TABLE */}
          <div className="w-full lg:flex-1 min-w-0">
            <GenericTable<Resident>
              data={residents}
              columns={columns}
              loading={loading}
              enableSearch
              enableDateRange={false}
              searchFields={["first_name", "surname", "main_tlf"]}
              defaultSort={{ key: "first_name", direction: "asc" }}
            />
          </div>

          {/* INFO PANEL */}
          <div className="w-full lg:w-[300px] shrink-0 space-y-4">

            {/* COMPANY INFO */}
            {companyData && (
              <div className="metric-card space-y-3">
                <p className="text-[13px] font-semibold font-poppins text-foreground">
                  {t("residentsPage.companyInfo") || "Información de propiedad"}
                </p>

                <div className="space-y-2 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">
                      {t("residentsPage.propertyName") || "Propiedad"}
                    </p>
                    <p className="font-medium text-foreground">{companyData.name_propierty}</p>
                  </div>

                  {companyData.address && (
                    <div>
                      <p className="text-xs text-muted-foreground">
                        {t("companyPage.table.address") || "Dirección"}
                      </p>
                      <p className="text-foreground text-xs leading-relaxed">{companyData.address}</p>
                    </div>
                  )}

                  <div className="pt-2 border-t border-border flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {t("residentsPage.totalResidents") || "Residentes"}
                    </span>
                    <span className="text-sm font-bold text-secondary">{residents.length}</span>
                  </div>
                </div>
              </div>
            )}

            {/* UNIT INFO */}
            {unit && isFrom === "units" && (
              <div className="metric-card space-y-3">
                <p className="text-[13px] font-semibold font-poppins text-foreground">
                  {t("residentsPage.unitInfo") || "Información de unidad"}
                </p>

                <div className="space-y-2 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">
                      {t("units.unitNumber") || "Unidad"}
                    </p>
                    <p className="font-medium text-foreground">{unit.number}</p>
                  </div>

                  {unit.code && (
                    <div>
                      <p className="text-xs text-muted-foreground">
                        {t("units.unitCode") || "Código"}
                      </p>
                      <p className="font-mono text-sm text-foreground">{unit.code}</p>
                    </div>
                  )}
                </div>
              </div>
            )}

          </div>
        </div>

      </div>
    </DashboardLayout>
  );
}