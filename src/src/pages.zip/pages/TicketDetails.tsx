import { useParams, useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useLanguage } from "@/contexts/LanguageContext";
import { useModel } from "@/contexts/ModelContext";
import { useState, useMemo } from "react";

// Components
import { TicketHeader } from "@/components/ticket-details/TicketHeader";
import { TicketDescription } from "@/components/ticket-details/TicketDescription";
import { TicketMessages } from "@/components/ticket-details/TicketMessages";
import { TicketSidebar } from "@/components/ticket-details/TicketSidebar";

import { Separator } from "@/components/ui/separator";
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  RefreshCcw,
  Loader2,
} from "lucide-react";

import { useTicketWithCache } from "@/hooks/useTicketWithCache";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";

/* =========================
   Helpers
========================= */

const isTicketOwner = (ticket: any, user: any) => {
  if (!ticket || !user) return false;
  const ticketUserId = String(ticket.client_information?.id_user);
  // ✅ Comparar contra todos los posibles campos de ID del usuario
  return (
    ticketUserId === String(user.id_user)     ||
    ticketUserId === String(user.id_consumer) ||
    ticketUserId === String(user.consumerId)
  );
};

const isClosedStatus = (status: string) => {
  return status === "CLOSED" || status === "ARCHIVED";
};

const mapStatusToKey = (status: string): string => {
  const statusMap: Record<string, string> = {
    OPEN: "open",
    IN_PROGRESS: "in_progress",
    REVIEW: "review",
    RESOLVED: "resolved",
    CLOSED: "closed",
    ARCHIVED: "archived",
  };
  return statusMap[status] || "open";
};

/* =========================
   COMPONENT
========================= */

export default function TicketDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const { currentModel } = useModel();
  const { toast } = useToast();
  const { user } = useAuth();

  const {
    ticket,
    loading,
    error,
    getFormattedMessages,
    refreshMessages,
    refreshTicket,
    updateTicketStatus,
    updateTicketPriority,
    sendMessage,
  } = useTicketWithCache(id);

  const [isManualRefreshing, setIsManualRefreshing] = useState(false);

  /* =========================
     Configs
  ========================= */

  const statusConfig = {
    open: {
      label: t("tickets.status.open"),
      className: "bg-warning/10 text-warning border-warning/20",
      icon: AlertTriangle,
    },
    in_progress: {
      label: t("tickets.status.in_progress"),
      className: "bg-info/10 text-info border-info/20",
      icon: Clock,
    },
    review: {
      label: t("tickets.status.review"),
      className: "bg-info/10 text-info border-info/20",
      icon: Clock,
    },
    resolved: {
      label: t("tickets.status.resolved"),
      className: "bg-success/10 text-success border-success/20",
      icon: CheckCircle2,
    },
    closed: {
      label: t("tickets.status.closed"),
      className: "bg-muted text-muted-foreground border-border",
      icon: CheckCircle2,
    },
    archived: {
      label: t("tickets.status.archived"),
      className: "bg-muted text-muted-foreground border-border",
      icon: CheckCircle2,
    },
  };

  const priorityConfig = {
    BAJA: {
      label: t("tickets.priority.low"),
      className: "bg-muted text-muted-foreground",
    },
    MEDIA: {
      label: t("tickets.priority.medium"),
      className: "bg-warning/10 text-warning",
    },
    ALTA: {
      label: t("tickets.priority.high"),
      className: "bg-destructive/10 text-destructive",
    },
    CRITICA: {
      label: t("tickets.priority.critical"),
      className: "bg-destructive text-destructive-foreground",
    },
  };

  const categoryLabels = {
    maintenance: t("tickets.category.maintenance"),
    technical: t("tickets.category.technical"),
    access: t("tickets.category.access"),
    billing: t("tickets.category.billing"),
    other: t("tickets.category.other"),
  };

  /* =========================
     Derived State
  ========================= */

  const isTicketClosed = isClosedStatus(ticket?.nombre_status);
  const isSupport =
    user?.user_type?.toUpperCase().includes("SOPORTE") === true;

    // ✅ Agregar esta helper junto a las otras
const isSupportAssigned = (ticket: any, user: any) => {
  if (!ticket || !user) return false;
  return String(ticket.id_user_propierty_support) === String(user.id_user_propierty_support);
};

  const truncateText = (value?: string | null, maxLength = 60) => {
  if (!value) return "N/A";

  const text = String(value).trim();

  if (text.length <= maxLength) return text;

  return `${text.slice(0, maxLength)}...`;
};

const canSendMessage =
  ticket && user
    ? (isTicketOwner(ticket, user) || (isSupport && isSupportAssigned(ticket, user))) && !isTicketClosed
    : false;

  const formattedMessages = getFormattedMessages();

const headerTicket = {
  id:
    ticket?.tracking_number_ticket ||
    ticket?.id_consumer_ticket?.toString() ||
    "N/A",
  title: truncateText(
    ticket?.title || t("ticketDetail.untitled"),
    60
  ),
  status: mapStatusToKey(ticket?.nombre_status || "OPEN"),
};

  /* =========================
     Handlers
  ========================= */

  const handleMessageSent = async () => {
    await refreshMessages();
  };

  const handleInternalNoteSent = async () => {
    await refreshMessages();
  };



  const handleManualRefresh = async () => {
    if (!id) return;

    setIsManualRefreshing(true);

    toast({
      title: "Actualizando",
      description: "Refrescando datos del ticket...",
    });

    try {
      await Promise.all([
        refreshTicket(),
        refreshMessages(),
      ]);

      toast({
        title: "Actualizado",
        description: "Datos actualizados correctamente",
      });
    } catch {
      toast({
        title: "Error",
        description: "No se pudo actualizar",
        variant: "destructive",
      });
    } finally {
      setIsManualRefreshing(false);
    }
  };

  const handleStatusChange = async (newStatus: string) => {
    if (!ticket) return;

    const success = await updateTicketStatus(newStatus);

    if (success) {
      toast({
        title: "Estado actualizado",
        description:
          statusConfig[newStatus.toLowerCase() as keyof typeof statusConfig]
            ?.label,
      });

      await refreshMessages();
    }
  };

  const handlePriorityChange = async (newPriority: string) => {
    if (!ticket) return;

    const success = await updateTicketPriority(newPriority);

    if (success) {
      toast({
        title: "Prioridad actualizada",
        description:
          priorityConfig[newPriority as keyof typeof priorityConfig]?.label,
      });
    }
  };

  /* =========================
     UI STATES
  ========================= */

  if (!ticket && loading) {
  return (
    <DashboardLayout>
      <LoadingSpinner fullPage text={t("common.loading")} />
    </DashboardLayout>
  );
  }

  if (error || !ticket) {
    return (
      <DashboardLayout>
        <div className="text-center">
          <AlertTriangle className="h-10 w-10 text-destructive mx-auto mb-3" />
          <p>{error || "Ticket no encontrado"}</p>
          <button onClick={() => navigate("/tickets")} className="mt-4">
            Volver
          </button>
        </div>
      </DashboardLayout>
    );
  }

  /* =========================
     RENDER
  ========================= */

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <TicketHeader
          ticket={headerTicket}
          statusConfig={statusConfig}
          currentModel={currentModel}
          navigate={navigate}
        />

        <div className="grid gap-5 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-5">
            <TicketDescription
              title={t("ticketDetail.description")}
              description={
                formattedMessages[0]?.content ||
                t("ticketDetail.noDescription")
              }
              maxLength={200}
            />

            <div className="metric-card space-y-4">
              <div className="flex justify-between items-center">
                <h3>{t("ticketDetail.messages")}</h3>

                <button
                  onClick={handleManualRefresh}
                  disabled={isManualRefreshing}
                  className="flex items-center gap-1 text-xs"
                >
                  {isManualRefreshing ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <RefreshCcw className="h-3 w-3" />
                  )}
                  {t("common.refresh")}
                </button>
              </div>

              <TicketMessages
                ticketId={ticket.id_consumer_ticket}
                messages={formattedMessages}
                onMessageSent={handleMessageSent}
                onInternalNoteSent={handleInternalNoteSent}
                canSendMessage={canSendMessage}
                sendMessage={sendMessage} // ✅ agregar
              />

              {isTicketClosed && (
                <div className="text-center py-4">
                  <Separator />
                  <p className="text-sm text-muted-foreground mt-4">
                    Ticket cerrado
                  </p>
                </div>
              )}
            </div>
          </div>

          <TicketSidebar
            ticket={ticket}
            statusConfig={statusConfig}
            priorityConfig={priorityConfig}
            categoryLabels={categoryLabels}
            t={t}
            onStatusChange={isSupport ? handleStatusChange : undefined}
            onPriorityChange={isSupport ? handlePriorityChange : undefined}
          />
        </div>
      </div>
    </DashboardLayout>
  );
}