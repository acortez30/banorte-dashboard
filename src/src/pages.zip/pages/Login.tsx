import { useEffect, useState, type FormEvent } from "react";
import { Eye, EyeOff, ShieldCheck, UserRoundCheck } from "lucide-react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import logo from "@/assets/logo_banorte_long.webp";
import { useAuth } from "@/contexts/AuthContext";
import { MOCK_PASSWORD } from "@/data/mockData";

export default function Login() {
  const { user, signIn } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const remembered = localStorage.getItem("banorte_remembered_email");
    if (remembered) setEmail(remembered);
  }, []);

  if (user) return <Navigate to={user.role === "SUPER_ADMIN" ? "/lockers" : "/employees"} replace />;

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setLoading(true);
    const result = await signIn(email, password);
    setLoading(false);
    if (!result.ok) {
      toast.error(result.error);
      return;
    }
    localStorage.setItem("banorte_remembered_email", email);
    navigate(result.user.role === "SUPER_ADMIN" ? "/lockers" : "/employees", { replace: true });
  };

  const fill = (type: "super" | "admin") => {
    setEmail(type === "super" ? "superadmin@vivipost.mock" : "admin@banorte.mock");
    setPassword(MOCK_PASSWORD);
  };

  return (
    <main className="min-h-screen bg-[#f6f6f7] lg:grid lg:grid-cols-[minmax(460px,.9fr)_minmax(520px,1.1fr)]">
      <section className="relative hidden overflow-hidden bg-sidebar-gradient p-10 text-white lg:flex lg:flex-col lg:justify-between xl:p-14">
        <div className="absolute -right-32 top-24 h-96 w-96 rounded-full border-[64px] border-white/[.035]" />
        <img src={logo} alt="Banorte" className="relative h-10 w-auto self-start brightness-0 invert" />
        <div className="relative max-w-lg">
          <p className="text-xs font-bold uppercase tracking-[.18em] text-white/[.65]">Banorte · Lockers</p>
          <h1 className="mt-4 font-poppins text-4xl font-bold leading-tight xl:text-5xl">Administración simple para islas y empleados.</h1>
          <p className="mt-5 max-w-md text-base leading-7 text-white/75">Mockup sin conexiones de servicios. Dos perfiles, permisos separados y control de capacidad por isla.</p>
        </div>
        <p className="relative text-xs text-white/50">Powered by Vivipost</p>
      </section>

      <section className="flex min-h-screen items-center justify-center px-5 py-10 sm:px-8 lg:min-h-0">
        <div className="w-full max-w-md">
          <img src={logo} alt="Banorte" className="mx-auto h-12 w-auto lg:hidden" />
          <div className="mt-8 lg:mt-0">
            <h2 className="font-poppins text-3xl font-bold tracking-tight text-foreground">Bienvenido</h2>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">Ingresa al dashboard de lockers Banorte.</p>
          </div>

          <form onSubmit={submit} className="mt-7 space-y-4">
            <label className="form-field"><span>Email</span><input className="form-input h-11" type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="usuario@empresa.com" required /></label>
            <label className="form-field">
              <span>Contraseña</span>
              <div className="relative"><input className="form-input h-11 pr-11" type={showPassword ? "text" : "password"} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="••••••••••" required /><button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" onClick={() => setShowPassword((value) => !value)} aria-label="Mostrar contraseña">{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button></div>
            </label>
            <div className="flex items-center justify-end"><Link to="/forgot-password" className="text-sm font-semibold text-primary hover:underline">¿Olvidaste tu contraseña?</Link></div>
            <button className="btn-primary h-11 w-full justify-center" disabled={loading}>{loading ? "Ingresando…" : "Iniciar sesión"}</button>
          </form>

          <div className="mt-7 rounded-2xl border border-border bg-card p-4 shadow-card">
            <p className="text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">Accesos de demostración</p>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              <button type="button" onClick={() => fill("super")} className="rounded-xl border border-border bg-background p-3 text-left transition hover:border-primary/35 hover:bg-primary/[.025]"><ShieldCheck size={18} className="text-primary" /><span className="mt-2 block text-sm font-semibold">Super administrador</span><span className="mt-0.5 block text-xs text-muted-foreground">Vivipost</span></button>
              <button type="button" onClick={() => fill("admin")} className="rounded-xl border border-border bg-background p-3 text-left transition hover:border-primary/35 hover:bg-primary/[.025]"><UserRoundCheck size={18} className="text-primary" /><span className="mt-2 block text-sm font-semibold">Administrador</span><span className="mt-0.5 block text-xs text-muted-foreground">Banorte</span></button>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">Contraseña mock: <strong className="text-foreground">{MOCK_PASSWORD}</strong></p>
          </div>
        </div>
      </section>
    </main>
  );
}
