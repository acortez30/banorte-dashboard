import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { useLanguage } from "@/contexts/LanguageContext";

import { useAdvertising } from "@/hooks/useAdvertising";

// 🧩 COMPONENTS
import { PendingAds } from "@/components/advertising/PendingAds";
import { OutletSelector } from "@/components/advertising/OutletSelector";
import { SlotManager } from "@/components/advertising/SlotManager";
import { ContentLibrary } from "@/components/advertising/ContentLibrary";

export default function Advertising() {
  const { t } = useLanguage();

  const {
    // state
    outlets,
    pendingAds,
    contentLibrary,
    selectedOutlet,
    contentFilter,

    // setters
    setSelectedOutlet,
    setContentFilter,

    // derived
    currentOutlet,
    filteredContent,

    // actions
    moveSlot,
    deleteSlot,
    addToSlot,
    approveAd,
    rejectAd,
    addContent,
    toggleContentActive,
    deleteContent,
  } = useAdvertising();

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* HEADER */}
        <DashboardHeader
          title={t("advertising.title")}
          subtitle={t("advertising.subtitle")}
        />

        {/* 🔔 PENDING ADS */}
        <PendingAds
          ads={pendingAds}
          onApprove={approveAd}
          onReject={rejectAd}
          t={t}
        />

        {/* 🖥️ OUTLET SELECTOR */}
        <OutletSelector
          outlets={outlets}
          selectedIndex={selectedOutlet}
          onSelect={setSelectedOutlet}
          t={t}
        />

        {/* 🎬 SLOT MANAGER */}
        <SlotManager
          outlet={currentOutlet}
          onMove={moveSlot}
          onDelete={deleteSlot}
          onAdd={addToSlot}
          t={t}
        />

        {/* 📚 CONTENT LIBRARY */}
        <ContentLibrary
          content={filteredContent}
          filter={contentFilter}
          onFilterChange={setContentFilter}
          onAddContent={addContent}
          onToggleActive={toggleContentActive}
          onDelete={deleteContent}
          t={t}
        />
      </div>
    </DashboardLayout>
  );
}