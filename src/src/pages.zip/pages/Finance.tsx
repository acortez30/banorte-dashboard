import { useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { useLanguage } from "@/contexts/LanguageContext";
import { DateRange } from "react-day-picker";
import { getStatusConfig, getTypeLabels, revenueData, sampleTransactions } from "@/data/finance.data";
import { useFinanceFilters } from "@/hooks/useFinanceFilters";
import { FinanceKpis } from "@/components/finance/FinanceKpis";
import { FinanceChart } from "@/components/finance/FinanceChart";
import { FinanceTable } from "@/components/finance/FinanceTable";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";

// 🧩 COMPONENTS


// 📦 DATA + HOOKS



export default function Finance() {
  const { t } = useLanguage();
    const [loading, setLoading]         = useState(false);

  // ===============================
  // 🧠 STATE
  // ===============================

  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | any>("all");
  const [dateRange, setDateRange] = useState<DateRange | undefined>();

  // ===============================
  // 🎯 CONFIG (i18n)
  // ===============================

  const statusConfig = getStatusConfig(t);
  const typeLabels = getTypeLabels(t);

  // ===============================
  // 🔍 FILTERED DATA
  // ===============================

  const filteredTransactions = useFinanceFilters({
    transactions: sampleTransactions,
    typeFilter,
    searchQuery,
    dateRange,
    sortBy: "date",
    sortDirection: "desc",
  });

  // ===============================
  // 🚀 HANDLERS
  // ===============================

  const handleRowClick = (row: any) => {

    // 🔥 futuro:
    // navigate(`/finance/${row.id}`);
  };

  const handleExportChart = () => {
    // 🔥 aquí puedes exportar a PNG / PDF
  };

  // ===============================
  // 🎨 RENDER
  // ===============================
  if (loading) {
    return (
      <DashboardLayout>
        <LoadingSpinner fullPage text={t("common.loading")} />
      </DashboardLayout>
    );
  }
  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* HEADER */}
        <DashboardHeader
          title={t("finance.title")}
          subtitle={t("finance.subtitle")}
        />

        {/* 💳 KPIs */}
        <FinanceKpis
          transactions={filteredTransactions}
          t={t}
        />

        {/* 📈 CHART */}
        <FinanceChart
          data={revenueData}
          t={t}
          dateRange={dateRange}
          onDateChange={setDateRange}
          onExport={handleExportChart}
        />

        {/* 📊 TABLE */}
        <FinanceTable
          data={filteredTransactions}
          t={t}
          statusConfig={statusConfig}
          typeLabels={typeLabels}
          onDateChange={setDateRange}
          onRowClick={handleRowClick}
        />
      </div>
    </DashboardLayout>
  );
}