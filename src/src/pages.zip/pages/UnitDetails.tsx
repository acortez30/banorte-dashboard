import {
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  useNavigate,
  useParams,
} from "react-router-dom";

import { toast } from "sonner";

import { DashboardLayout } from "@/components/layout/DashboardLayout";

import type { OrdersStatusTabValue } from "@/components/Orders/OrdersStatusTabs";

import { LoadingSpinner } from "@/components/ui/LoadingSpinner";

import { AddResidentDialog } from "@/components/units-details/dialog/AddResidentDialog";

import { DeleteResidentDialog } from "@/components/units-details/dialog/DeleteResidentDialog";

import { ResendEmailDialog } from "@/components/units-details/dialog/ResendEmailDialog";

import { PackagesSection } from "@/components/units-details/PackageSection";

import {
  type Resident,
  ResidentsSection,
} from "@/components/units-details/ResidentsSection";

import { UnitHeader } from "@/components/units-details/UnitHeader";

import { UnitMetrics } from "@/components/units-details/UnitMetrics";

import { useLanguage } from "@/contexts/LanguageContext";

import { clientsService } from "@/services/client.service";

import { notificationService } from "@/services/notification.service";

import {
  unitsService,
  type UnitPackageItem,
  type UnitPackagesStatusFilter,
} from "@/services/units.service";

import { usersService } from "@/services/users.service";

/* =============================== */
/* CONSTANTS                       */
/* =============================== */

const UNIT_PACKAGE_STATUSES: OrdersStatusTabValue[] =
  [
    "all",
    "in_progress",
    "expired",
    "completed",
  ];

/* =============================== */
/* HELPERS                         */
/* =============================== */

function getVisualStatus(
  pkg: UnitPackageItem,
  language: string,
) {
  const isSpanish =
    language !== "en";

  const statusKey =
    `${pkg.status_package}-${pkg.id_status_code_package}`;

  const statusName = String(
    pkg.name_status_package ??
      pkg.nombre_status_code_package ??
      "",
  )
    .trim()
    .toUpperCase();

  const codeStatusName = String(
    pkg.nombre_status_code_package ??
      "",
  )
    .trim()
    .toUpperCase();

  /* ---------- EXPIRED ---------- */

  if (
    statusKey === "14-32" ||
    statusName.includes(
      "VENCIDO",
    ) ||
    statusName.includes(
      "EXPIRED",
    ) ||
    codeStatusName.includes(
      "VENCIDO",
    )
  ) {
    return isSpanish
      ? "Expirado"
      : "Expired";
  }

  /* ---------- COMPLETED ---------- */

  if (
    statusKey === "16-18" ||
    statusName.includes(
      "ENTREGADO",
    ) ||
    statusName.includes(
      "COMPLETED",
    ) ||
    codeStatusName.includes(
      "UTILIZADO",
    )
  ) {
    return isSpanish
      ? "Completado"
      : "Completed";
  }

  /* ---------- IN LOCKER ---------- */

  if (
    [
      "14-17",
      "47-17",
      "57-17",
    ].includes(statusKey) ||
    statusName.includes(
      "IN_LOCKER",
    ) ||
    statusName.includes(
      "DISPONIBLE",
    )
  ) {
    return isSpanish
      ? "En Locker"
      : "In Locker";
  }

  /* ---------- IN TRANSIT ---------- */

  if (
    [
      "49-17",
      "53-17",
      "97-17",
      "117-17",
      "179-17",
    ].includes(statusKey) ||
    statusName.includes(
      "IN_TRANSIT",
    ) ||
    statusName.includes(
      "TRANSIT",
    ) ||
    statusName.includes(
      "ASSIGNED_CARRIER",
    ) ||
    statusName.includes(
      "WAREHOUSE",
    ) ||
    statusName.includes(
      "ALMACEN",
    ) ||
    statusName.includes(
      "ALMACÉN",
    ) ||
    statusName.includes(
      "CEDIS",
    )
  ) {
    return isSpanish
      ? "En tránsito"
      : "In transit";
  }

  /* ---------- FALLBACK ---------- */

  return (
    pkg.name_status_package ??
    pkg.nombre_status_code_package ??
    (
      isSpanish
        ? "En proceso"
        : "In progress"
    )
  );
}

function isExpiredPackage(
  pkg: UnitPackageItem,
) {
  const statusKey =
    `${pkg.status_package}-${pkg.id_status_code_package}`;

  const statusName = String(
    pkg.name_status_package ?? "",
  )
    .trim()
    .toUpperCase();

  const codeStatusName = String(
    pkg.nombre_status_code_package ??
      "",
  )
    .trim()
    .toUpperCase();

  return (
    statusKey === "14-32" ||
    statusName.includes(
      "EXPIRED",
    ) ||
    statusName.includes(
      "VENCIDO",
    ) ||
    codeStatusName.includes(
      "VENCIDO",
    )
  );
}

function formatDate(
  value: string | null,
  language: string,
) {
  if (!value) {
    return "—";
  }

  const date = new Date(value);

  if (
    Number.isNaN(
      date.getTime(),
    )
  ) {
    return "—";
  }

  return date.toLocaleDateString(
    language === "en"
      ? "en-US"
      : "es-MX",
  );
}

/* =============================== */
/* COMPONENT                       */
/* =============================== */

export default function UnitDetails() {
  const navigate =
    useNavigate();

  const {
    t,
    language,
  } = useLanguage();

  const {
    idUnit,
  } = useParams<{
    idUnit: string;
  }>();

  /* ============================= */
  /* UNIT STATE                    */
  /* ============================= */

  const [
    unit,
    setUnit,
  ] = useState<any>(null);

  const [
    loading,
    setLoading,
  ] = useState(true);

  /* ============================= */
  /* PACKAGES STATE                */
  /* ============================= */

  const [
    packages,
    setPackages,
  ] = useState<any[]>([]);

  const [
    packagesLoading,
    setPackagesLoading,
  ] = useState(false);

  const [
    activePackageStatus,
    setActivePackageStatus,
  ] =
    useState<OrdersStatusTabValue>(
      "all",
    );

  const [
    packagePage,
    setPackagePage,
  ] = useState(1);

  const [
    packagePageSize,
    setPackagePageSize,
  ] =
    useState("10");

  const [
    packageTotal,
    setPackageTotal,
  ] = useState(0);

  const [
    packageTotalPages,
    setPackageTotalPages,
  ] = useState(1);

  /* ============================= */
  /* RESIDENT STATE               */
  /* ============================= */

  const [
    searchQuery,
    setSearchQuery,
  ] = useState("");

  const [
    resultsPerPage,
    setResultsPerPage,
  ] = useState("10");

  const [
    addClientOpen,
    setAddClientOpen,
  ] = useState(false);

  const [
    addLoading,
    setAddLoading,
  ] = useState(false);

  const [
    emailModalOpen,
    setEmailModalOpen,
  ] = useState(false);

  const [
    emailLoading,
    setEmailLoading,
  ] = useState(false);

  const [
    emailTarget,
    setEmailTarget,
  ] = useState<{
    id: string;
    name: string;
    email: string;
  }>({
    id: "",
    name: "",
    email: "",
  });

  const [
    deleteModalOpen,
    setDeleteModalOpen,
  ] = useState(false);

  const [
    deleteLoading,
    setDeleteLoading,
  ] = useState(false);

  const [
    deleteTarget,
    setDeleteTarget,
  ] = useState({
    id: "",
    name: "",
  });

  /* ============================= */
  /* COMPANY / PROPERTY            */
  /* ============================= */

  const companyData =
    useMemo(() => {
      try {
        return JSON.parse(
          localStorage.getItem(
            "company",
          ) || "{}",
        );
      } catch {
        return {};
      }
    }, []);

  const propertyId =
    companyData?.id_propierty;

  const propertyInfo = {
    name:
      companyData?.company_name ||
      "—",

    address:
      companyData?.address ||
      "—",

    type:
      companyData?.company_type ||
      "—",

    code:
      companyData?.code_propierty ||
      "—",

    description:
      "—",
  };

  /* ============================= */
  /* RESIDENT FILTER               */
  /* ============================= */

  const filteredResidents =
    useMemo(() => {
      if (
        !unit?.residents
      ) {
        return [];
      }

      const normalizedSearch =
        searchQuery
          .trim()
          .toLowerCase();

      if (!normalizedSearch) {
        return unit.residents;
      }

      return unit.residents.filter(
        (
          resident: Resident,
        ) => {
          const name =
            resident.name ??
            "";

          const phone =
            resident.phone ??
            "";

          const email =
            resident.email ??
            "";

          return (
            name
              .toLowerCase()
              .includes(
                normalizedSearch,
              ) ||
            phone.includes(
              searchQuery,
            ) ||
            email
              .toLowerCase()
              .includes(
                normalizedSearch,
              )
          );
        },
      );
    }, [
      unit,
      searchQuery,
    ]);

  /* ============================= */
  /* RESIDENT ACTIONS              */
  /* ============================= */

  const handleOpenEmail = (
    resident: Resident,
  ) => {
    setEmailTarget({
      id:
        resident.id,

      name:
        resident.name,

      email:
        resident.email,
    });

    setEmailModalOpen(true);
  };

  const handleOpenDelete = (
    residentId: string,
    residentName: string,
  ) => {
    setDeleteTarget({
      id: residentId,
      name: residentName,
    });

    setDeleteModalOpen(true);
  };

  /* ============================= */
  /* LOAD UNIT                     */
  /* ============================= */

  useEffect(() => {
    if (
      !propertyId ||
      !idUnit
    ) {
      return;
    }

    let cancelled = false;

    const fetchUnit =
      async () => {
        try {
          setLoading(true);

          const response =
            await unitsService.getUnit(
              Number(
                propertyId,
              ),
              idUnit,
            );

          if (!cancelled) {
            setUnit(
              response,
            );
          }
        } catch (error) {
          if (!cancelled) {
            console.error(
              "[UnitDetails] Error loading unit:",
              error,
            );

            toast.error(
              "Error al cargar unidad",
            );
          }
        } finally {
          if (!cancelled) {
            setLoading(false);
          }
        }
      };

    void fetchUnit();

    return () => {
      cancelled = true;
    };
  }, [
    propertyId,
    idUnit,
  ]);

  /* ============================= */
  /* LOAD UNIT PACKAGES            */
  /* ============================= */

  useEffect(() => {
    /*
     * IMPORTANTE:
     *
     * idUnit es el id interno de la unidad.
     *
     * Este endpoint necesita
     * unit.number.
     *
     * Ejemplo:
     *
     * route:
     * /units/343
     *
     * unit.number:
     * 742
     *
     * request:
     * /properties/5/units/742/packages
     */

    if (
      !propertyId ||
      !unit?.number
    ) {
      return;
    }

    if (
      !UNIT_PACKAGE_STATUSES.includes(
        activePackageStatus,
      )
    ) {
      return;
    }

    let cancelled = false;

    const fetchPackages =
      async () => {
        try {
          setPackagesLoading(
            true,
          );

          const response =
            await unitsService.getUnitPackages(
              propertyId,
              unit.number,
              {
                page:
                  packagePage,

                limit:
                  Number(
                    packagePageSize,
                  ) || 10,

                status_filter:
                  activePackageStatus as UnitPackagesStatusFilter,

                language:
                  language ||
                  "es",
              },
            );

          if (cancelled) {
            return;
          }

          const responseCode =
            Number(
              response
                ?.mensaje_return
                ?.CODE,
            );

          const rawPackages =
            responseCode === 1103
              ? []
              : Array.isArray(
                    response
                      ?.return_result,
                  )
                ? response.return_result
                : [];

          const formattedPackages =
            rawPackages.map(
              (
                pkg: UnitPackageItem,
              ) => ({
                id:
                  String(
                    pkg.id_package ??
                      pkg.id_service ??
                      pkg.tracking_number ??
                      "",
                  ),

                tracking:
                  pkg.tracking_number ??
                  "—",

                carrier:
                  pkg.name_service ??
                  (
                    pkg.id_locker
                      ? "LOCKER"
                      : "—"
                  ),

                date:
                  formatDate(
                    pkg.package_delivery_date,
                    language ||
                      "es",
                  ),

                status:
                  getVisualStatus(
                    pkg,
                    language ||
                      "es",
                  ),

                expirationDate:
                  pkg.expiration_date ??
                  null,

                isExpired:
                  isExpiredPackage(
                    pkg,
                  ),

                recipient:
                  `${pkg.first_name ?? ""} ${
                    pkg.surname ?? ""
                  }`.trim() ||
                  "—",

                idPackage:
                  pkg.id_package,

                idService:
                  pkg.id_service,

                locker:
                  pkg.locker_name ??
                  "—",

                door:
                  pkg.door_number,

                compartment:
                  pkg.compartment_name,

                pickupDate:
                  pkg.package_pickup_date,

                extendedPackage:
                  pkg.extended_package ??
                  0,

                raw:
                  pkg,
              }),
            );

          setPackages(
            formattedPackages,
          );

          const total =
            Number(
              response
                ?.pagination
                ?.total,
            );

          const totalPages =
            Number(
              response
                ?.pagination
                ?.total_pages,
            );

          const safeTotal =
            Number.isFinite(
              total,
            )
              ? Math.max(
                  0,
                  total,
                )
              : formattedPackages.length;

          const safeTotalPages =
            Number.isFinite(
              totalPages,
            ) &&
            totalPages > 0
              ? totalPages
              : Math.max(
                  1,
                  Math.ceil(
                    safeTotal /
                      Math.max(
                        1,
                        Number(
                          packagePageSize,
                        ) ||
                          10,
                      ),
                  ),
                );

          setPackageTotal(
            safeTotal,
          );

          setPackageTotalPages(
            safeTotalPages,
          );

          if (
            packagePage >
            safeTotalPages
          ) {
            setPackagePage(
              safeTotalPages,
            );
          }
        } catch (error) {
          if (cancelled) {
            return;
          }

          console.error(
            "[UnitDetails] Error loading unit packages:",
            error,
          );

          setPackages([]);

          setPackageTotal(0);

          setPackageTotalPages(
            1,
          );

          toast.error(
            "Error al cargar paquetes de la unidad",
          );
        } finally {
          if (!cancelled) {
            setPackagesLoading(
              false,
            );
          }
        }
      };

    void fetchPackages();

    return () => {
      cancelled = true;
    };
  }, [
    activePackageStatus,

    language,

    packagePage,
    packagePageSize,

    propertyId,

    unit?.number,
  ]);

  /* ============================= */
  /* PACKAGE STATUS CHANGE         */
  /* ============================= */

  const handlePackageStatusChange =
    (
      status:
        OrdersStatusTabValue,
    ) => {
      if (
        !UNIT_PACKAGE_STATUSES.includes(
          status,
        )
      ) {
        return;
      }

      setActivePackageStatus(
        status,
      );

      setPackagePage(1);
    };

  /* ============================= */
  /* LOADING                       */
  /* ============================= */

  if (
    loading ||
    !unit
  ) {
    return (
      <DashboardLayout>
        <LoadingSpinner
          fullPage
          text={t(
            "common.loading",
          )}
        />
      </DashboardLayout>
    );
  }

  /* ============================= */
  /* RENDER                        */
  /* ============================= */

  return (
    <DashboardLayout>
      <div className="space-y-5">
        {/* UNIT HEADER */}

        <UnitHeader
          unit={unit}
          property={
            propertyInfo
          }
          onBack={() =>
            navigate(
              "/units",
            )
          }
          isActive
        />

        {/* METRICS */}

        <UnitMetrics
          residents={
            unit.residents ??
            []
          }
          packagesThisMonth={
            unit.packagesMonth ??
            0
          }
          accessCode={
            unit.code
          }
        />

        {/* RESIDENTS */}

        <ResidentsSection
          residents={
            filteredResidents
          }
          searchQuery={
            searchQuery
          }
          resultsPerPage={
            resultsPerPage
          }
          onSearchChange={
            setSearchQuery
          }
          onResultsChange={
            setResultsPerPage
          }
          onAddResident={() =>
            setAddClientOpen(
              true,
            )
          }
          onResendEmail={
            handleOpenEmail
          }
          onDeleteResident={(
            resident,
          ) =>
            handleOpenDelete(
              resident.id,
              resident.name,
            )
          }
        />

        {/* PACKAGES */}

        <PackagesSection
          packages={
            packages
          }

          activeStatus={
            activePackageStatus
          }

          onStatusChange={
            handlePackageStatusChange
          }

          allowedStatuses={
            UNIT_PACKAGE_STATUSES
          }

          onResetFilters={() => {
            setActivePackageStatus(
              "all",
            );

            setPackagePage(
              1,
            );
          }}

          page={
            packagePage
          }

          pageSize={
            packagePageSize
          }

          total={
            packageTotal
          }

          totalPages={
            packageTotalPages
          }

          loading={
            packagesLoading
          }

          onPageChange={
            setPackagePage
          }

          onPageSizeChange={(
            value,
          ) => {
            setPackagePageSize(
              value,
            );

            setPackagePage(
              1,
            );
          }}
        />
      </div>

      {/* ============================= */}
      {/* ADD RESIDENT                  */}
      {/* ============================= */}

      <AddResidentDialog
        open={
          addClientOpen
        }

        unitNumber={
          unit.number
        }

        loading={
          addLoading
        }

        onClose={() =>
          setAddClientOpen(
            false,
          )
        }

        onSubmit={async (
          data,
        ) => {
          try {
            if (
              !propertyId ||
              !idUnit
            ) {
              return;
            }

            setAddLoading(
              true,
            );

            await clientsService.registerConsumerFromUnit(
              Number(
                propertyId,
              ),
              Number(
                idUnit,
              ),
              data,
            );

            const updatedUnit =
              await unitsService.getUnit(
                Number(
                  propertyId,
                ),
                idUnit,
              );

            setUnit(
              updatedUnit,
            );

            toast.success(
              t(
                "unitDetail.clientAdded",
              ),
            );

            setAddClientOpen(
              false,
            );
          } catch (error) {
            console.error(
              "[UnitDetails] Error adding resident:",
              error,
            );

            toast.error(
              "Error al registrar cliente",
            );
          } finally {
            setAddLoading(
              false,
            );
          }
        }}
      />

      {/* ============================= */}
      {/* RESEND EMAIL                  */}
      {/* ============================= */}

      <ResendEmailDialog
        open={
          emailModalOpen
        }

        residentName={
          emailTarget.name
        }

        residentEmail={
          emailTarget.email
        }

        loading={
          emailLoading
        }

        onClose={() =>
          setEmailModalOpen(
            false,
          )
        }

        onConfirm={async () => {
          try {
            setEmailLoading(
              true,
            );

            await notificationService.resendEmailToUserNotLogged(
              emailTarget.id,
            );

            toast.success(
              "Email reenviado correctamente",
            );

            setEmailModalOpen(
              false,
            );
          } catch (error) {
            console.error(
              "[UnitDetails] Error resending email:",
              error,
            );

            toast.error(
              "Error al reenviar email",
            );
          } finally {
            setEmailLoading(
              false,
            );
          }
        }}
      />

      {/* ============================= */}
      {/* DELETE RESIDENT               */}
      {/* ============================= */}

      <DeleteResidentDialog
        open={
          deleteModalOpen
        }

        residentName={
          deleteTarget.name
        }

        loading={
          deleteLoading
        }

        requirePassword={
          false
        }

        onClose={() =>
          setDeleteModalOpen(
            false,
          )
        }

        onConfirm={async () => {
          try {
            if (
              !propertyId ||
              !idUnit
            ) {
              return;
            }

            setDeleteLoading(
              true,
            );

            await usersService.deleteUserFromProperty(
              Number(
                deleteTarget.id,
              ),
              Number(
                propertyId,
              ),
            );

            const updatedUnit =
              await unitsService.getUnit(
                Number(
                  propertyId,
                ),
                idUnit,
              );

            setUnit(
              updatedUnit,
            );

            toast.success(
              t(
                "unitDetail.clientDeleted",
              ),
            );

            setDeleteModalOpen(
              false,
            );
          } catch (error) {
            console.error(
              "[UnitDetails] Error deleting resident:",
              error,
            );

            toast.error(
              "Error al eliminar residente",
            );
          } finally {
            setDeleteLoading(
              false,
            );
          }
        }}
      />
    </DashboardLayout>
  );
}