import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, X, Building2, MapPin, CheckCircle2 } from "lucide-react";
import { Column } from "@/components/ui/types";
import { GenericTable } from "@/components/ui/GenericTable";
import { companyService } from "@/services/company.service";
import GoogleMapLockers from "@/components/ui/GoogleMapLocker";
import { format, parseISO } from "date-fns";
import { es } from "date-fns/locale";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";

/* ─── types ─── */
interface Company {
  id_company:              number;
  company_name:            string;
  address:                 string;
  company_type:            string;
  trfc:                    string;
  phone_number:            string;
  id_status:               number;
  registration_date:       string;
  map_lat_center_point:    string;
  map_length_center_point: string;
}

/* ─── helpers ─── */
const formatDate = (dateStr: string) => {
  if (!dateStr) return "—";
  try {
    return format(parseISO(dateStr), "dd MMM yyyy, HH:mm", { locale: es });
  } catch {
    return dateStr;
  }
};

/* ─────────────────────────────────────────────── */

export default function CompanyPage() {
  const { t }    = useLanguage();
  const navigate = useNavigate();

  const [companies, setCompanies]             = useState<Company[]>([]);
  const [loading, setLoading]                 = useState(true);
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);

  /* ─── fetch ─── */
  useEffect(() => {
    const fetchCompanies = async () => {
      try {
        setLoading(true);
        const res  = await companyService.getCompany();
        const data = Array.isArray(res.companies) ? res.companies : [res.companies];
        setCompanies(data);
      } catch (error) {
        console.error("Error loading companies:", error);
        setCompanies([]);
      } finally {
        setLoading(false);
      }
    };
    fetchCompanies();
  }, []);

  const activeCount = companies.filter((c) => c.id_status === 1).length;

  /* ─── badge ─── */
  const getStatusBadge = (id_status: number) => {
    const isActive = id_status === 1;
    return (
      <Badge
        className={
          isActive
            ? "bg-success/10 text-success border-success/20"
            : "bg-warning/10 text-warning border-warning/20"
        }
      >
        {isActive ? t("common.active") || "Activo" : t("common.inactive") || "Inactivo"}
      </Badge>
    );
  };

  /* ─── columns ─── */
  const columns: Column<Company>[] = [
    {
      key: "company_name",
      header: t("companyPage.table.company_name") || "Nombre de compañía",
      sortable: true,
      render: (row) => (
        <span
          className="text-primary font-medium cursor-pointer hover:underline"
          onClick={(e) => { e.stopPropagation(); navigate(`/company/${row.id_company}`); }}
        >
          {row.company_name}
        </span>
      ),
    },
    {
      key: "address",
      header: t("companyPage.table.address") || "Dirección",
      sortable: true,
      render: (row) => (
        <span className="text-sm text-muted-foreground max-w-[380px] truncate block">
          {row.address}
        </span>
      ),
    },
    {
      key: "company_type",
      header: t("companyPage.table.company_type") || "Tipo",
      sortable: true,
      render: (row) => <span className="text-sm">{row.company_type}</span>,
    },
    {
      key: "trfc",
      header: t("companyPage.table.trfc") || "RFC",
      sortable: true,
      render: (row) => <span className="text-sm font-mono">{row.trfc || "—"}</span>,
    },
    {
      key: "phone_number",
      header: t("companyPage.table.phone_number") || "Teléfono",
      sortable: false,
      render: (row) => (
        <span className="text-sm text-muted-foreground">{row.phone_number || "—"}</span>
      ),
    },
    {
      key: "id_status",
      header: t("companyPage.table.status") || "Estatus",
      sortable: true,
      render: (row) => getStatusBadge(row.id_status),
    },
    {
      key: "registration_date",
      header: t("companyPage.table.registration_date") || "Fecha de registro",
      sortable: true,
      render: (row) => (
        <span className="text-sm text-muted-foreground">{formatDate(row.registration_date)}</span>
      ),
    },
  ];

  /* ─── map lockers shape ─── */
  const mapLockers = companies.map((c) => ({
    description:    c.company_name,
    locker_address: c.address,
    latitud:        parseFloat(c.map_lat_center_point),
    longitud:       parseFloat(c.map_length_center_point),
  }));

  if (loading) {
    return (
      <DashboardLayout>
        <LoadingSpinner fullPage text={t("common.loading")} />
      </DashboardLayout>
    );
  }

  /* ─── render ─── */
  return (
    <DashboardLayout>
      <div className="space-y-6">

        {/* HEADER */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold font-poppins sm:text-2xl">
              {t("companyPage.title") || "Compañía"}
            </h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              {t("companyPage.subtitle") || "Gestiona las compañías del sistema"}
            </p>
          </div>

          <Button onClick={() => navigate("/company/add")} className="gap-2">
            <Plus className="h-4 w-4" />
            {t("companyPage.buttons.add_company") || "Agregar compañía"}
          </Button>
        </div>

        {/* COUNTER + MAP */}
        <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] gap-4 items-stretch">

          {/* COUNTER CARD */}
          <div className="metric-card flex flex-col gap-4">

            <p className="text-[13px] font-semibold font-poppins text-foreground">
              {t("companyPage.totalCompanies") || "Compañías"}
            </p>

            {/* BIG NUMBER */}
            <div className="flex-1 flex flex-col justify-center">
              <p className="text-[64px] font-bold font-poppins text-secondary leading-none">
                {loading ? "—" : companies.length}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                {t("companyPage.totalCompanies") || "Compañías"}
              </p>
            </div>

            {/* ACTIVE COUNT */}
            <div className="flex items-center gap-2 pt-3 border-t border-border">
              <CheckCircle2 className="h-4 w-4 text-success shrink-0" />
              <span className="text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">{activeCount}</span>{" "}
                {t("common.active") || "Activo"}
              </span>
            </div>
          </div>

          {/* MAP */}
          <div className="metric-card relative overflow-hidden p-0">

            <div className="px-4 py-3 border-b border-border">
              <p className="text-[13px] font-semibold font-poppins text-foreground">
                {t("companyPage.mapTitle") || "Ubicación de compañías"}
              </p>
            </div>

            <div className="h-[380px]">
              <GoogleMapLockers lockers={mapLockers} />
            </div>

            {/* SELECTED COMPANY POPUP */}
            {selectedCompany && (
              <div className="absolute bottom-4 right-4 z-10 w-72 bg-card border border-border rounded-xl shadow-elevated p-3 animate-fade-in">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <p className="text-xs font-semibold text-foreground">
                    {t("companyPage.companyDetails") || "Detalles de la compañía"}
                  </p>
                  <button
                    onClick={() => setSelectedCompany(null)}
                    className="text-muted-foreground hover:text-foreground transition-colors shrink-0"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>

                <p className="text-sm font-semibold text-foreground">
                  {selectedCompany.company_name}
                </p>

                <div className="flex items-start gap-1.5 mt-1.5">
                  <MapPin className="h-3 w-3 text-muted-foreground mt-0.5 shrink-0" />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {selectedCompany.address}
                  </p>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  {getStatusBadge(selectedCompany.id_status)}
                  <span className="text-xs text-muted-foreground">
                    {selectedCompany.company_type}
                  </span>
                </div>

                <Button
                  size="sm"
                  variant="outline"
                  className="w-full mt-3 h-7 text-xs"
                  onClick={() => navigate(`/company/${selectedCompany.id_company}`)}
                >
                  Ver detalle
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* TABLE */}
        <GenericTable<Company>
          data={companies}
          columns={columns}
          loading={loading}
          enableSearch
          enableDateRange={false}
          searchFields={["company_name", "address", "company_type", "trfc"]}
          defaultSort={{ key: "registration_date", direction: "desc" }}
          onRowClick={(row) => setSelectedCompany(row)}
        />

      </div>
    </DashboardLayout>
  );
}