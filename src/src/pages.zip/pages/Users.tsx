import { useMemo, useState } from "react";
import { Pencil, Plus, Search, ShieldCheck, UserRoundCheck, UsersRound } from "lucide-react";
import { toast } from "sonner";
import DashboardLayout from "@/components/layout/DashboardLayout";
import PageHeader from "@/components/common/PageHeader";
import MetricCard from "@/components/common/MetricCard";
import ToggleSwitch from "@/components/common/ToggleSwitch";
import TablePagination from "@/components/common/TablePagination";
import UserFormDialog from "@/components/users/UserFormDialog";
import { useAuth } from "@/contexts/AuthContext";
import { useData } from "@/contexts/DataContext";
import type { DashboardUser } from "@/types/dashboard";

const dateFormatter = new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "short", year: "numeric" });

export default function Users() {
  const { user: sessionUser } = useAuth();
  const { users, addUser, updateUser, toggleUser } = useData();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<DashboardUser | null>(null);

  const isSuper = sessionUser?.role === "SUPER_ADMIN";
  const visibleUsers = useMemo(() => users.filter((item) => isSuper || (item.role === "ADMIN" && item.organization === "Banorte")), [isSuper, users]);
  const filtered = visibleUsers.filter((item) => `${item.name} ${item.email} ${item.role}`.toLowerCase().includes(search.toLowerCase()));
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize);

  const admins = visibleUsers.filter((item) => item.role === "ADMIN");
  const supers = visibleUsers.filter((item) => item.role === "SUPER_ADMIN");

  return (
    <DashboardLayout>
      <div className="space-y-5 animate-fade-in">
        <PageHeader
          title="Usuarios"
          description={isSuper ? "Gestiona administradores Banorte y super administradores Vivipost." : "Consulta y administra únicamente los usuarios administradores de Banorte."}
          actions={isSuper ? <button className="btn-primary" onClick={() => { setEditing(null); setFormOpen(true); }}><Plus size={17} /> Nuevo usuario</button> : undefined}
        />

        <div className={`grid gap-3 sm:grid-cols-2 ${isSuper ? "xl:grid-cols-3" : "xl:grid-cols-2"}`}>
          <MetricCard label="Usuarios visibles" value={visibleUsers.length} helper={`${visibleUsers.filter((item) => item.active).length} activos`} icon={UsersRound} />
          <MetricCard label="Administradores Banorte" value={admins.length} helper={`${admins.filter((item) => item.active).length} con acceso`} icon={UserRoundCheck} />
          {isSuper ? <MetricCard label="Super administradores" value={supers.length} helper="Usuarios Vivipost" icon={ShieldCheck} /> : null}
        </div>

        <section className="table-shell">
          <div className="table-toolbar">
            <div className="relative w-full max-w-sm"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={16} /><input className="form-input h-10 pl-9" value={search} onChange={(event) => { setSearch(event.target.value); setPage(1); }} placeholder="Buscar nombre o correo" /></div>
            {!isSuper ? <p className="text-xs font-medium text-muted-foreground">Los super administradores Vivipost no son visibles para este rol.</p> : null}
          </div>
          <div className="overflow-x-auto">
            <table className={`data-table ${isSuper ? "min-w-[950px]" : "min-w-[820px]"}`}>
              <thead><tr><th>Nombre</th><th>Email</th>{isSuper ? <th>Rol</th> : null}<th>Fecha de registro</th><th>Ingreso al dashboard</th><th className="text-right">Acción</th></tr></thead>
              <tbody>
                {paginated.map((item) => (
                  <tr key={item.id}>
                    <td className="font-semibold text-foreground">{item.name}</td>
                    <td>{item.email}</td>
                    {isSuper ? <td><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${item.role === "SUPER_ADMIN" ? "bg-primary/10 text-primary" : "bg-slate-100 text-slate-700"}`}>{item.role === "SUPER_ADMIN" ? "Super administrador" : "Administrador"}</span></td> : null}
                    <td>{dateFormatter.format(new Date(item.registeredAt))}</td>
                    <td><ToggleSwitch checked={item.active} onChange={(active) => { toggleUser(item.id, active); toast.success(active ? "Acceso activado" : "Acceso desactivado"); }} label={`Cambiar acceso de ${item.name}`} /></td>
                    <td className="text-right"><button className="icon-action" onClick={() => { setEditing(item); setFormOpen(true); }} aria-label={`Editar ${item.name}`}><Pencil size={16} /></button></td>
                  </tr>
                ))}
                {!paginated.length ? <tr><td colSpan={isSuper ? 6 : 5} className="py-12 text-center text-muted-foreground">No se encontraron usuarios.</td></tr> : null}
              </tbody>
            </table>
          </div>
          <TablePagination page={page} pageSize={pageSize} total={filtered.length} onPageChange={setPage} onPageSizeChange={(size) => { setPageSize(size); setPage(1); }} />
        </section>
      </div>

      <UserFormDialog
        open={formOpen}
        onClose={() => setFormOpen(false)}
        user={editing}
        allowRoleSelection={isSuper}
        onSubmit={(value) => {
          if (!isSuper && value.role !== "ADMIN") return { ok: false, error: "Este rol solo puede administrar usuarios Banorte." };
          const result = editing ? updateUser(editing.id, value) : addUser(value);
          if (result.ok) toast.success(editing ? "Usuario actualizado" : "Usuario creado");
          return result;
        }}
      />
    </DashboardLayout>
  );
}
