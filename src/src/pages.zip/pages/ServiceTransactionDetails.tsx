// pages/transactions/ServiceTransactionDetails.tsx

import {
  useCallback,
  useEffect,
  useState,
  type ElementType,
  type ReactNode,
} from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import QRCode from "react-qr-code";
import {
  AlertCircle,
  ArrowLeft,
  Bell,
  Box,
  Calendar,
  Camera,
  CheckCircle,
  ChevronDown,
  Clock,
  Hash,
  Key,
  Layers,
  Mail,
  MapPin,
  Package,
  Phone,
  Play,
  RefreshCw,
} from "lucide-react";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLanguage } from "@/contexts/LanguageContext";
import { orderDetailService } from "@/services/orderDetail.service";
import { mapOrderDetail } from "@/utils/orderDetail.mapper";
import type { OrderDetail, OrderStatus } from "@/types/orders.types";
import type { Language } from "@/i18n";
import { KpiGrid } from "@/components/dashboard/KpiGrid";
import { KpiCard } from "@/components/dashboard/KpiCard";

// ============================================================================
// TYPES
// ============================================================================

type TranslateFn = (
  key: string,
  params?: Record<string, string | number>
) => string;

type LocalizedText = Record<Language, string>;

// ============================================================================
// HELPERS
// ============================================================================

function tx(
  t: TranslateFn,
  language: Language,
  key: string,
  fallback: LocalizedText
): string {
  const translated = t(key);

  if (!translated || translated === key) {
    return fallback[language];
  }

  return translated;
}

function fmtDate(value?: string | null, language: Language = "es", fallback = "—") {
  if (!value || value === "---") return fallback;

  const parsed = new Date(value);

  if (Number.isNaN(parsed.getTime())) {
    return value;
  }

  return parsed.toLocaleString(language === "en" ? "en-US" : "es-MX", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function cleanDisplayValue(value?: string | null, fallback = "---") {
  if (
    value === null ||
    value === undefined ||
    value === "" ||
    value === "false" ||
    value === "null" ||
    value === "undefined"
  ) {
    return fallback;
  }

  return value;
}

function prettifyTimelineKey(key: string) {
  const raw = key.replace("orderDetail.title.", "");

  return raw
    .split("_")
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");
}

// ============================================================================
// STATUS CONFIGURATION
// ============================================================================

const statusBadgeClass: Record<OrderStatus, string> = {
  completed: "bg-green-500/10 text-green-600 border-green-500/20",
  delivered: "bg-green-500/10 text-green-600 border-green-500/20",
  in_locker: "bg-blue-500/10 text-blue-600 border-blue-500/20",
  in_transit: "bg-blue-500/10 text-blue-600 border-blue-500/20",
  returned: "bg-purple-500/10 text-purple-500 border-purple-500/20",
  expired: "bg-orange-500/10 text-orange-500 border-orange-500/20",

  canceled: "bg-gray-500/10 text-gray-600 border-gray-500/20",
  canceled_locker: "bg-gray-500/10 text-gray-600 border-gray-500/20",
  canceled_picked: "bg-gray-500/10 text-gray-600 border-gray-500/20",

  scheduled: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
  processing: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
};

const statusLabelKey: Record<OrderStatus, string> = {
  completed: "orderDetail.completed",
  delivered: "orderDetail.delivered",
  in_locker: "orderDetail.inLocker",
  in_transit: "orderDetail.inTransit",
  returned: "orderDetail.returned",
  expired: "orderDetail.expired",

  canceled: "common.cancelled",
  canceled_locker: "common.cancelled",
  canceled_picked: "orderDetail.canceledPicked",

  scheduled: "orderDetail.schedule",
  processing: "orderDetail.processing",
};

const statusLabelFallback: Record<Language, Record<OrderStatus, string>> = {
  es: {
    completed: "Completado",
    delivered: "Entregado",
    in_locker: "En locker",
    in_transit: "En tránsito",
    returned: "Devuelto",
    expired: "Vencido",

    canceled: "Cancelado",
    canceled_locker: "Cancelado",
    canceled_picked: "Cancelado recogido",

    scheduled: "Agendado",
    processing: "Procesando",
  },
  en: {
    completed: "Completed",
    delivered: "Delivered",
    in_locker: "In locker",
    in_transit: "In transit",
    returned: "Returned",
    expired: "Expired",

    canceled: "Canceled",
    canceled_locker: "Canceled",
    canceled_picked: "Canceled picked up",

    scheduled: "Scheduled",
    processing: "Processing",
  },
};

function getStatusLabel(
  t: TranslateFn,
  language: Language,
  status: OrderStatus
): string {
  const key = statusLabelKey[status];
  const translated = t(key);

  if (!translated || translated === key) {
    return statusLabelFallback[language][status];
  }

  return translated;
}

// ============================================================================
// TIMELINE TRANSLATION
// ============================================================================

const timelineTitleFallback: Record<Language, Record<string, string>> = {
  es: {
    "orderDetail.title.SCHEDULE": "Paquete programado",
    "orderDetail.title.REVIEWED": "Paquete revisado",
    "orderDetail.title.CANCELED_UNUSED": "Cancelado sin uso",
    "orderDetail.title.CANCELED": "Cancelado",
    "orderDetail.title.CANCELADO": "Cancelado",
    "orderDetail.title.ELIMINADO": "Eliminado",
    "orderDetail.title.DELIVERED": "Entregado",
    "orderDetail.title.IN_LOCKER": "En locker",
    "orderDetail.title.IN_TRANSIT": "En tránsito",
    "orderDetail.title.EXPIRED": "Vencido",
    "orderDetail.title.RETURNED": "Devuelto",
    "orderDetail.title.COMPLETED": "Completado",
    "orderDetail.title.unknown": "Movimiento desconocido",
  },
  en: {
    "orderDetail.title.SCHEDULE": "Package scheduled",
    "orderDetail.title.REVIEWED": "Package reviewed",
    "orderDetail.title.CANCELED_UNUSED": "Canceled unused",
    "orderDetail.title.CANCELED": "Canceled",
    "orderDetail.title.CANCELADO": "Canceled",
    "orderDetail.title.ELIMINADO": "Deleted",
    "orderDetail.title.DELIVERED": "Delivered",
    "orderDetail.title.IN_LOCKER": "In locker",
    "orderDetail.title.IN_TRANSIT": "In transit",
    "orderDetail.title.EXPIRED": "Expired",
    "orderDetail.title.RETURNED": "Returned",
    "orderDetail.title.COMPLETED": "Completed",
    "orderDetail.title.unknown": "Unknown movement",
  },
};

function getTimelineTitle(
  t: TranslateFn,
  language: Language,
  key: string
): string {
  const translated = t(key);

  if (!translated || translated === key) {
    return timelineTitleFallback[language][key] ?? prettifyTimelineKey(key);
  }

  return translated;
}

// ============================================================================
// UI COMPONENTS
// ============================================================================

function SectionCard({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={`rounded-2xl border border-border bg-card p-5 ${className}`}>
      {children}
    </div>
  );
}

function SectionTitle({ children }: { children: ReactNode }) {
  return (
    <h3 className="mb-4 text-sm font-semibold font-poppins text-foreground">
      {children}
    </h3>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
}: {
  icon?: ElementType;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3">
      {Icon && (
        <div className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-muted">
          <Icon className="h-3.5 w-3.5 text-muted-foreground" />
        </div>
      )}

      <div className="min-w-0 flex-1">
        <p className="text-[11px] font-inter text-muted-foreground">
          {label}
        </p>
        <p className="truncate text-xs font-medium font-inter leading-snug text-foreground">
          {value}
        </p>
      </div>
    </div>
  );
}

// ============================================================================
// SKELETON
// ============================================================================

function TransactionDetailSkeleton() {
  return (
    <div className="mx-auto max-w-[1200px] space-y-5 px-4 py-6 animate-pulse">
      <div className="flex items-center gap-3">
        <div className="h-9 w-9 rounded-lg bg-muted" />
        <div className="h-4 w-64 rounded-full bg-muted" />
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {[...Array(4)].map((_, index) => (
          <div
            key={index}
            className="space-y-2 rounded-2xl border border-border bg-card p-4"
          >
            <div className="h-3 w-20 rounded-full bg-muted" />
            <div className="h-5 w-28 rounded-full bg-muted" />
          </div>
        ))}
      </div>

      {[...Array(3)].map((_, index) => (
        <div
          key={index}
          className="space-y-3 rounded-2xl border border-border bg-card p-5"
        >
          <div className="h-4 w-40 rounded-full bg-muted" />
          {[...Array(4)].map((_, itemIndex) => (
            <div
              key={itemIndex}
              className="h-3 rounded-full bg-muted"
              style={{ width: `${50 + itemIndex * 12}%` }}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

// ============================================================================
// ERROR STATE
// ============================================================================

function ErrorState({
  error,
  id,
  onRetry,
  onBack,
}: {
  error: string | null;
  id: string | undefined;
  onRetry: () => void;
  onBack: () => void;
}) {
  const { t, language } = useLanguage();

  return (
    <div className="mx-auto max-w-[600px] space-y-4 px-4 py-16 text-center">
      <div className="flex justify-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-red-500/10">
          <AlertCircle className="h-8 w-8 text-red-500" />
        </div>
      </div>

      <h2 className="text-lg font-semibold font-poppins text-foreground">
        {error
          ? tx(t, language, "txnDetail.errorLoadingPackage", {
              es: "Error al cargar el paquete",
              en: "Error loading package",
            })
          : tx(t, language, "txnDetail.packageNotFound", {
              es: "Paquete no encontrado",
              en: "Package not found",
            })}
      </h2>

      <p className="text-sm font-inter text-muted-foreground">
        {error ??
          tx(t, language, "txnDetail.packageIdNotFound", {
            es: `No se encontró el paquete con ID ${id}`,
            en: `Package with ID ${id} was not found`,
          })}
      </p>

      <div className="flex justify-center gap-3">
        <Button variant="outline" className="gap-2 text-xs" onClick={onBack}>
          <ArrowLeft className="h-3.5 w-3.5" />
          {tx(t, language, "txnDetail.backToServices", {
            es: "Volver a servicios",
            en: "Back to services",
          })}
        </Button>

        {error && (
          <Button className="gap-2 text-xs" onClick={onRetry}>
            <RefreshCw className="h-3.5 w-3.5" />
            {tx(t, language, "common.retry", {
              es: "Reintentar",
              en: "Retry",
            })}
          </Button>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// HEADER COMPONENT
// ============================================================================

function TransactionDetailHeader({
  order,
  onBack,
}: {
  order: OrderDetail;
  onBack: () => void;
}) {
  const { t, language } = useLanguage();
  const [lockerOpen, setLockerOpen] = useState(false);

  return (
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9 shrink-0"
          onClick={onBack}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>

        <nav className="flex items-center gap-2 text-xs font-inter text-muted-foreground">
          <Link
            to="/services"
            className="transition-colors hover:text-foreground"
          >
            {tx(t, language, "services.title", {
              es: "Servicios",
              en: "Services",
            })}
          </Link>
          <span>/</span>
          <span className="font-semibold text-foreground">
            {order.tracking_number}
          </span>
        </nav>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <DropdownMenu open={lockerOpen} onOpenChange={setLockerOpen}>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="h-9 gap-2 text-xs font-inter">
              <MapPin className="h-4 w-4 text-primary" />
              {order.property.name}
              <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
            </Button>
          </DropdownMenuTrigger>

          <DropdownMenuContent
            align="end"
            className="w-72 border border-border bg-card p-4"
          >
            <div className="space-y-3">
              <p className="text-xs font-semibold font-poppins text-foreground">
                {order.property.name}
              </p>

              <div className="grid grid-cols-2 gap-3 border-t border-border pt-3">
                <InfoRow
                  icon={Box}
                  label={tx(t, language, "orderDetail.locker", {
                    es: "Locker",
                    en: "Locker",
                  })}
                  value={order.locker.name}
                />

                <InfoRow
                  icon={Hash}
                  label={tx(t, language, "txnDetail.position", {
                    es: "Posición",
                    en: "Position",
                  })}
                  value={order.position}
                />

                <InfoRow
                  icon={Layers}
                  label={tx(t, language, "orderDetail.door", {
                    es: "Puerta",
                    en: "Door",
                  })}
                  value={order.locker.door_assigned}
                />

                <InfoRow
                  icon={Package}
                  label={tx(t, language, "txnDetail.compartment", {
                    es: "Compartimento",
                    en: "Compartment",
                  })}
                  value={order.locker.max_length}
                />

                <InfoRow
                  icon={Box}
                  label={tx(t, language, "txnDetail.service", {
                    es: "Servicio",
                    en: "Service",
                  })}
                  value={order.locker.service_type}
                />
              </div>
            </div>
          </DropdownMenuContent>
        </DropdownMenu>

        <Badge
          variant="outline"
          className={`gap-1.5 text-[11px] font-semibold font-inter ${
            statusBadgeClass[order.status]
          }`}
        >
          {getStatusLabel(t, language, order.status)}
        </Badge>
      </div>
    </div>
  );
}

// ============================================================================
// METRICS COMPONENT
// ============================================================================

// ============================================================================
// METRICS COMPONENT
// ============================================================================

function TransactionMetrics({ order }: { order: OrderDetail }) {
  const { t, language } = useLanguage();

  const statusLabel = getStatusLabel(t, language, order.status);

  return (
    <KpiGrid columns={4}>
      <KpiCard
        title={tx(t, language, "txnDetail.tracking", {
          es: "Tracking",
          en: "Tracking",
        })}
        value={cleanDisplayValue(order.tracking_number)}
        tooltip={tx(t, language, "txnDetail.tooltips.tracking", {
          es: "Número único utilizado para identificar y consultar este paquete.",
          en: "Unique number used to identify and track this package.",
        })}
      />

      <KpiCard
        title={tx(t, language, "services.status", {
          es: "Estado",
          en: "Status",
        })}
        value={statusLabel}
        tooltip={tx(t, language, "txnDetail.tooltips.status", {
          es: "Estado actual del paquete dentro del flujo del servicio.",
          en: "Current package status within the service flow.",
        })}
        variant={
          order.status === "completed" || order.status === "delivered"
            ? "success"
            : order.status === "expired"
            ? "warning"
            : "default"
        }
      />

      <KpiCard
        title={tx(t, language, "txnDetail.compartment", {
          es: "Compartimento",
          en: "Compartment",
        })}
        value={cleanDisplayValue(order.locker.max_length)}
        tooltip={tx(t, language, "txnDetail.tooltips.compartment", {
          es: "Dimensión del compartimento asignado al paquete.",
          en: "Dimensions of the compartment assigned to the package.",
        })}
      />

      <KpiCard
        title={tx(t, language, "txnDetail.position", {
          es: "Posición",
          en: "Position",
        })}
        value={cleanDisplayValue(order.position)}
        tooltip={tx(t, language, "txnDetail.tooltips.position", {
          es: "Posición física del compartimento asignado dentro del locker.",
          en: "Physical position of the assigned compartment inside the locker.",
        })}
      />
    </KpiGrid>
  );
}

// ============================================================================
// CLIENT INFO COMPONENT
// ============================================================================

function TransactionClientInfo({ order }: { order: OrderDetail }) {
  const { t, language } = useLanguage();

  return (
    <SectionCard>
      <SectionTitle>
        {tx(t, language, "txnDetail.clientAndPackage", {
          es: "Información del cliente y paquete",
          en: "Client and package information",
        })}
      </SectionTitle>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <InfoRow
          icon={Hash}
          label={tx(t, language, "txnDetail.trackingNumber", {
            es: "Número de tracking",
            en: "Tracking number",
          })}
          value={order.tracking_number}
        />

        <InfoRow
          icon={Key}
          label="OTP"
          value={cleanDisplayValue(order.otp)}
        />

        <InfoRow
          icon={Mail}
          label={tx(t, language, "txnDetail.clientName", {
            es: "Cliente",
            en: "Client",
          })}
          value={order.client.name}
        />

        <InfoRow
          icon={Mail}
          label={tx(t, language, "txnDetail.email", {
            es: "Email",
            en: "Email",
          })}
          value={order.client.email}
        />

        <InfoRow
          icon={Phone}
          label={tx(t, language, "txnDetail.phone", {
            es: "Teléfono",
            en: "Phone",
          })}
          value={order.client.phone}
        />

        <InfoRow
          icon={Calendar}
          label={tx(t, language, "orderDetail.registrationDate", {
            es: "Fecha registro",
            en: "Registration date",
          })}
          value={order.registration_date}
        />

        <InfoRow
          icon={Calendar}
          label={tx(t, language, "orderDetail.expirationDate", {
            es: "Fecha expiración",
            en: "Expiration date",
          })}
          value={order.expiration_date}
        />

        {order.collected_date !== "---" && (
          <InfoRow
            icon={CheckCircle}
            label={tx(t, language, "orderDetail.collectionDate", {
              es: "Fecha recogida",
              en: "Collection date",
            })}
            value={order.collected_date}
          />
        )}
      </div>
    </SectionCard>
  );
}

// ============================================================================
// PROPERTY INFO COMPONENT
// ============================================================================

function TransactionPropertyInfo({ order }: { order: OrderDetail }) {
  const { t, language } = useLanguage();

  return (
    <SectionCard>
      <SectionTitle>
        {tx(t, language, "txnDetail.propertyInfo", {
          es: "Información de la propiedad",
          en: "Property information",
        })}
      </SectionTitle>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <InfoRow
          icon={MapPin}
          label={tx(t, language, "settings.propertyName", {
            es: "Nombre propiedad",
            en: "Property name",
          })}
          value={order.property.name}
        />

        <InfoRow
          icon={MapPin}
          label={tx(t, language, "ticketDetail.address", {
            es: "Dirección",
            en: "Address",
          })}
          value={order.property.address}
        />

        <InfoRow
          icon={Package}
          label={tx(t, language, "orderDetail.description", {
            es: "Descripción",
            en: "Description",
          })}
          value={order.property.description}
        />

        <InfoRow
          icon={Calendar}
          label={tx(t, language, "orderDetail.weekdays", {
            es: "Horario semana",
            en: "Weekday schedule",
          })}
          value={order.property.scheduled_attention.weekdays}
        />

        <InfoRow
          icon={Calendar}
          label={tx(t, language, "orderDetail.weekends", {
            es: "Horario fin de semana",
            en: "Weekend schedule",
          })}
          value={order.property.scheduled_attention.weekends}
        />
      </div>
    </SectionCard>
  );
}

// ============================================================================
// TIMELINE COMPONENT
// ============================================================================

function TransactionTimeline({ order }: { order: OrderDetail }) {
  const { t, language } = useLanguage();

  if (!order.timeline || order.timeline.length === 0) {
    return null;
  }

  return (
    <SectionCard>
      <SectionTitle>
        {tx(t, language, "orderDetail.transactionHistory", {
          es: "Historial de la transacción",
          en: "Transaction history",
        })}
      </SectionTitle>

      <div className="space-y-0">
        {order.timeline.map((event, index) => (
          <div
            key={`${event.id}-${event.timestamp}-${index}`}
            className="flex gap-4 pb-5 last:pb-0"
          >
            <div className="flex flex-col items-center pt-1.5">
              <div
                className={`flex h-3 w-3 rounded-full ring-4 ${
                  event.type === "success"
                    ? "bg-green-500 ring-green-500/10"
                    : event.type === "error"
                    ? "bg-red-500 ring-red-500/10"
                    : event.type === "info"
                    ? "bg-blue-500 ring-blue-500/10"
                    : "bg-yellow-500 ring-yellow-500/10"
                }`}
              />

              {index < order.timeline.length - 1 && (
                <div className="mt-2 w-px flex-1 bg-border" />
              )}
            </div>

            <div className="flex flex-1 items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                {event.type === "success" && (
                  <CheckCircle className="h-3.5 w-3.5 text-green-500" />
                )}

                {event.type === "error" && (
                  <AlertCircle className="h-3.5 w-3.5 text-red-500" />
                )}

                {event.type === "warning" && (
                  <AlertCircle className="h-3.5 w-3.5 text-yellow-500" />
                )}

                {event.type === "info" && (
                  <Clock className="h-3.5 w-3.5 text-blue-500" />
                )}

                <p className="text-xs font-semibold font-inter text-foreground">
                  {getTimelineTitle(t, language, event.title)}
                </p>
              </div>

              <p className="whitespace-nowrap text-[11px] font-inter text-muted-foreground">
                {event.timestamp}
              </p>
            </div>
          </div>
        ))}
      </div>
    </SectionCard>
  );
}

// ============================================================================
// EVIDENCE COMPONENT
// ============================================================================

interface EvidencePhoto {
  url: string;
  label: string;
  date: string | null;
}

function TransactionEvidence({ order }: { order: OrderDetail }) {
  const { t, language } = useLanguage();
  const [selectedPhoto, setSelectedPhoto] = useState<EvidencePhoto | null>(
    null
  );
  const [videoOpen, setVideoOpen] = useState(false);

  const photos: EvidencePhoto[] = [
    {
      url: order.evidence.dropoff_photo,
      label: tx(t, language, "orderDetail.dropoffPhoto", {
        es: "Foto de depósito",
        en: "Drop-off photo",
      }),
      date: order.evidence.dropoff_timestamp,
    },
    {
      url: order.evidence.pickup_photo,
      label: tx(t, language, "orderDetail.pickupPhoto", {
        es: "Foto de retiro",
        en: "Pickup photo",
      }),
      date: order.evidence.pickup_timestamp,
    },
  ].filter((photo) => Boolean(photo.url));

  const hasVideo = Boolean(order.evidence.video_url);

  if (photos.length === 0 && !hasVideo) {
    return null;
  }

  return (
    <>
      <SectionCard>
        <SectionTitle>
          {tx(t, language, "orderDetail.deliveryEvidence", {
            es: "Evidencia",
            en: "Evidence",
          })}
        </SectionTitle>

        {photos.length > 0 && (
          <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {photos.map((photo, index) => (
              <button
                key={`${photo.label}-${index}`}
                type="button"
                onClick={() => setSelectedPhoto(photo)}
                className="group overflow-hidden rounded-xl border border-border text-left transition-all duration-200 hover:border-primary/40 hover:shadow-md"
              >
                <div className="relative flex h-[140px] items-center justify-center bg-muted sm:h-[160px]">
                  <img
                    src={photo.url}
                    alt={photo.label}
                    className="h-full w-full object-cover"
                  />
                </div>

                <div className="px-3 py-2">
                  <p className="truncate text-xs font-semibold font-inter text-foreground">
                    {photo.label}
                  </p>

                  {photo.date && (
                    <p className="mt-0.5 truncate text-[10px] font-inter text-muted-foreground">
                      {fmtDate(photo.date, language)}
                    </p>
                  )}
                </div>
              </button>
            ))}
          </div>
        )}

        {hasVideo && (
          <div className="mt-2 border-t border-border pt-4">
            <Button
              variant="outline"
              size="sm"
              className="h-9 gap-2 text-xs font-inter"
              onClick={() => setVideoOpen(true)}
            >
              <Play className="h-3.5 w-3.5" />
              {tx(t, language, "orderDetail.evidenceVideo", {
                es: "Ver video de evidencia",
                en: "View evidence video",
              })}
            </Button>
          </div>
        )}
      </SectionCard>

      <Dialog
        open={Boolean(selectedPhoto)}
        onOpenChange={(open) => {
          if (!open) setSelectedPhoto(null);
        }}
      >
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-semibold font-poppins">
              {selectedPhoto?.label}
            </DialogTitle>
          </DialogHeader>

          <AspectRatio
            ratio={4 / 3}
            className="overflow-hidden rounded-lg bg-muted"
          >
            {selectedPhoto?.url ? (
              <img
                src={selectedPhoto.url}
                alt={selectedPhoto.label}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full flex-col items-center justify-center gap-2 text-muted-foreground">
                <Camera className="h-10 w-10" />
                <p className="text-xs font-inter">
                  {tx(t, language, "txnDetail.noPhotoAvailable", {
                    es: "Sin foto disponible",
                    en: "No photo available",
                  })}
                </p>
              </div>
            )}
          </AspectRatio>
        </DialogContent>
      </Dialog>

      <Dialog open={videoOpen} onOpenChange={setVideoOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-semibold font-poppins">
              {tx(t, language, "orderDetail.evidenceVideo", {
                es: "Video de evidencia",
                en: "Evidence video",
              })}
            </DialogTitle>
          </DialogHeader>

          <AspectRatio
            ratio={16 / 9}
            className="flex items-center justify-center overflow-hidden rounded-lg bg-muted"
          >
            {order.evidence.video_url ? (
              <video
                src={order.evidence.video_url}
                controls
                className="h-full w-full"
              />
            ) : (
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <Play className="h-10 w-10" />
                <p className="text-xs font-inter">
                  {tx(t, language, "orderDetail.videoUnavailable", {
                    es: "Video no disponible",
                    en: "Video unavailable",
                  })}
                </p>
              </div>
            )}
          </AspectRatio>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ============================================================================
// NOTIFICATIONS COMPONENT
// ============================================================================

function TransactionNotifications({ order }: { order: OrderDetail }) {
  const { t, language } = useLanguage();

  if (!order.notifications || order.notifications.length === 0) {
    return null;
  }

  const getNotificationStatus = (status: string) => {
    const normalizedStatus = status.toLowerCase();

    if (normalizedStatus === "enviado" || normalizedStatus === "sent") {
      return tx(t, language, "txnDetail.notificationSent", {
        es: "Enviado",
        en: "Sent",
      });
    }

    return tx(t, language, "txnDetail.notificationError", {
      es: "Error",
      en: "Error",
    });
  };

  return (
    <SectionCard>
      <SectionTitle>
        {tx(t, language, "orderDetail.notifications", {
          es: "Notificaciones enviadas",
          en: "Sent notifications",
        })}
      </SectionTitle>

      <div className="space-y-3">
        {order.notifications.map((notification, index) => {
          const statusLabel = getNotificationStatus(notification.status);
          const isSent =
            notification.status.toLowerCase() === "enviado" ||
            notification.status.toLowerCase() === "sent";

          return (
            <div
              key={`${notification.id}-${index}`}
              className="flex items-center justify-between rounded-xl bg-muted/30 p-3"
            >
              <div className="flex items-center gap-3">
                <Bell className="h-4 w-4 text-muted-foreground" />

                <div>
                  <p className="text-xs font-semibold font-inter text-foreground">
                    {notification.type}
                  </p>
                  <p className="text-[10px] font-inter text-muted-foreground">
                    {notification.method}
                  </p>
                </div>
              </div>

              <div className="text-right">
                <Badge
                  variant="outline"
                  className={`text-[10px] ${
                    isSent
                      ? "bg-green-500/10 text-green-600"
                      : "bg-red-500/10 text-red-600"
                  }`}
                >
                  {statusLabel}
                </Badge>

                <p className="mt-1 text-[10px] font-inter text-muted-foreground">
                  {notification.send_date}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </SectionCard>
  );
}

// ============================================================================
// QR CODE BUTTON
// ============================================================================

const QR_ALLOWED_STATUSES: OrderStatus[] = ["expired", "in_locker"];

function QRCodeButton({ order }: { order: OrderDetail }) {
  const { t, language } = useLanguage();
  const [qrOpen, setQrOpen] = useState(false);
  const canGenerateQR = QR_ALLOWED_STATUSES.includes(order.status);

  if (!canGenerateQR) {
    return null;
  }

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        className="h-9 gap-2 text-xs font-inter"
        onClick={() => setQrOpen(true)}
      >
        <Package className="h-3.5 w-3.5" />
        {tx(t, language, "orderDetail.generateQR", {
          es: "Ver QR",
          en: "View QR",
        })}
      </Button>

      <Dialog open={qrOpen} onOpenChange={setQrOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">
              {tx(t, language, "orderDetail.qrCode", {
                es: "Código QR del paquete",
                en: "Package QR code",
              })}
            </DialogTitle>
          </DialogHeader>

          <div className="flex flex-col items-center space-y-4 py-4">
            <div className="rounded-xl bg-white p-4">
              <QRCode
                value={order.hash_package || order.tracking_number}
                size={200}
              />
            </div>

            <p className="text-center text-xs font-inter text-muted-foreground">
              {order.status === "expired"
                ? tx(t, language, "txnDetail.expiredQrDescription", {
                    es: "QR para retiro de paquete vencido",
                    en: "QR for expired package pickup",
                  })
                : tx(t, language, "txnDetail.lockerQrDescription", {
                    es: "QR para apertura de locker",
                    en: "QR for locker opening",
                  })}
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export default function ServiceTransactionDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { t, language } = useLanguage();

  const [orderData, setOrderData] = useState<OrderDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchOrderDetail = useCallback(async () => {
    if (!id) {
      setError(
        tx(t, language, "txnDetail.noServiceId", {
          es: "No se proporcionó ID del servicio",
          en: "No service ID was provided",
        })
      );
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const response = await orderDetailService.getDetailPackage(id, language);
      const code = Number(response?.mensaje_return?.CODE);

      if (code === 200) {
        const mapped = mapOrderDetail(response);

        if (mapped) {
          setOrderData(mapped);
          return;
        }

        setError(
          tx(t, language, "txnDetail.mapError", {
            es: "No se pudieron mapear los datos del paquete",
            en: "Package data could not be mapped",
          })
        );
        return;
      }

      setError(
        response?.mensaje_return?.MESSAGE ||
          tx(t, language, "txnDetail.loadPackageError", {
            es: "Error al cargar el detalle del paquete",
            en: "Error loading package detail",
          })
      );
    } catch (err) {
      console.error("Error fetching order detail:", err);

      setError(
        err instanceof Error
          ? err.message
          : tx(t, language, "txnDetail.connectionError", {
              es: "Error de conexión",
              en: "Connection error",
            })
      );
    } finally {
      setLoading(false);
    }
  }, [id, language, t]);

  useEffect(() => {
    fetchOrderDetail();
  }, [fetchOrderDetail]);

  if (loading) {
    return (
      <DashboardLayout>
        <TransactionDetailSkeleton />
      </DashboardLayout>
    );
  }

  if (error || !orderData) {
    return (
      <DashboardLayout>
        <ErrorState
          error={error}
          id={id}
          onRetry={fetchOrderDetail}
          onBack={() => navigate("/services")}
        />
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-[1200px] space-y-5 px-4 py-6">
        <TransactionDetailHeader
          order={orderData}
          onBack={() => navigate("/services")}
        />

        <TransactionMetrics order={orderData} />

        <TransactionClientInfo order={orderData} />

        <TransactionPropertyInfo order={orderData} />

        <TransactionTimeline order={orderData} />

        <TransactionEvidence order={orderData} />

        <TransactionNotifications order={orderData} />

        <div className="flex justify-end gap-3">
          <QRCodeButton order={orderData} />
        </div>
      </div>
    </DashboardLayout>
  );
}