import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { cn } from "@/lib/utils";
import { useLanguage } from "@/contexts/LanguageContext";

// Tabs
import AccountTab from "@/components/settings/AccountTab";
import PasswordTab from "@/components/settings/PasswordTab";
import PreferencesTab from "@/components/settings/PreferencesTab";
import PropertyTab from "@/components/settings/PropertyTab";
import AppearanceTab from "@/components/settings/AppearanceTab";
// ← elimina el import de LoadingSpinner, no se usa aquí

export default function Settings() {
  const { t } = useLanguage();
  const [searchParams, setSearchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState(() => {
    return searchParams.get("tab") || "account";
  });

  const tabs = [
    { id: "account",    label: t("settings.tab.account") },
    { id: "password",   label: t("settings.tab.password") },
    { id: "appearance", label: t("settings.tab.appearance") },
  ];

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    setSearchParams({ tab: tabId });
  };

  const subtitle = t("settings.subtitle");
  const hasValidSubtitle = subtitle !== "settings.subtitle";

  // ← elimina el if (loading) completo

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <DashboardHeader
          title={t("settings.title")}
          subtitle={hasValidSubtitle ? subtitle : undefined}
        />

        <div className="mt-6 border-b border-border">
          <div className="flex gap-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => handleTabChange(tab.id)}
                className={cn(
                  "pb-3 text-sm font-medium transition-colors border-b-2 -mb-px whitespace-nowrap",
                  activeTab === tab.id
                    ? "text-primary border-primary"
                    : "text-muted-foreground border-transparent hover:text-foreground"
                )}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-8 max-w-[740px]">
          {activeTab === "account"    && <AccountTab />}
          {activeTab === "password"   && <PasswordTab />}
          {activeTab === "appearance" && <AppearanceTab />}
        </div>
      </div>
    </DashboardLayout>
  );
}